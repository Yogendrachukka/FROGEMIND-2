# FrogeMind — Upgrade Notes v2.0

## What Changed

### 🧠 Smart Auto-Router (Improved)
- **Coding** → Qwen 2.5 Coder 32B (regex matches code keywords, file types, frameworks)
- **Deep reasoning/math** → DeepSeek R1 (matches analysis, proof, theorem, etc.)
- **Casual/short chat** → Gemini 2.5 Flash or Llama 3.1 8B on Groq (fast)
- **Conversation** → Llama 3.3 70B (natural dialogue)
- **Writing/multilingual** → Qwen 2.5 72B
- **Vision (images)** → Gemini 2.5 Flash
- Route info shown inline in chat header with category badge

### 💬 Chat Interface (Rebuilt)
- Full **Markdown rendering**: headers, lists, bold, italic, inline code, links, blockquotes
- **Code blocks**: syntax highlighted, language label, copy button per block
- **Textarea input** with auto-resize (Shift+Enter for newline, Enter to send)
- **Bubble layout**: user right (indigo), AI left (white card)
- Smooth **typing cursor** animation while streaming
- Better **thinking dots** animation
- Route category badge (Code / Reasoning / Writing / Vision / Chat)
- Proper **attach/image preview** in messages
- Close button on split-screen panel B

### 🎨 UI Design (Refined)
- **Fonts**: Plus Jakarta Sans (display) + DM Sans (body) + JetBrains Mono
- **Colors**: White/slate base, indigo accents, no heavy colors
- Cleaner sidebar: tighter spacing, better active states
- Custom scrollbar styling
- Improved model dropdown (replaces native select)

### 🔧 Bug Fixes
- Code block rendering was showing dummy text — now renders actual code
- Input was `<input>` (no multiline) — upgraded to auto-resize `<textarea>`
- Auto-router had weak keyword matching — overhauled with comprehensive regex
- Removed duplicate model definitions in App.tsx
- Added `multiple` attribute to file inputs
- Streaming state properly clears on split-screen mode

### 📦 Models
- All 19 models retained with improved "Best for:" descriptions
- Skill annotations per model (what each excels at)
