/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Bot,
  ShieldCheck,
  Sliders,
  MessageSquare,
  LogOut,
  Clock,
  Briefcase,
  Cable,
  Zap
} from 'lucide-react';

interface SidebarProps {
  currentScreen: string;
  setScreen: (screen: string) => void;
  memoriesCount: number;
  pluginsCount: number;
  onSignOut: () => void;
  userEmail: string;
  isAdmin: boolean;
}

export default function Sidebar({
  currentScreen,
  setScreen,
  memoriesCount,
  pluginsCount,
  onSignOut,
  userEmail,
  isAdmin
}: SidebarProps) {

  const navItems = [
    { id: 'chat',       label: 'Chat',         icon: MessageSquare, badge: null,                          color: 'text-indigo-500' },
    { id: 'projects',   label: 'Projects',     icon: Briefcase,     badge: 'Active',                      color: 'text-sky-500' },
    { id: 'connectors', label: 'Connectors',   icon: Cable,         badge: null,                          color: 'text-emerald-500' },
    {
      id: 'admin',
      label: isAdmin ? 'Admin Console' : 'Usage Stats',
      icon: ShieldCheck,
      badge: isAdmin ? 'Admin' : null,
      color: isAdmin ? 'text-amber-500' : 'text-rose-500'
    },
    { id: 'settings',   label: 'Settings',     icon: Sliders,       badge: null,                          color: 'text-slate-500' },
  ];

  return (
    <aside className="w-60 shrink-0 flex flex-col justify-between border-r border-slate-100 bg-white h-screen select-none font-sans">
      <div>
        {/* Brand */}
        <div className="px-5 py-5 flex items-center gap-3 border-b border-slate-100">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center shadow-sm">
            <Zap className="w-4 h-4 text-white" />
          </div>
          <div>
            <span className="font-bold text-sm text-slate-900 block font-display tracking-tight">FrogeMind</span>
            <span className="text-[9px] uppercase font-mono tracking-widest text-indigo-500 block font-bold leading-none">AI Assistant</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-3 space-y-0.5">
          <p className="text-[9px] font-mono uppercase tracking-widest text-slate-400 font-bold px-2 pt-2 pb-1.5">Navigation</p>
          {navItems.map((item) => {
            const isActive = currentScreen === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setScreen(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all duration-150 cursor-pointer ${
                  isActive
                    ? 'bg-indigo-50 text-indigo-700 border border-indigo-100'
                    : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50 border border-transparent'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-indigo-500' : item.color}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded-full font-bold uppercase ${
                    isActive
                      ? 'bg-indigo-100 text-indigo-600'
                      : 'bg-slate-100 text-slate-500'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Quick stats */}
        <div className="mx-3 mt-3 bg-slate-50 rounded-2xl p-3.5 border border-slate-100">
          <div className="flex items-center gap-1.5 mb-2.5">
            <Clock className="w-3 h-3 text-slate-400" />
            <span className="text-[9px] font-mono uppercase tracking-widest text-slate-400 font-bold">Status</span>
          </div>
          <div className="space-y-1.5 text-[10px] font-mono">
            <div className="flex justify-between">
              <span className="text-slate-500">API Latency</span>
              <span className="text-emerald-600 font-semibold">12ms</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Memories</span>
              <span className="text-indigo-600 font-semibold">{memoriesCount} saved</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Models</span>
              <span className="text-slate-700 font-semibold">19 active</span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="p-3 border-t border-slate-100 space-y-2">
        {userEmail && (
          <div className={`p-2.5 rounded-xl border ${
            isAdmin ? 'bg-amber-50 border-amber-200' : 'bg-slate-50 border-slate-100'
          }`}>
            <div className="flex items-center gap-2 mb-0.5">
              <div className={`w-1.5 h-1.5 rounded-full ${isAdmin ? 'bg-amber-500' : 'bg-emerald-500'}`} />
              <span className={`text-[9px] font-mono font-bold uppercase ${isAdmin ? 'text-amber-600' : 'text-slate-400'}`}>
                {isAdmin ? 'Admin' : 'User'}
              </span>
            </div>
            <span className="text-xs font-semibold text-slate-800 block truncate font-display">
              {userEmail.split('@')[0]}
            </span>
            <span className="text-[10px] text-slate-400 font-mono truncate block">{userEmail}</span>
          </div>
        )}

        <button
          onClick={onSignOut}
          className="w-full py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-500 hover:text-slate-700 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          Sign Out
        </button>
      </div>
    </aside>
  );
}
