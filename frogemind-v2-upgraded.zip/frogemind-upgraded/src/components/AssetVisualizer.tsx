/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { ShapeSpec } from '../types';

interface AssetVisualizerProps {
  shapes: ShapeSpec[];
  colors: string[];
  name: string;
}

export default function AssetVisualizer({ shapes, colors, name }: AssetVisualizerProps) {
  // Yaw represents horizontal rotation (around Y axis)
  const [yaw, setYaw] = useState<number>(-35);
  // Pitch represents vertical tilt (around X axis)
  const [pitch, setPitch] = useState<number>(20);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [scale, setScale] = useState<number>(1.1);
  const dragStart = useRef({ x: 0, y: 0 });
  const startRotation = useRef({ yaw: 0, pitch: 0 });

  // Fallback if no shapes
  const displayShapes = shapes && shapes.length > 0 ? shapes : [
    { type: 'cube' as const, color: colors[0] || '#6366f1', size: [80, 80, 80] as [number, number, number], position: [0, 0, 0] as [number, number, number], rotation: [0, 45, 0] as [number, number, number] }
  ];

  // Mouse drag handlers to rotate 3D scene
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragStart.current = { x: e.clientX, y: e.clientY };
    startRotation.current = { yaw, pitch };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStart.current.x;
    const dy = e.clientY - dragStart.current.y;
    // Multipliers controls speed of drag
    setYaw(startRotation.current.yaw + dx * 0.5);
    setPitch(Math.max(-80, Math.min(80, startRotation.current.pitch - dy * 0.5)));
  };

  const handleMouseUpOrLeave = () => {
    setIsDragging(false);
  };

  // Touch handlers for mobile/trackpad devices
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 0) return;
    setIsDragging(true);
    dragStart.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    startRotation.current = { yaw, pitch };
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || e.touches.length === 0) return;
    const dx = e.touches[0].clientX - dragStart.current.x;
    const dy = e.touches[0].clientY - dragStart.current.y;
    setYaw(startRotation.current.yaw + dx * 0.5);
    setPitch(Math.max(-80, Math.min(80, startRotation.current.pitch - dy * 0.5)));
  };

  // Helper values
  const width = 450;
  const height = 300;
  const cx = width / 2;
  const cy = height / 2;

  // 3D rotation matrix calculation
  const projectPoint = (x: number, y: number, z: number): { x: number; y: number; zDepth: number } => {
    const radYaw = (yaw * Math.PI) / 180;
    const radPitch = (pitch * Math.PI) / 180;

    // Y-rotate (Yaw)
    let rx = x * Math.cos(radYaw) - z * Math.sin(radYaw);
    let rz = x * Math.sin(radYaw) + z * Math.cos(radYaw);

    // X-rotate (Pitch)
    let ry = y * Math.cos(radPitch) - rz * Math.sin(radPitch);
    let rz2 = y * Math.sin(radPitch) + rz * Math.cos(radPitch);

    // Orthographic projection with scaling
    const screenX = cx + rx * scale;
    const screenY = cy - ry * scale; // invert Y to match cartesian standard

    return { x: screenX, y: screenY, zDepth: rz2 };
  };

  // Draw 3D Primitives
  interface PolygonItem {
    id: string;
    points: string;
    avgDepth: number;
    color: string;
    opacity: number;
    strokeColor?: string;
    isOutlineOnly?: boolean;
    elementType: 'polygon' | 'circle' | 'line';
    circleProps?: { cx: number; cy: number; r: number };
    lineProps?: { x1: number; y1: number; x2: number; y2: number };
  }

  const itemsToRender: PolygonItem[] = [];

  // Populate render items based on shape specs
  displayShapes.forEach((shape, index) => {
    const [sx, sy, sz] = shape.size;
    const [px, py, pz] = shape.position;
    const opacity = shape.opacity ?? 0.85;

    // Helper functions for vertices
    const getCubeVertices = (): [number, number, number][] => {
      const dx = sx / 2;
      const dy = sy / 2;
      const dz = sz / 2;
      return [
        [-dx, -dy, -dz], [dx, -dy, -dz], [dx, dy, -dz], [-dx, dy, -dz],
        [-dx, -dy, dz],  [dx, -dy, dz],  [dx, dy, dz],  [-dx, dy, dz]
      ].map(([vx, vy, vz]) => {
        // Apply individual shape rotation if defined
        const srx = ((shape.rotation?.[0] || 0) * Math.PI) / 180;
        const sry = ((shape.rotation?.[1] || 0) * Math.PI) / 180;
        const srz = ((shape.rotation?.[2] || 0) * Math.PI) / 180;

        // Rotate vertices around individual axes
        let x1 = vx;
        let y1 = vy * Math.cos(srx) - vz * Math.sin(srx);
        let z1 = vy * Math.sin(srx) + vz * Math.cos(srx);

        let x2 = x1 * Math.cos(sry) + z1 * Math.sin(sry);
        let y2 = y1;
        let z2 = -x1 * Math.sin(sry) + z1 * Math.cos(sry);

        let x3 = x2 * Math.cos(srz) - y2 * Math.sin(srz);
        let y3 = x2 * Math.sin(srz) + y2 * Math.cos(srz);
        let z3 = z2;

        return [x3 + px, y3 + py, z3 + pz];
      });
    };

    if (shape.type === 'cube' || shape.type === 'crystal') {
      const v = getCubeVertices();
      const faceIndices = shape.type === 'cube' ? [
        [0, 1, 2, 3], // Back
        [4, 5, 6, 7], // Front
        [0, 1, 5, 4], // Bottom
        [2, 3, 7, 6], // Top
        [0, 3, 7, 4], // Left
        [1, 2, 6, 5]  // Right
      ] : [
        [0, 1, 2], [0, 2, 3], [0, 3, 4], [0, 4, 1], // Top pyramid vertices if pyramid
        [5, 1, 2], [5, 2, 3], [5, 3, 4], [5, 4, 1]  // Bottom inverted pyramid for crystal
      ];

      faceIndices.forEach((face, fIdx) => {
        const projected = face.map(vIdx => projectPoint(v[vIdx][0], v[vIdx][1], v[vIdx][2]));
        const avgDepth = projected.reduce((sum, pt) => sum + pt.zDepth, 0) / projected.length;
        const pointsStr = projected.map(pt => `${pt.x},${pt.y}`).join(' ');

        // Shade faces slightly to simulate light source from top-right
        const shadeFactor = 0.85 + (fIdx % 3) * 0.05;
        const hex = shape.color;
        
        itemsToRender.push({
          id: `shape-${index}-face-${fIdx}`,
          elementType: 'polygon',
          points: pointsStr,
          avgDepth,
          color: hex,
          opacity: opacity * (fIdx === 3 ? 1.0 : shadeFactor), // Top face is brightest
          strokeColor: '#e2e8f0', // Soft white edges
        });
      });
    } else if (shape.type === 'pyramid') {
      const v = [
        [px, py + sy/2, pz], // Apex top
        [px - sx/2, py - sy/2, pz - sz/2], // bottom base corners
        [px + sx/2, py - sy/2, pz - sz/2],
        [px + sx/2, py - sy/2, pz + sz/2],
        [px - sx/2, py - sy/2, pz + sz/2],
      ];

      // Triangles side faces
      const faces = [
        [0, 1, 2], [0, 2, 3], [0, 3, 4], [0, 4, 1], // Sides
        [1, 2, 3, 4] // Base square
      ];

      faces.forEach((face, fIdx) => {
        const projected = face.map(vIdx => projectPoint(v[vIdx][0], v[vIdx][1], v[vIdx][2]));
        const avgDepth = projected.reduce((sum, pt) => sum + pt.zDepth, 0) / projected.length;
        const pointsStr = projected.map(pt => `${pt.x},${pt.y}`).join(' ');
        const shadeFactor = 0.82 + (fIdx % 4) * 0.06;

        itemsToRender.push({
          id: `pyramid-${index}-face-${fIdx}`,
          elementType: 'polygon',
          points: pointsStr,
          avgDepth,
          color: shape.color,
          opacity: opacity * shadeFactor,
          strokeColor: '#ffffff'
        });
      });
    } else if (shape.type === 'sphere') {
      // Circle projected representation
      const centerProj = projectPoint(px, py, pz);
      // Perspective radius scaling based on depth
      const radius = (sx / 2) * scale * (1 - centerProj.zDepth / 1000);

      itemsToRender.push({
        id: `sphere-${index}`,
        elementType: 'circle',
        points: '',
        avgDepth: centerProj.zDepth,
        color: shape.color,
        opacity: opacity,
        circleProps: { cx: centerProj.x, cy: centerProj.y, r: Math.max(5, radius) }
      });
    } else if (shape.type === 'cylinder' || shape.type === 'cone') {
      // Cylinder with top circle, base circle, and body panels
      const steps = 12;
      const baseVertices: [number, number, number][] = [];
      const topVertices: [number, number, number][] = [];

      for (let i = 0; i < steps; i++) {
        const angle = (i * 2 * Math.PI) / steps;
        const rx = (sx / 2) * Math.cos(angle);
        const rz = (sz / 2) * Math.sin(angle);
        baseVertices.push([px + rx, py - sy/2, pz + rz]);
        topVertices.push([shape.type === 'cone' ? px : px + rx, py + sy/2, pz + rz]);
      }

      // Render side panels
      for (let i = 0; i < steps; i++) {
        const nextIdx = (i + 1) % steps;
        const face = [
          baseVertices[i], baseVertices[nextIdx],
          topVertices[nextIdx], topVertices[i]
        ];

        const projected = face.map(([x, y, z]) => projectPoint(x, y, z));
        const avgDepth = projected.reduce((sum, pt) => sum + pt.zDepth, 0) / projected.length;
        const pointsStr = projected.map(pt => `${pt.x},${pt.y}`).join(' ');
        const shadeFactor = 0.75 + Math.sin((i / steps) * Math.PI) * 0.15;

        itemsToRender.push({
          id: `cyl-${index}-panel-${i}`,
          elementType: 'polygon',
          points: pointsStr,
          avgDepth,
          color: shape.color,
          opacity: opacity * shadeFactor,
          strokeColor: shape.color
        });
      }

      // Add top lid (for cylinder)
      if (shape.type === 'cylinder') {
        const topProjected = topVertices.map(([x, y, z]) => projectPoint(x, y, z));
        const topDepth = topProjected.reduce((sum, pt) => sum + pt.zDepth, 0) / steps;
        const topPointsStr = topProjected.map(pt => `${pt.x},${pt.y}`).join(' ');

        itemsToRender.push({
          id: `cyl-${index}-top`,
          elementType: 'polygon',
          points: topPointsStr,
          avgDepth: topDepth + 1, // Slightly higher priority
          color: shape.color,
          opacity: opacity * 1.05,
          strokeColor: '#ffffff'
        });
      }
    } else if (shape.type === 'ring' || shape.type === 'torus') {
      // Ring consists of a series of line-segments or polygons
      const steps = 18;
      const rOuter = sx / 2;
      const rInner = shape.type === 'torus' ? rOuter * 0.7 : rOuter * 0.92;

      for (let i = 0; i < steps; i++) {
        const a1 = (i * 2 * Math.PI) / steps;
        const a2 = (((i + 1) % steps) * 2 * Math.PI) / steps;

        // Vertices for the ring portion
        const p1_out = [px + rOuter * Math.cos(a1), py, pz + rOuter * Math.sin(a1)];
        const p2_out = [px + rOuter * Math.cos(a2), py, pz + rOuter * Math.sin(a2)];
        const p1_in = [px + rInner * Math.cos(a1), py, pz + rInner * Math.sin(a1)];
        const p2_in = [px + rInner * Math.cos(a2), py, pz + rInner * Math.sin(a2)];

        const face = [p1_out, p2_out, p2_in, p1_in];
        const projected = face.map(([x, y, z]) => projectPoint(x, y, z));
        const avgDepth = projected.reduce((sum, pt) => sum + pt.zDepth, 0) / projected.length;
        const pointsStr = projected.map(pt => `${pt.x},${pt.y}`).join(' ');
        const shadeFactor = 0.8 + Math.abs(Math.sin(a1)) * 0.2;

        itemsToRender.push({
          id: `ring-${index}-seg-${i}`,
          elementType: 'polygon',
          points: pointsStr,
          avgDepth,
          color: shape.color,
          opacity: opacity * shadeFactor,
          strokeColor: '#ffffff'
        });
      }
    } else if (shape.type === 'grid') {
      // Isometric bottom floor grid wireframe
      const lines = 6;
      const gSize = sx;
      const spacing = gSize / lines;
      const halfSize = gSize / 2;

      // Draw horizontal lines across grid
      for (let i = 0; i <= lines; i++) {
        const coord = -halfSize + i * spacing;

        const pStart1 = projectPoint(px + coord, py, pz - halfSize);
        const pEnd1 = projectPoint(px + coord, py, pz + halfSize);
        const d1 = (pStart1.zDepth + pEnd1.zDepth) / 2;

        itemsToRender.push({
          id: `grid-${index}-h-${i}`,
          elementType: 'line',
          points: '',
          avgDepth: d1,
          color: shape.color,
          opacity: 0.25,
          lineProps: { x1: pStart1.x, y1: pStart1.y, x2: pEnd1.x, y2: pEnd1.y }
        });

        const pStart2 = projectPoint(px - halfSize, py, pz + coord);
        const pEnd2 = projectPoint(px + halfSize, py, pz + coord);
        const d2 = (pStart2.zDepth + pEnd2.zDepth) / 2;

        itemsToRender.push({
          id: `grid-${index}-v-${i}`,
          elementType: 'line',
          points: '',
          avgDepth: d2,
          color: shape.color,
          opacity: 0.25,
          lineProps: { x1: pStart2.x, y1: pStart2.y, x2: pEnd2.x, y2: pEnd2.y }
        });
      }
    }
  });

  // Painter's algorithm: sort depth descending (render higher depth first / background elements first)
  itemsToRender.sort((a, b) => b.avgDepth - a.avgDepth);

  // Auto slow hover spin if not dragging
  useEffect(() => {
    let animationId: number;
    const spin = () => {
      if (!isDragging) {
        setYaw(prev => (prev + 0.15) % 360);
      }
      animationId = requestAnimationFrame(spin);
    };
    animationId = requestAnimationFrame(spin);
    return () => cancelAnimationFrame(animationId);
  }, [isDragging]);

  return (
    <div className="relative select-none flex flex-col items-center w-full">
      {/* 3D stage area */}
      <div
        id={`stage-${name.toLowerCase().replace(/\s+/g, '-')}`}
        className="w-full relative rounded-2xl bg-slate-900 border border-slate-800 p-4 shadow-inner overflow-hidden flex items-center justify-center cursor-grab active:cursor-grabbing group h-[340px]"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUpOrLeave}
        onMouseLeave={handleMouseUpOrLeave}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleMouseUpOrLeave}
      >
        {/* Glowing Background Radial */}
        <div 
          className="absolute inset-0 pointer-events-none opacity-20"
          style={{
            background: `radial-gradient(circle at center, ${colors[0] || '#6366f1'} 0%, transparent 65%)`
          }}
        />

        {/* Ambient Grid overlay representation */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#020617_1px,transparent_1px),linear-gradient(to_bottom,#020617_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none opacity-40" />

        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-full max-h-[300px] z-10 transition-transform duration-200"
        >
          {/* Coordinate Axes in top right */}
          <g transform="translate(410, 40)" opacity="0.6" className="pointer-events-none mb-10">
            <line x1="0" y1="0" x2="20" y2="10" stroke="#f43f5e" strokeWidth="1.5" />
            <line x1="0" y1="0" x2="-10" y2="-20" stroke="#10b981" strokeWidth="1.5" />
            <line x1="0" y1="0" x2="-20" y2="10" stroke="#0ea5e9" strokeWidth="1.5" />
            <circle cx="0" cy="0" r="2.5" fill="#f8fafc" />
            <text x="23" y="14" fill="#f43f5e" fontSize="8" fontFamily="monospace">x</text>
            <text x="-12" y="-24" fill="#10b981" fontSize="8" fontFamily="monospace">y</text>
            <text x="-30" y="14" fill="#0ea5e9" fontSize="8" fontFamily="monospace">z</text>
          </g>

          {/* Render painter-sorted 3D elements */}
          {itemsToRender.map((item) => {
            if (item.elementType === 'polygon') {
              return (
                <polygon
                  key={item.id}
                  points={item.points}
                  fill={item.color}
                  opacity={item.opacity}
                  stroke={item.strokeColor || item.color}
                  strokeWidth="0.8"
                  strokeLinejoin="round"
                />
              );
            } else if (item.elementType === 'circle' && item.circleProps) {
              const gradientId = `grad-${item.id}`;
              return (
                <g key={item.id}>
                  <defs>
                    <radialGradient id={gradientId} cx="35%" cy="35%" r="65%">
                      <stop offset="0%" stopColor="#ffffff" stopOpacity="0.4" />
                      <stop offset="100%" stopColor={item.color} stopOpacity="0" />
                    </radialGradient>
                  </defs>
                  {/* Sphere core */}
                  <circle
                    cx={item.circleProps.cx}
                    cy={item.circleProps.cy}
                    r={item.circleProps.r}
                    fill={item.color}
                    opacity={item.opacity}
                  />
                  {/* Outer glow overlay */}
                  <circle
                    cx={item.circleProps.cx}
                    cy={item.circleProps.cy}
                    r={item.circleProps.r}
                    fill={`url(#${gradientId})`}
                    opacity={item.opacity * 0.9}
                    stroke={item.color}
                    strokeWidth="0.5"
                  />
                </g>
              );
            } else if (item.elementType === 'line' && item.lineProps) {
              return (
                <line
                  key={item.id}
                  x1={item.lineProps.x1}
                  y1={item.lineProps.y1}
                  x2={item.lineProps.x2}
                  y2={item.lineProps.y2}
                  stroke={item.color}
                  strokeOpacity={item.opacity}
                  strokeWidth="1.0"
                  strokeDasharray={item.id.includes('h') ? '3 3' : undefined}
                />
              );
            }
            return null;
          })}
        </svg>

        {/* Rotation Indicators HUD */}
        <div className="absolute bottom-3 left-3 flex gap-4 text-[10px] font-mono text-slate-400 bg-slate-950/70 border border-slate-800 backdrop-blur px-2.5 py-1 rounded-md pointer-events-none">
          <div>YAW: <span className="text-emerald-400">{Math.round(yaw)}°</span></div>
          <div>PITCH: <span className="text-cyan-400">{Math.round(pitch)}°</span></div>
          <div className="hidden sm:block">SIZE: <span className="text-fuchsia-400">{displayShapes.length} specs</span></div>
        </div>

        {/* Navigation Drag Helper Hint */}
        <div className="absolute top-3 left-3 text-[10px] text-slate-500 font-sans tracking-wide pointer-events-none group-hover:text-slate-300 transition-colors duration-200">
          ✦ Drag to tilt viewport
        </div>

        {/* Preset Scale Controls */}
        <div className="absolute right-3 bottom-3 flex gap-1 bg-slate-950/70 border border-slate-800 p-0.5 rounded-lg z-20">
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); setScale(prev => Math.max(0.6, prev - 0.1)); }}
            className="w-5 h-5 flex items-center justify-center text-xs font-bold text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
            title="Zoom Out"
          >
            -
          </button>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); setScale(1.1); setYaw(-35); setPitch(20); }}
            className="w-5 h-5 flex items-center justify-center text-[9px] font-mono text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
            title="Reset Scale"
          >
            1x
          </button>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); setScale(prev => Math.min(2.0, prev + 0.1)); }}
            className="w-5 h-5 flex items-center justify-center text-xs font-bold text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
            title="Zoom In"
          >
            +
          </button>
        </div>
      </div>

      {/* Info card underneath visualizer stage */}
      <div className="w-full mt-3 bg-slate-900/40 border border-slate-800 p-3 rounded-xl flex items-center justify-between text-xs font-sans text-slate-300">
        <div>
          <span className="text-slate-500 block text-[9px] uppercase tracking-wider">Concept Conception</span>
          <span className="font-semibold text-slate-200">{name}</span>
        </div>
        <div className="flex gap-1.5 items-center">
          {colors.slice(0, 4).map((c, i) => (
            <span
              key={i}
              className="w-3.5 h-3.5 rounded-full border border-slate-700/50 shadow-sm transition-transform duration-200 hover:scale-110"
              style={{ backgroundColor: c }}
              title={c}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
