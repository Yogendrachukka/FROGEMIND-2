/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Zap, 
  ChevronDown, 
  Mic, 
  ArrowUp, 
  Plus, 
  Sparkles, 
  Layers, 
  HelpCircle,
  Clock,
  Volume2
} from 'lucide-react';
import { LLMModel } from '../types';

interface PromptBarProps {
  onGenerate: (prompt: string, model: string, category: string, inspiration: string) => void;
  isLoading: boolean;
  selectedCategory: string;
  theme: 'light' | 'dark';
}

const LLM_MODELS: LLMModel[] = [
  { 
    id: 'gemini-3.5-flash', 
    name: 'Gemini 3.5 Flash', 
    provider: 'Google', 
    badge: 'Free', 
    badgeColor: 'bg-emerald-500/10 text-emerald-500' ,
    description: 'High-speed creative generation and layout reasoning (Recommended).',
    speed: 5,
    quality: 3,
    status: 'Cloud',
    latency: '0.4s'
  },
  { 
    id: 'gemini-3.1-pro-preview', 
    name: 'Gemini 3.1 Pro', 
    provider: 'Google', 
    badge: 'Pro', 
    badgeColor: 'bg-indigo-500/10 text-indigo-500',
    description: 'Deep complex reasoning for ultra-creative, geometric structures.',
    speed: 4,
    quality: 5,
    status: 'Cloud',
    latency: '0.8s'
  },
  { 
    id: 'gemini-3.1-flash-lite', 
    name: 'Gemini 3.1 Lite', 
    provider: 'Google', 
    badge: 'Free', 
    badgeColor: 'bg-amber-500/10 text-amber-500',
    description: 'Low-latency generator focused on basic low-poly assets.',
    speed: 5,
    quality: 2,
    status: 'Local',
    latency: '0.1s'
  }
];

const PRESETS = [
  "Holographic biome with levitating neon crystal trees",
  "Cyberpunk computer terminal displaying phosphor matrix",
  "Minimalist multi-tiered pastel temple with spiral loops",
  "Organic biosphere containing golden helix columns under glass",
  "A retro-arcade racing car floating above a mesh grid"
];

export default function PromptBar({ 
  onGenerate, 
  isLoading, 
  selectedCategory,
  theme 
}: PromptBarProps) {
  const [promptInput, setPromptInput] = useState<string>('');
  const [selectedModel, setSelectedModel] = useState<LLMModel>(LLM_MODELS[0]);
  const [showModelDropdown, setShowModelDropdown] = useState<boolean>(false);
  const [showInspirationDropdown, setShowInspirationDropdown] = useState<boolean>(false);
  const [isRecording, setIsRecording] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptInput.trim() || isLoading) return;
    onGenerate(promptInput, selectedModel.id, selectedCategory, "General Preset");
  };

  const handleSelectPreset = (preset: string) => {
    setPromptInput(preset);
    setShowInspirationDropdown(false);
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    if (!isRecording) {
      // Simulate speech-to-text input dictation
      setTimeout(() => {
        setPromptInput("A low-poly retro synthesizer floating inside a sci-fi cybernetic torus");
        setIsRecording(false);
      }, 4000);
    }
  };

  return (
    <div className="relative w-full max-w-4xl mx-auto z-40 px-2 sm:px-4">
      <form 
        onSubmit={handleSubmit}
        className={`rounded-3xl shadow-xl border p-4 transition-all duration-300 ${
          theme === 'dark'
            ? 'bg-slate-900 border-slate-800 text-white shadow-indigo-900/10 hover:border-slate-700'
            : 'bg-white border-slate-100 text-slate-800 shadow-slate-100/80 hover:border-slate-200'
        }`}
      >
        {/* Input Text Box */}
        <div className="relative mb-4">
          <textarea
            value={promptInput}
            onChange={(e) => setPromptInput(e.target.value)}
            disabled={isLoading}
            placeholder="Describe your 3D object or scene..."
            rows={2}
            className={`w-full pr-10 pl-2 py-1 text-sm bg-transparent border-0 outline-none resize-none placeholder-slate-400 focus:ring-0 ${
              theme === 'dark' ? 'text-white' : 'text-slate-800'
            }`}
          />
          {promptInput && (
            <button
              type="button"
              onClick={() => setPromptInput('')}
              className="absolute top-1 right-2 w-5 h-5 flex items-center justify-center text-xs rounded-full bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 transition-colors"
            >
              ×
            </button>
          )}
        </div>

        {/* Action Controls Pillar (Matches Image 2) */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
          <div className="flex flex-wrap items-center gap-2">
            
            {/* Template Presets trigger */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setPromptInput("A futuristic gaming capsule with curved glass panels");
                }}
                className={`w-9 h-9 rounded-xl border flex items-center justify-center transition-colors cursor-pointer ${
                  theme === 'dark' 
                    ? 'border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-white' 
                    : 'border-slate-100 text-slate-500 hover:bg-slate-50 hover:text-slate-800'
                }`}
                title="Use custom blueprint layout node"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {/* Inspiration Dropdown Selector */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setShowInspirationDropdown(!showInspirationDropdown);
                  setShowModelDropdown(false);
                }}
                className={`py-1.5 px-3.5 rounded-xl border text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                  theme === 'dark'
                    ? 'border-slate-800 hover:bg-slate-800 text-emerald-400'
                    : 'border-slate-100 hover:bg-slate-50 text-emerald-600 bg-emerald-50/20'
                }`}
              >
                <Zap className="w-3.5 h-3.5 fill-emerald-500 stroke-none" />
                <span>Inspiration</span>
                <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${showInspirationDropdown ? 'rotate-180' : ''}`} />
              </button>

              {/* Inspiration list menu */}
              {showInspirationDropdown && (
                <div className={`absolute bottom-full mb-2 left-0 w-80 rounded-2xl p-2 border shadow-2xl z-50 animate-in fade-in slide-in-from-bottom-2 ${
                  theme === 'dark' ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-100 text-slate-850'
                }`}>
                  <div className="px-3 py-1.5 text-[10px] uppercase font-mono tracking-widest text-slate-400 border-b border-slate-100 dark:border-slate-800/50 mb-1">
                    Creative Ideas Presets
                  </div>
                  <div className="space-y-1">
                    {PRESETS.map((preset, index) => (
                      <button
                        key={index}
                        type="button"
                        onClick={() => handleSelectPreset(preset)}
                        className={`w-full text-left p-2 rounded-xl text-xs transition-colors flex items-start gap-2 ${
                          theme === 'dark' ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <Sparkles className="w-3.5 h-3.5 mt-0.5 text-indigo-400 flex-shrink-0" />
                        <span>{preset}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Switch LLM Model Option Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setShowModelDropdown(!showModelDropdown);
                  setShowInspirationDropdown(false);
                }}
                className={`py-1.5 px-3.5 rounded-xl border text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                  theme === 'dark'
                    ? 'border-slate-800 hover:bg-slate-800 text-indigo-400 bg-slate-950'
                    : 'border-slate-100 hover:bg-slate-50 text-slate-700 bg-slate-50'
                }`}
              >
                <span>{selectedModel.name}</span>
                <span className={`text-[9px] px-1 rounded ${selectedModel.badgeColor}`}>
                  {selectedModel.badge}
                </span>
                <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${showModelDropdown ? 'rotate-180' : ''}`} />
              </button>

              {/* LLM Models Popup list */}
              {showModelDropdown && (
                <div className={`absolute bottom-full mb-2 right-0 sm:left-0 w-72 rounded-2xl p-2 border shadow-2xl z-50 animate-in fade-in slide-in-from-bottom-2 ${
                  theme === 'dark' ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-100 text-slate-850'
                }`}>
                  <div className="px-3 py-1.5 text-[10px] uppercase font-mono tracking-widest text-slate-400 border-b border-slate-100 dark:border-slate-800/50 mb-1">
                    Select FrogeMind Model
                  </div>
                  <div className="space-y-0.5">
                    {LLM_MODELS.map((model) => (
                      <button
                        key={model.id}
                        type="button"
                        onClick={() => {
                          setSelectedModel(model);
                          setShowModelDropdown(false);
                        }}
                        className={`w-full text-left p-2.5 rounded-xl transition-all flex flex-col gap-0.5 ${
                          selectedModel.id === model.id
                            ? (theme === 'dark' ? 'bg-indigo-600/10 text-white' : 'bg-indigo-50 text-indigo-900 font-medium')
                            : (theme === 'dark' ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-50 text-slate-700')
                        }`}
                      >
                        <div className="flex items-center justify-between w-full">
                          <span className="text-xs font-semibold">{model.name}</span>
                          <span className={`text-[8.5px] px-1 rounded ${model.badgeColor}`}>
                            {model.badge}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400 block font-normal leading-relaxed">
                          {model.description}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

          </div>

          <div className="flex items-center gap-2">
            
            {/* Audio Voice feedback button */}
            <button
              type="button"
              onClick={toggleRecording}
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                isRecording 
                  ? 'bg-red-500 text-white animate-pulse' 
                  : (theme === 'dark'
                      ? 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600')
              }`}
              title="Dictate with voice prompt"
            >
              <Mic className="w-4 h-4" />
            </button>

            {/* SEND button */}
            <button
              type="submit"
              disabled={!promptInput.trim() || isLoading}
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
                promptInput.trim() && !isLoading
                  ? 'bg-slate-900 text-white hover:bg-slate-850 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white'
                  : 'bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-600'
              }`}
            >
              <ArrowUp className="w-4 h-4 stroke-[3]" />
            </button>

          </div>
        </div>
      </form>

      {/* recording status container */}
      {isRecording && (
        <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-slate-900/95 border border-slate-800 px-4 py-2 rounded-full text-slate-200 text-xs shadow-xl backdrop-blur-md animate-bounce z-50">
          <Volume2 className="w-4 h-4 text-red-500 animate-pulse" />
          <span>I am listening. Whisper your prompt ideas...</span>
          <div className="flex gap-0.5 items-end h-3 pl-1">
            <span className="w-0.5 h-1.5 bg-red-400 animate-[bounce_1s_infinite_0s]" />
            <span className="w-0.5 h-3 bg-red-400 animate-[bounce_1s_infinite_0.15s]" />
            <span className="w-0.5 h-2 bg-red-400 animate-[bounce_1s_infinite_0.3s]" />
            <span className="w-0.5 h-0.5 bg-red-400 animate-[bounce_1s_infinite_0.45s]" />
          </div>
        </div>
      )}
    </div>
  );
}
