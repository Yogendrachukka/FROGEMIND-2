/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState } from 'react';
import { 
  Users, 
  Wallet, 
  ArrowUpRight, 
  ArrowDownRight,
  Search,
  Plus,
  Bell,
  MessageCircle,
  ChevronDown,
  ChevronRight,
  TrendingUp,
  Clock,
  ExternalLink,
  Bot
} from 'lucide-react';
import { GeneratedAsset, ProductItem, CommentItem } from '../types';
import AssetVisualizer from './AssetVisualizer';

interface DashboardProps {
  currentCategory: string;
  onOpenCreate: () => void;
  generatedAssets: GeneratedAsset[];
  popularProducts: ProductItem[];
  comments: CommentItem[];
  theme: 'light' | 'dark';
}

export default function Dashboard({
  currentCategory,
  onOpenCreate,
  generatedAssets,
  popularProducts,
  comments,
  theme
}: DashboardProps) {
  const [selectedChartBarIdx, setSelectedChartBarIdx] = useState<number>(5); // Index 5 matches highlighted active bar in Mockup 1
  const [activeAssetPreview, setActiveAssetPreview] = useState<GeneratedAsset | null>(null);

  // Filter generated assets to only show under current category
  const filteredAssets = generatedAssets.filter(
    asset => asset.category.toLowerCase() === currentCategory.toLowerCase()
  );

  // Dummy monthly analytics bar chart data to render exact mock shape
  const chartData = [
    { label: 'Mon', value: '1.2m', height: 40 },
    { label: 'Tue', value: '1.5m', height: 60 },
    { label: 'Wed', value: '0.8m', height: 35 },
    { label: 'Thu', value: '2.4m', height: 95 },
    { label: 'Fri', value: '1.1m', height: 50 },
    { label: 'Sat', value: '2.2m', height: 110 }, // Target Highlighted Green Bar in Image 1
    { label: 'Sun', value: '1.7m', height: 75 },
    { label: 'Mon2', value: '1.9m', height: 85 },
    { label: 'Tue2', value: '2.5m', height: 115 },
  ];

  const handleBarClick = (idx: number) => {
    setSelectedChartBarIdx(idx);
  };

  return (
    <div className={`flex-1 p-4 sm:p-7 overflow-y-auto ${
      theme === 'dark' ? 'bg-[#0f172a] text-[#f8fafc]' : 'bg-[#f4f5f6] text-[#1e293b]'
    }`}>
      
      {/* Top Header Block: Search, Create, Profiles */}
      <header className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight">Dashboard</h1>
          <span className="text-xs text-slate-400 font-mono">WORKSPACE ID: 04F7E6AA</span>
        </div>

        <div className="flex items-center flex-wrap gap-3.5 w-full sm:w-auto">
          {/* Mock Search Bar (Matches Image 1 Search Anything) */}
          <div className={`relative flex-1 sm:w-60 ${
            theme === 'dark' ? 'bg-[#1e293b]/60' : 'bg-white'
          } rounded-full py-2.5 px-4 flex items-center gap-2 border ${
            theme === 'dark' ? 'border-[#334155]/50' : 'border-slate-200/60'
          }`}>
            <Search className="w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search anything..." 
              className="bg-transparent text-xs w-full focus:outline-none placeholder-slate-400"
            />
          </div>

          {/* Create Floating Prompt Input trigger */}
          <button
            type="button"
            onClick={onOpenCreate}
            className="bg-slate-900 hover:bg-slate-800 text-white dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100 py-2.5 px-5 rounded-full text-xs font-semibold shadow-sm flex items-center gap-1.5 transition-all cursor-pointer hover:scale-105"
          >
            <Plus className="w-3.5 h-3.5 stroke-[3]" />
            <span>Create</span>
          </button>

          {/* Social Icons */}
          <div className="flex items-center gap-1.5">
            <button className={`w-9 h-9 flex items-center justify-center rounded-full border ${
              theme === 'dark' ? 'border-slate-800 text-slate-300' : 'border-slate-200 text-slate-600'
            } bg-white dark:bg-[#1e293b]/30`}>
              <Bell className="w-4 h-4" />
            </button>
            <button className={`w-9 h-9 flex items-center justify-center rounded-full border ${
              theme === 'dark' ? 'border-slate-800 text-slate-300' : 'border-slate-200 text-slate-600'
            } bg-white dark:bg-[#1e293b]/30`}>
              <MessageCircle className="w-4 h-4" />
            </button>
          </div>

          {/* Avatar Profile */}
          <div className="flex items-center gap-2 border-l border-slate-300 dark:border-slate-700 pl-3.5">
            <img 
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80" 
              alt="Yogendra portrait user" 
              className="w-8 h-8 rounded-full border border-indigo-500/30 object-cover" 
            />
          </div>
        </div>
      </header>

      {/* Main Grid: split left content section from right static panels */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        
        {/* Left Double Columns: Stats, Product view chart, categories */}
        <div className="lg:col-span-2 flex flex-col gap-6">

          {/* Overview Section Card */}
          <section className={`p-5 sm:p-6 rounded-3xl border ${
            theme === 'dark' ? 'bg-[#1b2234] border-[#313b53]' : 'bg-white border-slate-200/50'
          } shadow-sm flex flex-col gap-5`}>
            
            <div className="flex justify-between items-center">
              <h2 className="text-sm font-semibold tracking-tight text-slate-400 uppercase font-mono">Overview</h2>
              <div className="flex gap-1.5">
                <span className={`text-xs px-2.5 py-1 rounded-full border ${
                  theme === 'dark' ? 'border-slate-800 text-slate-300 bg-slate-900' : 'border-slate-100 text-slate-600 bg-slate-50'
                } flex items-center gap-1 font-medium`}>
                  <span>Last month</span>
                  <ChevronDown className="w-3 h-3" />
                </span>
              </div>
            </div>

            {/* Split Customers / Balance */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Customers card */}
              <div className={`p-5 rounded-2xl ${
                theme === 'dark' ? 'bg-[#1e293b]/40 border border-[#334155]/40' : 'bg-[#fafafa]'
              }`}>
                <div className="flex items-center gap-2 text-slate-400 text-xs mb-3 font-medium">
                  <Users className="w-4 h-4 text-slate-500" />
                  <span>Customers</span>
                </div>
                <div className="flex items-baseline gap-3.5 flex-wrap">
                  <span className="text-3xl sm:text-4xl font-semibold tracking-tight">1,293</span>
                  <span className="flex items-center gap-0.5 text-xs text-rose-500 bg-rose-500/10 px-2 py-0.5 rounded-full font-semibold">
                    <ArrowDownRight className="w-3.5 h-3.5" />
                    <span>36.8%</span>
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">vs last month</span>
                </div>
              </div>

              {/* Balance card */}
              <div className={`p-5 rounded-2xl ${
                theme === 'dark' ? 'bg-[#1e293b]/40 border border-[#334155]/40' : 'bg-[#fafafa]'
              }`}>
                <div className="flex items-center gap-2 text-slate-400 text-xs mb-3 font-medium">
                  <Wallet className="w-4 h-4 text-slate-500" />
                  <span>Balance</span>
                </div>
                <div className="flex items-baseline gap-3.5 flex-wrap">
                  <span className="text-3xl sm:text-4xl font-semibold tracking-tight">256k</span>
                  <span className="flex items-center gap-0.5 text-xs text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full font-semibold">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    <span>36.8%</span>
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">vs last month</span>
                </div>
              </div>
            </div>

            {/* Sub informational panel under Overview (857 new customers today) */}
            <div className={`p-4 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
              theme === 'dark' ? 'bg-[#162a35] text-teal-200 border border-teal-850' : 'bg-[#f4ebe6]/40 text-[#4c3427]'
            }`}>
              <div className="flex flex-col gap-0.5">
                <span className="text-sm font-semibold">857 new customers today!</span>
                <span className="text-[11px] text-slate-400 leading-relaxed">Send a welcoming prompt to organize their asset pipelines.</span>
              </div>
              
              {/* Avatar stack */}
              <div className="flex items-center gap-1.5 self-stretch sm:self-auto justify-end">
                <div className="flex -space-x-2.5">
                  <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=80&q=80" alt="Gladyce" className="w-7 h-7 rounded-full border-2 border-white dark:border-slate-900 object-cover" />
                  <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=80&q=80" alt="Elbert" className="w-7 h-7 rounded-full border-2 border-white dark:border-slate-900 object-cover" />
                  <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=80&q=80" alt="Dash" className="w-7 h-7 rounded-full border-2 border-white dark:border-slate-900 object-cover" />
                  <img src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=80&q=80" alt="Joyce" className="w-7 h-7 rounded-full border-2 border-white dark:border-slate-900 object-cover" />
                </div>
                <button type="button" className={`ml-2 text-[10px] font-semibold tracking-wide uppercase px-2 py-1 rounded-full ${
                  theme === 'dark' ? 'bg-[#334155]/60 hover:bg-[#334155]' : 'bg-slate-200 hover:bg-slate-300'
                } transition-colors`}>
                  View all
                </button>
              </div>
            </div>
          </section>

          {/* Product View Chart Card (Matches Image 1 layout) */}
          <section className={`p-5 sm:p-6 rounded-3xl border relative overflow-hidden ${
            theme === 'dark' ? 'bg-[#1b2234] border-[#313b53]' : 'bg-white border-slate-200/50'
          } shadow-sm`}>
            
            <div className="flex justify-between items-center mb-6 relative z-10">
              <h2 className="text-sm font-semibold tracking-tight text-slate-400 uppercase font-mono">Product view</h2>
              <span className={`text-xs px-2.5 py-1 rounded-full border ${
                theme === 'dark' ? 'border-slate-800 text-slate-300 bg-slate-900' : 'border-slate-100 text-slate-600 bg-slate-50'
              } flex items-center gap-1`}>
                <span>Last 7 days</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </span>
            </div>

            {/* Massive background translucent "$10.2m" text */}
            <div className="absolute left-6 bottom-16 select-none pointer-events-none">
              <span className="text-7xl sm:text-[144px] font-bold tracking-tight opacity-[0.06] sm:opacity-[0.05] block font-sans">
                $10.2m
              </span>
            </div>

            {/* Render Horizontal Bars list with highlighted green custom block */}
            <div className="relative h-44 flex items-end justify-between px-2 sm:px-6 z-10 pt-10">
              {chartData.map((bar, idx) => {
                const isSelected = selectedChartBarIdx === idx;
                return (
                  <div 
                    key={idx} 
                    className="flex flex-col items-center h-full justify-end group cursor-pointer w-[6%] sm:w-[8%]"
                    onClick={() => handleBarClick(idx)}
                  >
                    {/* Floating dark tooltip on selection / highlight */}
                    {isSelected && (
                      <div className="absolute bottom-[115px] bg-slate-900 text-white font-mono text-[9px] px-2 py-1 rounded-lg shadow-lg flex flex-col items-center justify-center animate-bounce z-20">
                        <span className="font-bold">{bar.value}</span>
                        <div className="w-1.5 h-1.5 bg-slate-900 rotate-45 mt-[-3px] absolute bottom-[-3px]" />
                      </div>
                    )}
                    
                    {/* Vertical pillar bar of chart */}
                    <div 
                      className={`w-full rounded-full transition-all duration-300 ${
                        isSelected 
                          ? 'bg-emerald-500 shadow-lg shadow-emerald-500/30' 
                          : 'bg-slate-200 dark:bg-[#334155]/30 group-hover:bg-slate-300 dark:group-hover:bg-[#334155]/60'
                      }`}
                      style={{ height: `${bar.height}px` }}
                    />
                    
                    <span className="text-[9px] text-slate-400 font-mono mt-2 uppercase block">
                      {bar.label.substring(0, 3)}
                    </span>
                  </div>
                );
              })}
            </div>
          </section>

          {/* Category-scoped Generated Assets Preview Panel */}
          {filteredAssets.length > 0 && (
            <section className={`p-5 rounded-3xl border ${
              theme === 'dark' ? 'bg-[#1b2234] border-[#313b53]' : 'bg-white border-slate-200/50'
            } shadow`}>
              <div className="flex items-center gap-2 mb-4">
                <Bot className="w-4 h-4 text-indigo-500" />
                <span className="text-xs font-semibold tracking-wider font-mono text-slate-400 uppercase">
                  My Custom Generated {currentCategory}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredAssets.map((asset) => (
                  <div 
                    key={asset.id}
                    onClick={() => setActiveAssetPreview(asset)}
                    className={`p-4 rounded-xl border transition-all cursor-pointer ${
                      theme === 'dark'
                        ? 'bg-slate-900/60 border-slate-800 hover:border-indigo-500/50 hover:bg-slate-900'
                        : 'bg-slate-50 border-slate-100 hover:border-indigo-400/40 hover:bg-white'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3 mb-2.5">
                      <div>
                        <span className="font-bold text-xs sm:text-sm text-slate-800 dark:text-slate-100 block">
                          {asset.name}
                        </span>
                        <p className="text-[10px] text-slate-400 font-mono">
                          Modeled: {asset.modelUsed}
                        </p>
                      </div>
                      <span className="text-xs font-semibold font-mono text-indigo-500">
                        {asset.price}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 leading-relaxed line-clamp-2">
                      {asset.description}
                    </p>
                    <div className="mt-2.5 flex items-center justify-between text-[10px] font-mono text-slate-400">
                      <span>{asset.shapes.length} geometry specs</span>
                      <span className="text-indigo-400 flex items-center gap-1 hover:underline">
                        Interact 3D
                        <ExternalLink className="w-2.5 h-2.5" />
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

        </div>

        {/* Right Columns: Popular products, comments */}
        <div className="flex flex-col gap-6">

          {/* Popular Products Sidebar card (Matches Image 1 right list) */}
          <section className={`p-5 sm:p-6 rounded-3xl border ${
            theme === 'dark' ? 'bg-[#1b2234] border-[#313b53]' : 'bg-white border-slate-200/50'
          } shadow-sm`}>
            
            <div className="flex justify-between items-center mb-5">
              <h2 className="text-sm font-semibold tracking-tight uppercase font-mono text-slate-400">Popular products</h2>
            </div>

            <div className="flex flex-col gap-3.5">
              {popularProducts.map((p) => (
                <div 
                  key={p.id} 
                  className={`flex items-center justify-between p-2.5 rounded-xl border ${
                    theme === 'dark' ? 'border-[#334155]/30 hover:bg-slate-800/25' : 'border-slate-100 hover:bg-[#fafafa]'
                  } transition-colors`}
                >
                  <div className="flex items-center gap-3">
                    {/* Aesthetic visual thumbnail placeholder representation */}
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold text-xs shadow-sm bg-gradient-to-tr from-slate-800 to-slate-950 text-white border border-slate-700/55`}>
                      <span className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: p.imagePlaceholderColor }} />
                    </div>
                    
                    <div>
                      <span className="font-bold text-xs sm:text-[13px] block leading-tight">{p.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{p.category}</span>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <span className="text-xs font-semibold font-mono block mb-1">{p.price}</span>
                    <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded-md font-semibold ${
                      p.status === 'Active' 
                        ? 'bg-emerald-500/10 text-emerald-500' 
                        : 'bg-amber-500/10 text-amber-500/90'
                    }`}>
                      {p.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <button
              type="button"
              className="w-full text-center py-2.5 border border-slate-200/80 dark:border-slate-800 rounded-xl text-xs font-semibold text-slate-500 hover:text-indigo-505 transition-colors cursor-pointer mt-4"
            >
              All products
            </button>
          </section>

          {/* Comments Sidebar card (Matches Image 1 bottom right list) */}
          <section className={`p-5 sm:p-6 rounded-3xl border ${
            theme === 'dark' ? 'bg-[#1b2234] border-[#313b53]' : 'bg-white border-slate-200/50'
          } shadow-sm`}>
            
            <h2 className="text-sm font-semibold tracking-tight uppercase font-mono text-slate-400 mb-5">Comments</h2>

            <div className="flex flex-col gap-4">
              {comments.map((comment) => (
                <div 
                  key={comment.id} 
                  className={`p-3 rounded-xl border ${
                    theme === 'dark' ? 'bg-[#111827]/40 border-slate-800/50' : 'bg-[#fafafa] border-transparent'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2.5 mb-2.5">
                    <div className="flex items-center gap-2">
                      <img 
                        src={comment.avatar} 
                        alt={comment.user} 
                        className="w-6 h-6 rounded-full border border-slate-300 dark:border-slate-800 object-cover" 
                      />
                      <span className="text-xs font-semibold leading-tight block">
                        {comment.user} <span className="font-normal text-slate-400 font-sans text-[10px]">on {comment.targetProduct}</span>
                      </span>
                    </div>
                    <span className="text-[9px] text-slate-400 font-mono shrink-0">{comment.time}</span>
                  </div>
                  
                  <p className="text-[11px] text-slate-500 leading-relaxed font-sans pr-2">
                    {comment.text}
                  </p>
                </div>
              ))}
            </div>
          </section>

        </div>

      </div>

      {/* Model Asset interactive Modal preview screen */}
      {activeAssetPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in transition-all">
          <div className={`w-full max-w-xl rounded-2xl border p-6 shadow-2xl relative ${
            theme === 'dark' ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-850'
          }`}>
            <button
              onClick={() => setActiveAssetPreview(null)}
              className="absolute top-4 right-4 text-xs font-mono font-bold w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center hover:scale-105 transition-transform"
            >
              ×
            </button>

            <h3 className="text-lg font-bold mb-1">{activeAssetPreview.name}</h3>
            <span className="text-[10px] font-mono uppercase text-indigo-500 bg-indigo-500/10 px-2 py-0.5 rounded">
              {activeAssetPreview.category}
            </span>

            <p className="text-xs text-slate-400 mt-3 mb-5 leading-relaxed">
              {activeAssetPreview.description}
            </p>

            {/* Custom 3D interactive Canvas/SVG visualizer stage */}
            <div className="mb-4">
              <AssetVisualizer 
                shapes={activeAssetPreview.shapes} 
                colors={activeAssetPreview.colors} 
                name={activeAssetPreview.name} 
              />
            </div>

            <div className="flex items-center justify-between border-t border-slate-100 dark:border-slate-800 pt-4 mt-4">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-mono block">Estimated Value</span>
                <span className="text-lg font-black font-mono text-emerald-500">{activeAssetPreview.price}</span>
              </div>
              <button
                type="button"
                onClick={() => setActiveAssetPreview(null)}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs py-2 px-4 rounded-xl shadow transition-colors"
              >
                Done Previewing
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
