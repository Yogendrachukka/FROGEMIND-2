/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Search, 
  Layers, 
  PenTool, 
  FileCode, 
  Paintbrush, 
  Activity, 
  TrendingUp, 
  Zap, 
  CheckCircle2, 
  Grid,
  TrendingDown,
  Compass
} from 'lucide-react';
import { MarketplaceTool } from '../../types';

interface ToolsMarketplaceProps {
  onInstallPlugin: (name: string) => void;
  installedList: string[];
}

export default function ToolsMarketplace({ onInstallPlugin, installedList }: ToolsMarketplaceProps) {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchVal, setSearchVal] = useState<string>('');

  const toolsRepo: MarketplaceTool[] = [
    {
      id: "tool-1",
      name: "Document Summarizer",
      description: "Elegant, zero-jargon summarizer optimized for drafting long-form essays, user stories, and summaries.",
      category: "Writing",
      badge: "Free Sandbox",
      popularity: 910,
      apiCost: "$0.00 / prompt",
      iconName: "PenTool"
    },
    {
      id: "tool-2",
      name: "TypeScript Code Generator",
      description: "Injects clean type declarations and interface blocks inside modular codebases based on natural description trees.",
      category: "Coding",
      badge: "Pro",
      popularity: 1850,
      apiCost: "$0.02 / run",
      iconName: "FileCode"
    },
    {
      id: "tool-3",
      name: "SVG Drawing Generator",
      description: "Generates custom relative coordinates, responsive CSS styling, and visual SVG vectors matching detailed prompts.",
      category: "Image generation",
      badge: "Priority Access",
      popularity: 3200,
      apiCost: "$0.05 / render",
      iconName: "Paintbrush"
    },
    {
      id: "tool-4",
      name: "Fact Checker & Website Search",
      description: "Cross-checks web databases, Wikipedia resources, and literature logs to verify reasoning validity.",
      category: "Research",
      badge: "Pro",
      popularity: 820,
      apiCost: "$0.01 / query",
      iconName: "Compass"
    },
    {
      id: "tool-5",
      name: "Smart Calendar Planner",
      description: "Coordinates timeline maps, calendars, schedules, and blocks times dynamically in a clean list format.",
      category: "Productivity",
      badge: "Free Sandbox",
      popularity: 1400,
      apiCost: "$0.00 / free",
      iconName: "Layers"
    },
    {
      id: "tool-6",
      name: "Automated Webhook Sender",
      description: "Dispatches automated callback signals and JSON payloads across connected personal endpoints.",
      category: "Automation",
      badge: "Enterprise",
      popularity: 250,
      apiCost: "$0.10 / callback",
      iconName: "Zap"
    }
  ];

  // Filters out categories
  const filteredTools = toolsRepo.filter(tool => {
    if (activeCategory !== 'all' && tool.category !== activeCategory) return false;
    if (searchVal.trim() !== '') {
      const q = searchVal.toLowerCase();
      return (
        tool.name.toLowerCase().includes(q) ||
        tool.description.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="flex-1 overflow-y-auto bg-white p-6 sm:p-8 text-slate-800 font-sans select-none">
      
      {/* Top Header Row */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-150 pb-6 mb-8 mt-2">
        <div>
          <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-emerald-600">Available Plugins</span>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            App Plugins & Tools
          </h1>
          <p className="text-slate-500 text-xs mt-1.5 leading-relaxed">
            Browse, turn on, and use helpful extensions like web searches or text helpers inside your active chats.
          </p>
        </div>

        {/* Action input filter */}
        <div className="relative">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            value={searchVal}
            onChange={(e) => setSearchVal(e.target.value)}
            placeholder="Search active tools..." 
            className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-205 focus:border-emerald-450 rounded-xl text-xs text-slate-700 outline-none w-60 focus:bg-white transition-all placeholder:text-slate-400 font-sans font-medium"
          />
        </div>
      </div>

      {/* Categories chips filter ribbon */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-50 border border-slate-200/60 rounded-2xl max-w-3xl mb-8">
        {['all', 'Writing', 'Coding', 'Image generation', 'Research', 'Productivity', 'Automation'].map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-2 rounded-xl text-[10px] font-mono font-bold transition-all cursor-pointer ${
              activeCategory === cat
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'border border-transparent text-slate-500 hover:text-slate-850'
            }`}
          >
            {cat.toUpperCase()}
          </button>
        ))}
      </div>

      {/* Main Tools Catalog Grid Layout */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {filteredTools.map((tool) => {
          const isInstalled = installedList.includes(tool.name);

          return (
            <div 
              key={tool.id}
              className={`p-5 rounded-2xl border bg-white transition-all duration-200 flex flex-col justify-between relative ${
                isInstalled 
                  ? 'border-emerald-300 bg-emerald-50/10 shadow-md' 
                  : 'border-slate-100 hover:border-slate-200 shadow-xs'
              }`}
            >
              
              {/* Category flag & popularity index */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[9px] font-mono font-bold text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded-full uppercase">
                    {tool.category}
                  </span>
                  
                  <div className="flex items-center gap-1 text-[10.5px] font-mono text-emerald-600 font-bold">
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
                    <span>{tool.popularity} installs</span>
                  </div>
                </div>

                {/* Name */}
                <h3 className="text-sm font-bold text-slate-800 mb-2 flex items-center justify-between">
                  <span>{tool.name}</span>
                  {isInstalled && (
                    <span className="text-[9px] font-mono text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-100 font-bold leading-none">
                      Active
                    </span>
                  )}
                </h3>

                {/* Description */}
                <p className="text-[11px] text-slate-500 leading-relaxed mb-6 min-h-[48px]">
                  {tool.description}
                </p>

                {/* Metadata detail summary */}
                <div className="space-y-2 border-t border-slate-100 pt-3 mb-6">
                  <div className="flex justify-between items-center text-[10.5px] font-mono text-slate-450 font-bold">
                    <span>Cost per use:</span>
                    <span className="text-slate-750 font-semibold">{tool.apiCost}</span>
                  </div>
                  <div className="flex justify-between items-center text-[10.5px] font-mono text-slate-450 font-bold">
                    <span>Required Plan:</span>
                    <span className="text-slate-750 font-semibold">{tool.badge}</span>
                  </div>
                </div>
              </div>

              {/* Install action trigger */}
              <button
                type="button"
                onClick={() => onInstallPlugin(tool.name)}
                className={`w-full py-2.5 rounded-xl text-xs font-bold font-sans transition-all cursor-pointer border ${
                  isInstalled 
                    ? 'bg-emerald-50 text-emerald-600 border-emerald-200 hover:bg-emerald-100' 
                    : 'bg-slate-900 text-white hover:bg-slate-800 border-transparent'
                }`}
              >
                {isInstalled ? 'Activated (Click to Turn Off)' : 'Activate Plugin'}
              </button>

            </div>
          );
        })}

      </div>

    </div>
  );
}
