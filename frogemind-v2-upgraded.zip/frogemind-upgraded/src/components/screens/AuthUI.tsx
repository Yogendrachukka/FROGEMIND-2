/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Lock, 
  Mail, 
  User, 
  ArrowLeft, 
  CheckCircle2, 
  ShieldAlert,
  Loader2,
  ShieldCheck,
  Eye,
  EyeOff,
  Phone,
  ExternalLink,
  Copy,
  Check
} from 'lucide-react';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  GithubAuthProvider,
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signInWithPhoneNumber,
  RecaptchaVerifier,
  updateProfile,
  ConfirmationResult
} from 'firebase/auth';
import { auth, db } from '../../firebase';
import { doc, setDoc } from 'firebase/firestore';

const COUNTRY_CODES = [
  { code: '+1', name: 'US/CA', flag: '🇺🇸' },
  { code: '+91', name: 'IN', flag: '🇮🇳' },
  { code: '+44', name: 'GB', flag: '🇬🇧' },
  { code: '+61', name: 'AU', flag: '🇦🇺' },
  { code: '+81', name: 'JP', flag: '🇯🇵' },
  { code: '+49', name: 'DE', flag: '🇩🇪' },
  { code: '+33', name: 'FR', flag: '🇫🇷' },
  { code: '+55', name: 'BR', flag: '🇧🇷' },
  { code: '+86', name: 'CN', flag: '🇨🇳' },
  { code: '+65', name: 'SG', flag: '🇸🇬' },
  { code: '+971', name: 'AE', flag: '🇦🇪' },
  { code: '+7', name: 'RU', flag: '🇷🇺' },
  { code: '+34', name: 'ES', flag: '🇪🇸' },
  { code: '+39', name: 'IT', flag: '🇮🇹' },
  { code: '+27', name: 'ZA', flag: '🇿🇦' },
  { code: '+52', name: 'MX', flag: '🇲🇽' },
  { code: '+82', name: 'KR', flag: '🇰🇷' },
  { code: '+62', name: 'ID', flag: '🇮🇩' },
  { code: '+60', name: 'MY', flag: '🇲🇾' },
  { code: '+63', name: 'PH', flag: '🇵🇭' },
  { code: '+66', name: 'TH', flag: '🇹🇭' },
  { code: '+84', name: 'VN', flag: '🇻🇳' },
  { code: '+92', name: 'PK', flag: '🇵🇰' },
  { code: '+880', name: 'BD', flag: '🇧🇩' },
  { code: '+90', name: 'TR', flag: '🇹🇷' },
  { code: '+20', name: 'EG', flag: '🇪🇬' },
  { code: '+234', name: 'NG', flag: '🇳🇬' },
  { code: '+54', name: 'AR', flag: '🇦🇷' },
  { code: '+56', name: 'CL', flag: '🇨🇱' },
  { code: '+57', name: 'CO', flag: '🇨🇴' },
  { code: '+31', name: 'NL', flag: '🇳🇱' },
  { code: '+41', name: 'CH', flag: '🇨🇭' },
  { code: '+46', name: 'SE', flag: '🇸🇪' },
  { code: '+47', name: 'NO', flag: '🇳🇴' },
  { code: '+45', name: 'DK', flag: '🇩🇰' },
  { code: '+353', name: 'IE', flag: '🇮🇪' },
  { code: '+64', name: 'NZ', flag: '🇳🇿' },
  { code: '+966', name: 'SA', flag: '🇸🇦' },
  { code: '+972', name: 'IL', flag: '🇮🇱' }
];

interface AuthUIProps {
  onAuthSuccess: () => void;
  onGoBack: () => void;
}

export default function AuthUI({ onAuthSuccess, onGoBack }: AuthUIProps) {
  // Tabs: 'email-login' | 'email-signup' | 'phone' | 'forgot'
  const [activeTab, setActiveTab] = useState<'email-login' | 'email-signup' | 'phone' | 'forgot'>('email-login');
  
  // Input values
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [name, setName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [selectedCountryCode, setSelectedCountryCode] = useState<string>('+1');
  const [otpCode, setOtpCode] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [rememberMe, setRememberMe] = useState<boolean>(true);

  // States
  const [loading, setLoading] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [waitingForOtp, setWaitingForOtp] = useState<boolean>(false);
  const [isNetworkError, setIsNetworkError] = useState<boolean>(false);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Recaptcha element container ref
  const recaptchaContainerRef = useRef<HTMLDivElement | null>(null);

  // Helper to copy text to clipboard with simple toast feedback
  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => {
      setCopiedText(null);
    }, 2000);
  };

  // Sync profile data to firestore database securely
  const syncUserProfile = async (uid: string, userEmail: string | null, userPhone: string | null, userDisplayName: string | null) => {
    try {
      await setDoc(doc(db, 'users', uid), {
        uid,
        email: userEmail || '',
        phone: userPhone || '',
        displayName: userDisplayName || 'FrogeMind User',
        createdAt: new Date().toISOString()
      }, { merge: true });
    } catch (e) {
      console.error('Failed to sync user profile to Firestore:', e);
    }
  };

  // Google Sign In handler
  const handleGoogleSignIn = async () => {
    setLoading(true);
    setStatusMessage(null);
    setIsNetworkError(false);
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      await syncUserProfile(result.user.uid, result.user.email, result.user.phoneNumber, result.user.displayName);
      setStatusMessage({ type: 'success', text: 'Sign in successful! Redirecting...' });
      setTimeout(() => {
        onAuthSuccess();
      }, 1000);
    } catch (error: any) {
      console.error('Google Sign In Error:', error);
      let errorMsg = 'Google authentication failed.';
      if (error.code === 'auth/operation-not-allowed' || error.code === 'auth/configuration-not-found') {
        errorMsg = 'Google login is not enabled yet in your Firebase Project configuration.';
      } else if (
        error.code === 'auth/network-request-failed' || 
        error.message?.includes('network-request-failed') ||
        error.message?.includes('auth/network')
      ) {
        setIsNetworkError(true);
        errorMsg = 'A browser sandbox or network boundary restriction blocked Google SSO. See the recovery guide below.';
      } else if (error.message) {
        errorMsg = error.message;
      }
      setStatusMessage({ type: 'error', text: errorMsg });
    } finally {
      setLoading(false);
    }
  };

  // GitHub Sign In handler
  const handleGithubSignIn = async () => {
    setLoading(true);
    setStatusMessage(null);
    setIsNetworkError(false);
    try {
      const provider = new GithubAuthProvider();
      const result = await signInWithPopup(auth, provider);
      await syncUserProfile(result.user.uid, result.user.email, result.user.phoneNumber, result.user.displayName);
      setStatusMessage({ type: 'success', text: 'Sign in successful! Redirecting...' });
      setTimeout(() => {
        onAuthSuccess();
      }, 1000);
    } catch (error: any) {
      console.error('GitHub Sign In Error:', error);
      let errorMsg = 'GitHub authentication failed.';
      if (error.code === 'auth/operation-not-allowed' || error.code === 'auth/configuration-not-found') {
        errorMsg = 'GitHub login is not enabled yet in your Firebase Project configuration.';
      } else if (
        error.code === 'auth/network-request-failed' || 
        error.message?.includes('network-request-failed') ||
        error.message?.includes('auth/network')
      ) {
        setIsNetworkError(true);
        errorMsg = 'A browser sandbox or network boundary restriction blocked GitHub SSO. See the recovery guide below.';
      } else if (error.message) {
        errorMsg = error.message;
      }
      setStatusMessage({ type: 'error', text: errorMsg });
    } finally {
      setLoading(false);
    }
  };

  // Email Sign In or Sign Up handler
  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setStatusMessage(null);

    try {
      if (activeTab === 'email-login') {
        const result = await signInWithEmailAndPassword(auth, email, password);
        await syncUserProfile(result.user.uid, result.user.email, result.user.phoneNumber, result.user.displayName);
        setStatusMessage({ type: 'success', text: 'Login successful! Welcome back.' });
        setTimeout(() => {
          onAuthSuccess();
        }, 1000);
      } else if (activeTab === 'email-signup') {
        const result = await createUserWithEmailAndPassword(auth, email, password);
        await updateProfile(result.user, { displayName: name });
        await syncUserProfile(result.user.uid, email, null, name);
        setStatusMessage({ type: 'success', text: 'Account created successfully!' });
        setTimeout(() => {
          onAuthSuccess();
        }, 1000);
      } else if (activeTab === 'forgot') {
        await sendPasswordResetEmail(auth, email);
        setStatusMessage({ type: 'success', text: 'Password reset link sent to your email.' });
      }
    } catch (error: any) {
      console.error('Email Auth Error:', error);
      let errorMsg = 'Authentication failed. Please check your credentials.';
      if (error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
        errorMsg = 'Incorrect email address or password.';
      } else if (error.code === 'auth/email-already-in-use') {
        errorMsg = 'This email address is already registered.';
      } else if (error.code === 'auth/operation-not-allowed') {
        errorMsg = 'Email/Password sign-in method is not enabled in Firebase Console.';
      } else if (error.code === 'auth/weak-password') {
        errorMsg = 'The password is too weak. Please use at least 6 characters.';
      } else if (error.message) {
        errorMsg = error.message;
      }
      setStatusMessage({ type: 'error', text: errorMsg });
    } finally {
      setLoading(false);
    }
  };

  // Initialize Recaptcha Verifier
  const setupRecaptcha = () => {
    try {
      if ((window as any).recaptchaInstance) {
        return (window as any).recaptchaInstance;
      }
      
      const verifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
        size: 'invisible',
        callback: () => {
          console.log('reCAPTCHA verified');
        }
      });
      (window as any).recaptchaInstance = verifier;
      return verifier;
    } catch (e: any) {
      console.error('reCAPTCHA init error:', e);
      return null;
    }
  };

  // Trigger Phone OTP Code Send
  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setStatusMessage(null);

    // Clean up input of common characters (spaces, dashes, parentheses)
    const cleanedNumber = phone.replace(/[\s\-\(\)]/g, '');

    if (!cleanedNumber) {
      setStatusMessage({
        type: 'error',
        text: 'Please enter a valid phone number.'
      });
      setLoading(false);
      return;
    }

    let finalPhone = cleanedNumber;
    // If user has not typed an explicit international prefix, prepend the selected one
    if (!cleanedNumber.startsWith('+')) {
      finalPhone = selectedCountryCode + cleanedNumber;
    }

    try {
      const verifier = setupRecaptcha();
      if (!verifier) {
        throw new Error('Could not initialize reCAPTCHA check.');
      }

      const result = await signInWithPhoneNumber(auth, finalPhone, verifier);
      setConfirmationResult(result);
      setWaitingForOtp(true);
      setStatusMessage({ type: 'success', text: `Verification code successfully sent to ${finalPhone}` });
    } catch (error: any) {
      console.error('Phone SMS send error:', error);
      let errorMsg = 'Failed to send SMS code.';
      
      const errorStr = (error.code || '') + ' ' + (error.message || '');
      const isOperationNotAllowed = errorStr.includes('operation-not-allowed');
      const isInvalidPhone = errorStr.includes('invalid-phone-number');

      if (isOperationNotAllowed) {
        errorMsg = 'Phone authentication is not enabled in your Firebase Console. Please go to Firebase Console > Authentication > Sign-in method, add the Phone provider, and enable it.';
      } else if (isInvalidPhone) {
        errorMsg = 'Invalid phone number. Please check the number and try selecting the correct country code.';
      } else if (error.message) {
        errorMsg = error.message;
      }
      setStatusMessage({ type: 'error', text: errorMsg });
      
      if ((window as any).recaptchaInstance) {
        try {
          ((window as any).recaptchaInstance as RecaptchaVerifier).clear();
        } catch (_) {}
        (window as any).recaptchaInstance = null;
      }
    } finally {
      setLoading(false);
    }
  };

  // Verify code
  const handleOtpVerification = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setStatusMessage(null);

    if (!confirmationResult) {
      setStatusMessage({ type: 'error', text: 'Verification session expired. Please request a new code.' });
      setLoading(false);
      return;
    }

    try {
      const result = await confirmationResult.confirm(otpCode);
      await syncUserProfile(result.user.uid, result.user.email, result.user.phoneNumber, result.user.displayName || 'SMS User');
      setStatusMessage({ type: 'success', text: 'SMS verified! Setting up session...' });
      setTimeout(() => {
        onAuthSuccess();
      }, 1000);
    } catch (error: any) {
      console.error('Confirmation Code verification error:', error);
      let errorMsg = 'Incorrect verification code. Please try again.';
      if (error.message) errorMsg = error.message;
      setStatusMessage({ type: 'error', text: errorMsg });
    } finally {
      setLoading(false);
    }
  };

  // Switch tabs
  const switchTab = (tab: 'email-login' | 'email-signup' | 'phone' | 'forgot') => {
    setActiveTab(tab);
    setStatusMessage(null);
    setWaitingForOtp(false);
    setConfirmationResult(null);
  };

  // Render SVG icons inline for 100% precision with custom styles
  const GoogleLogo = () => (
    <svg className="w-5 h-5 mr-3 shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
      <path d="M5.84 14.1c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.08H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.92l2.85-2.22c-.22-.66-.35-1.36-.35-2.09z" fill="#FBBC05" />
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.08l3.66 2.84c.87-2.6 3.3-4.54 6.16-4.54z" fill="#EA4335" />
    </svg>
  );

  const GithubLogo = () => (
    <svg className="w-5 h-5 mr-3 shrink-0 text-slate-900" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.17 6.839 9.49.5.092.682-.217.682-.482 0-.237-.008-.866-.013-1.7-2.782.603-3.369-1.34-3.369-1.34-.454-1.156-1.11-1.464-1.11-1.464-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.831.092-.646.35-1.086.636-1.336-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.203 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.579.688.481C19.137 20.167 22 16.418 22 12c0-5.523-4.477-10-10-10z" />
    </svg>
  );

  return (
    <div className="min-h-screen bg-[#f8f9fa] flex flex-col items-center justify-center p-4 relative overflow-hidden font-sans antialiased selection:bg-slate-900 selection:text-white">
      
      {/* Decorative blurred background shapes matching mockup ambiance */}
      <div className="absolute top-[-250px] left-[-150px] w-[700px] h-[700px] rounded-full bg-[#f1f3f5] filter blur-[130px] opacity-70 pointer-events-none" />
      <div className="absolute bottom-[-250px] right-[-150px] w-[700px] h-[700px] rounded-full bg-[#eef1f6] filter blur-[140px] opacity-75 pointer-events-none" />

      {/* Floating discretely placed back / exit portal action */}
      <button 
        type="button"
        onClick={onGoBack}
        className="absolute top-6 left-6 z-20 inline-flex items-center gap-1.5 text-[13px] text-slate-400 hover:text-slate-800 transition-colors duration-150 cursor-pointer bg-white/50 backdrop-blur-sm border border-slate-100/60 shadow-sm px-3.5 py-1.5 rounded-full hover:shadow"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span className="font-medium">Exit Auth</span>
      </button>

      {/* Invisible verification anchor */}
      <div id="recaptcha-container" ref={recaptchaContainerRef} className="hidden"></div>

      {/* Primary Container Card */}
      <div className="relative z-10 w-full max-w-[460px] bg-white border border-slate-100/60 shadow-[0_24px_70px_rgba(31,41,55,0.03)] rounded-[38px] px-6 sm:px-11 py-10 sm:py-12 flex flex-col items-center justify-center select-text transition-all duration-300">
        
        {isNetworkError ? (
          <motion.div
            key="sandbox-troubleshoot"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="w-full text-left font-sans text-slate-800 space-y-5"
          >
            {/* Header */}
            <div>
              <div className="flex items-center gap-2 mb-2 text-rose-500 font-medium">
                <ShieldAlert className="w-5 h-5 shrink-0" />
                <span className="font-bold tracking-tight uppercase font-mono text-[10px]">
                  Sandbox Restriction Detected
                </span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 tracking-tight leading-snug">
                Iframe SSO Blocked
              </h3>
              <p className="text-slate-500 text-xs mt-2 leading-relaxed">
                Browsers block popups & third-party state exchange inside sandboxed iframes (like the AI Studio Preview panel). Standalone windows are required to establish Google and GitHub Single Sign-On successfully.
              </p>
            </div>

            {/* Recommended Bypass */}
            <div className="bg-indigo-50/70 border border-indigo-100/60 rounded-2xl p-4.5 space-y-3">
              <span className="text-[11px] font-bold text-indigo-905 block font-mono uppercase tracking-wider">
                ⚡ Recommended Direct Bypass:
              </span>
              <p className="text-xs text-indigo-700 leading-relaxed font-sans">
                Opening this application in a standalone tab removes the iframe jail completely, allowing SSO to execute!
              </p>
              <button
                type="button"
                onClick={() => window.open(window.location.href, '_blank')}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow transition-all duration-150 cursor-pointer"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Open App in Standalone Tab</span>
              </button>
            </div>

            {/* Domain Authorizations */}
            <div className="space-y-2">
              <span className="text-[10px] font-bold text-slate-500 block font-mono uppercase tracking-wider">
                ⚙️ Authorized Domains (For Custom Firebase Projects):
              </span>
              <p className="text-xs text-slate-550 leading-normal">
                If integrating with a custom database, ensure your running domains are added under the Firebase Console Authorized domains:
              </p>
              
              <div className="space-y-1.5">
                {[
                  'localhost',
                  window.location.hostname,
                  window.location.hostname.replace('-dev-', '-pre-')
                ].map((domain, index) => (
                  <div key={index} className="flex items-center justify-between border border-slate-205/60 bg-slate-50 rounded-xl px-3 py-2 font-mono text-xs">
                    <span className="text-slate-600 select-all truncate pr-2">{domain}</span>
                    <button
                      type="button"
                      onClick={() => handleCopyText(domain)}
                      className="p-1 text-slate-400 hover:text-indigo-650 rounded transition-colors shrink-0 cursor-pointer"
                      title="Copy Domain"
                    >
                      {copiedText === domain ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                ))}
              </div>

              {auth.app.options.projectId && (
                <div className="pt-1">
                  <a
                    href={`https://console.firebase.google.com/project/${auth.app.options.projectId}/authentication/providers`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:text-indigo-850 transition-colors"
                  >
                    <span>Authorize Domains in Firebase</span>
                    <ExternalLink className="w-3" />
                  </a>
                </div>
              )}
            </div>

            {/* Dismiss button */}
            <div className="border-t border-slate-100 pt-4 flex">
              <button
                type="button"
                onClick={() => setIsNetworkError(false)}
                className="w-full py-3 text-center border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition-all duration-150"
              >
                Go back to login options
              </button>
            </div>
          </motion.div>
        ) : (
          <div className="w-full">
            
            {/* Top avatar design matching portrait exactly */}
            <div className="flex justify-center mb-6">
              <div className="w-20 h-20 rounded-full bg-white border border-slate-100 flex items-center justify-center shadow-[0_8px_20px_rgba(0,0,0,0.035)] relative">
                <User className="w-8 h-8 text-slate-800" strokeWidth={1.5} />
              </div>
            </div>

            {/* Header Titles Dynamic content depending on views */}
            <div className="mb-8 select-none">
              <h2 className="text-[32px] font-bold text-[#0f1115] tracking-tight leading-none mb-2.5 font-sans">
                {activeTab === 'email-login' && 'Welcome Back'}
                {activeTab === 'email-signup' && 'Welcome to App'}
                {activeTab === 'phone' && 'Phone Sign In'}
                {activeTab === 'forgot' && 'Reset Password'}
              </h2>
              <p className="text-slate-400 text-sm font-sans tracking-normal">
                {activeTab === 'email-login' && 'Sign in to continue to your account'}
                {activeTab === 'email-signup' && 'Create a free account to get started'}
                {activeTab === 'phone' && 'Enter your telephone to authenticate'}
                {activeTab === 'forgot' && 'Tell us your email to restore credentials'}
              </p>
            </div>

            {/* Dynamic Status Alert Message */}
            {statusMessage && (
              <div className={`mb-5 p-4 border text-[13px] rounded-2xl flex items-start gap-2.5 animate-in fade-in duration-200 text-left ${
                statusMessage.type === 'success' 
                  ? 'bg-emerald-50/60 border-emerald-100 text-emerald-800' 
                  : 'bg-rose-50/60 border-rose-100 text-rose-800'
              }`}>
                {statusMessage.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                ) : (
                  <ShieldAlert className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                )}
                <div className="font-medium leading-relaxed">
                  {statusMessage.text}
                </div>
              </div>
            )}

            {/* Active Render Form */}
            <AnimatePresence mode="wait">
              
              {/* EMAIL LOGIN FORMS */}
              {activeTab === 'email-login' && !waitingForOtp && (
                <motion.div
                  key="email-login"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.15 }}
                >
                  <form onSubmit={handleEmailSubmit} className="space-y-4">
                    <div className="h-14 w-full px-4 border border-slate-200 focus-within:border-slate-400 focus-within:ring-1 focus-within:ring-slate-400 rounded-2xl flex items-center transition-all bg-white">
                      <Mail className="w-5 h-5 text-slate-400 shrink-0 mr-3" strokeWidth={1.5} />
                      <input 
                        type="email" 
                        required 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Email or Username" 
                        className="w-full h-full text-sm bg-transparent outline-none text-slate-800 placeholder-slate-400/80 font-normal"
                      />
                    </div>

                    <div className="h-14 w-full px-4 border border-slate-200 focus-within:border-slate-400 focus-within:ring-1 focus-within:ring-slate-400 rounded-2xl flex items-center transition-all bg-white">
                      <Lock className="w-5 h-5 text-slate-400 shrink-0 mr-3" strokeWidth={1.5} />
                      <input 
                        type={showPassword ? 'text' : 'password'} 
                        required 
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Password" 
                        className="w-full h-full text-sm bg-transparent outline-none text-slate-800 placeholder-slate-400/80 font-normal"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="text-slate-400 hover:text-slate-650 transition-colors p-1 cursor-pointer shrink-0 ml-1.5 focus:outline-none"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" strokeWidth={1.5} /> : <Eye className="w-4 h-4" strokeWidth={1.5} />}
                      </button>
                    </div>

                    {/* Checkbox and Forgot Row */}
                    <div className="flex items-center justify-between w-full pt-1.5 text-sm select-none">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input 
                          type="checkbox" 
                          checked={rememberMe}
                          onChange={(e) => setRememberMe(e.target.checked)}
                          className="w-4.5 h-4.5 rounded border-slate-200 text-slate-900 focus:ring-slate-900 focus:ring-offset-0 cursor-pointer accent-slate-900" 
                        />
                        <span className="text-slate-500 text-[13px] font-medium leading-none">Remember me</span>
                      </label>
                      
                      <button 
                        type="button"
                        onClick={() => switchTab('forgot')}
                        className="text-slate-500 hover:text-slate-800 transition-colors cursor-pointer text-[13px] font-medium"
                      >
                        Forgot password?
                      </button>
                    </div>

                    {/* Main submit button */}
                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full h-13 bg-[#0a0c10] hover:bg-[#1c1f26] text-white font-sans font-bold text-sm tracking-wide rounded-[14px] transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 mt-6 active:scale-[0.99] disabled:opacity-75 focus:outline-none"
                    >
                      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Log In'}
                    </button>
                  </form>
                </motion.div>
              )}

              {/* EMAIL REGISTER SIGN UP */}
              {activeTab === 'email-signup' && !waitingForOtp && (
                <motion.div
                  key="email-signup"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.15 }}
                >
                  <form onSubmit={handleEmailSubmit} className="space-y-4">
                    <div className="h-14 w-full px-4 border border-slate-200 focus-within:border-slate-400 focus-within:ring-1 focus-within:ring-slate-400 rounded-2xl flex items-center transition-all bg-white">
                      <User className="w-5 h-5 text-slate-400 shrink-0 mr-3" strokeWidth={1.5} />
                      <input 
                        type="text" 
                        required 
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Full Name" 
                        className="w-full h-full text-sm bg-transparent outline-none text-slate-800 placeholder-slate-400/80 font-normal"
                      />
                    </div>

                    <div className="h-14 w-full px-4 border border-slate-200 focus-within:border-slate-400 focus-within:ring-1 focus-within:ring-slate-400 rounded-2xl flex items-center transition-all bg-white">
                      <Mail className="w-5 h-5 text-slate-400 shrink-0 mr-3" strokeWidth={1.5} />
                      <input 
                        type="email" 
                        required 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Email Address" 
                        className="w-full h-full text-sm bg-transparent outline-none text-slate-800 placeholder-slate-400/80 font-normal"
                      />
                    </div>

                    <div className="h-14 w-full px-4 border border-slate-200 focus-within:border-slate-400 focus-within:ring-1 focus-within:ring-slate-400 rounded-2xl flex items-center transition-all bg-white">
                      <Lock className="w-5 h-5 text-slate-400 shrink-0 mr-3" strokeWidth={1.5} />
                      <input 
                        type={showPassword ? 'text' : 'password'} 
                        required 
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Password (Min 6 chars)" 
                        className="w-full h-full text-sm bg-transparent outline-none text-slate-800 placeholder-slate-400/80 font-normal"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="text-slate-400 hover:text-slate-650 transition-colors p-1 cursor-pointer shrink-0 ml-1.5 focus:outline-none"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" strokeWidth={1.5} /> : <Eye className="w-4 h-4" strokeWidth={1.5} />}
                      </button>
                    </div>

                    {/* Main submit button */}
                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full h-13 bg-[#0a0c10] hover:bg-[#1c1f26] text-white font-sans font-bold text-sm tracking-wide rounded-[14px] transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 mt-6 active:scale-[0.99] disabled:opacity-75 focus:outline-none"
                    >
                      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Create Account'}
                    </button>
                  </form>
                </motion.div>
              )}

              {/* TELEPHONE AUTH */}
              {activeTab === 'phone' && !waitingForOtp && (
                <motion.div
                  key="phone"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.15 }}
                >
                  <form onSubmit={handlePhoneSubmit} className="space-y-4">
                    <div className="h-14 w-full border border-slate-200 focus-within:border-slate-400 focus-within:ring-1 focus-within:ring-slate-400 rounded-2xl flex items-center transition-all bg-white overflow-hidden">
                      {/* Left: Beautiful custom dropdown selector */}
                      <div className="h-full pl-3 pr-2.5 border-r border-slate-100 flex items-center bg-slate-50/70 relative shrink-0">
                        <select
                          value={selectedCountryCode}
                          onChange={(e) => setSelectedCountryCode(e.target.value)}
                          className="h-full bg-transparent text-[13px] font-bold text-slate-700 outline-none pr-5 cursor-pointer appearance-none relative z-10 font-sans"
                        >
                          {COUNTRY_CODES.map((item) => (
                            <option key={item.code} value={item.code} className="text-slate-800 font-medium font-sans">
                              {item.flag} {item.code} ({item.name})
                            </option>
                          ))}
                        </select>
                        <div className="absolute right-2.5 pointer-events-none text-slate-400 z-0">
                          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                          </svg>
                        </div>
                      </div>
                      
                      {/* Right: Phone input line */}
                      <div className="flex-1 h-full px-4 flex items-center">
                        <Phone className="w-4.5 h-4.5 text-slate-400 shrink-0 mr-3" strokeWidth={1.5} />
                        <input 
                          type="tel" 
                          required 
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="Phone Number (e.g., 415 555 2671)" 
                          className="w-full h-full text-sm bg-transparent outline-none text-slate-800 placeholder-slate-400/80 font-normal font-mono"
                        />
                      </div>
                    </div>
                    <span className="text-[11px] text-slate-400 mt-1 block leading-relax text-left ml-1 font-sans">
                      Select your country code from the dropdown or type it directly.
                    </span>

                    {/* Main submit button */}
                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full h-13 bg-[#0a0c10] hover:bg-[#1c1f26] text-white font-sans font-bold text-sm tracking-wide rounded-[14px] transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 mt-5 active:scale-[0.99] disabled:opacity-75 focus:outline-none"
                    >
                      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Send Verification Code'}
                    </button>
                  </form>
                </motion.div>
              )}

              {/* OTP CODE VERIFICATION ACTIVE */}
              {waitingForOtp && (
                <motion.div
                  key="otp-verification"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.15 }}
                  className="space-y-5 text-center mt-2"
                >
                  <div className="p-3.5 bg-indigo-50 border border-indigo-100 rounded-2xl flex justify-center items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-indigo-600 shrink-0" />
                    <span className="text-[12px] text-indigo-900 font-semibold font-sans">
                      SMS confirmation sent successfully
                    </span>
                  </div>

                  <form onSubmit={handleOtpVerification} className="space-y-4">
                    <div>
                      <span className="text-xs text-slate-450 block font-bold uppercase tracking-wider mb-2 select-none">
                        Enter Secure Auth Code
                      </span>
                      <input 
                        type="text" 
                        required 
                        maxLength={6}
                        value={otpCode}
                        onChange={(e) => setOtpCode(e.target.value)}
                        placeholder="123456" 
                        className="w-40 text-center mx-auto block px-4 py-3 bg-slate-50 border border-slate-200 focus:border-slate-400 focus:bg-white rounded-xl text-xl font-bold font-mono tracking-[0.25em] outline-none transition-all"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full h-13 bg-[#0a0c10] hover:bg-[#1c1f26] text-white font-sans font-bold text-sm tracking-wide rounded-[14px] transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 mt-2 active:scale-[0.99]"
                    >
                      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Confirm Code & Access'}
                    </button>
                  </form>

                  <button 
                    type="button" 
                    onClick={() => switchTab('phone')}
                    className="text-xs font-semibold text-indigo-650 hover:text-indigo-800 transition-colors cursor-pointer w-full text-center block pt-1.5"
                  >
                    Resend to different phone number
                  </button>
                </motion.div>
              )}

              {/* FORGOT PASSWORD FORM */}
              {activeTab === 'forgot' && !waitingForOtp && (
                <motion.div
                  key="forgot"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.15 }}
                >
                  <form onSubmit={handleEmailSubmit} className="space-y-4">
                    <div className="h-14 w-full px-4 border border-slate-200 focus-within:border-slate-400 focus-within:ring-1 focus-within:ring-slate-400 rounded-2xl flex items-center transition-all bg-white">
                      <Mail className="w-5 h-5 text-slate-400 shrink-0 mr-3" strokeWidth={1.5} />
                      <input 
                        type="email" 
                        required 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Registered Email Address" 
                        className="w-full h-full text-sm bg-transparent outline-none text-slate-800 placeholder-slate-400/80 font-normal"
                      />
                    </div>

                    {/* Main submit button */}
                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full h-13 bg-[#0a0c10] hover:bg-[#1c1f26] text-white font-sans font-bold text-sm tracking-wide rounded-[14px] transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 mt-5 active:scale-[0.99] disabled:opacity-75 focus:outline-none"
                    >
                      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Send Restoration Link'}
                    </button>
                  </form>
                </motion.div>
              )}

            </AnimatePresence>

            {/* Social Logins Stack (Always shown except in explicit verification / forgot code modes) */}
            {!waitingForOtp && activeTab !== 'forgot' && (
              <div className="w-full mt-6 space-y-3">
                
                {/* Google SSO Button */}
                <button
                  type="button"
                  onClick={handleGoogleSignIn}
                  disabled={loading}
                  className="w-full h-13 bg-white hover:bg-slate-50 border border-slate-100 flex items-center justify-center rounded-[15px] cursor-pointer transition-all duration-150 shadow-[0_1px_2px_rgba(0,0,0,0.01)] active:scale-[0.99] focus:outline-none"
                >
                  <GoogleLogo />
                  <span className="text-slate-700 font-semibold font-sans text-[13.5px] tracking-normal">
                    Continue with Google
                  </span>
                </button>

                {/* GitHub SSO Button */}
                <button
                  type="button"
                  onClick={handleGithubSignIn}
                  disabled={loading}
                  className="w-full h-13 bg-white hover:bg-slate-50 border border-slate-100 flex items-center justify-center rounded-[15px] cursor-pointer transition-all duration-150 shadow-[0_1px_2px_rgba(0,0,0,0.01)] active:scale-[0.99] focus:outline-none"
                >
                  <GithubLogo />
                  <span className="text-slate-700 font-semibold font-sans text-[13.5px] tracking-normal">
                    Continue with GitHub
                  </span>
                </button>

                {/* Phone Sign-In Trigger (Exposed only if on email screens) */}
                {(activeTab === 'email-login' || activeTab === 'email-signup') && (
                  <button
                    type="button"
                    onClick={() => switchTab('phone')}
                    disabled={loading}
                    className="w-full h-13 bg-white hover:bg-slate-50 border border-slate-100 flex items-center justify-center rounded-[15px] cursor-pointer transition-all duration-150 shadow-[0_1px_2px_rgba(0,0,0,0.01)] active:scale-[0.99] focus:outline-none"
                  >
                    <Phone className="w-4 h-4 text-slate-600 mr-3 shrink-0" strokeWidth={1.8} />
                    <span className="text-slate-700 font-semibold font-sans text-[13.5px] tracking-normal">
                      Continue with Phone
                    </span>
                  </button>
                )}
                
              </div>
            )}

            {/* Bottom Form Footer Toggle */}
            <div className="text-slate-505 select-none text-[13.5px] font-medium font-sans mt-7 text-center">
              {activeTab === 'email-login' && (
                <>
                  Don’t have an account?{' '}
                  <span 
                    onClick={() => switchTab('email-signup')} 
                    className="font-bold text-[#090b10] hover:underline cursor-pointer ml-1"
                  >
                    Sign up
                  </span>
                </>
              )}

              {activeTab === 'email-signup' && (
                <>
                  Already have an account?{' '}
                  <span 
                    onClick={() => switchTab('email-login')} 
                    className="font-bold text-[#090b10] hover:underline cursor-pointer ml-1"
                  >
                    Sign in
                  </span>
                </>
              )}

              {activeTab === 'phone' && (
                <span 
                  onClick={() => switchTab('email-login')} 
                  className="font-bold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                >
                  Back to Sign In
                </span>
              )}

              {activeTab === 'forgot' && (
                <span 
                  onClick={() => switchTab('email-login')} 
                  className="font-bold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                >
                  Back to Sign In
                </span>
              )}
            </div>

          </div>
        )}

      </div>

    </div>
  );
}
