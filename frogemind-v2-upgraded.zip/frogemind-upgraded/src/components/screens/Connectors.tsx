/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Cable, 
  Github, 
  Database, 
  Slack, 
  MessageSquare, 
  Check, 
  X, 
  RefreshCw, 
  Loader2, 
  Lock, 
  Info, 
  Sparkles,
  Link2,
  Plug,
  ExternalLink,
  Cpu,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

interface ConnectorItem {
  id: string;
  name: string;
  provider: string;
  description: string;
  iconType: 'github' | 'drive' | 'notion' | 'slack' | 'postgres';
  status: 'connected' | 'disconnected';
  lastSynced?: string;
  credentialsRequired: string[];
}

export default function Connectors() {
  const [connectors, setConnectors] = useState<ConnectorItem[]>(() => {
    const saved = localStorage.getItem('frogemind_connectors');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error loading connectors', e);
      }
    }
    return [
      {
        id: 'conn-1',
        name: 'GitHub Repository Sync',
        provider: 'GitHub Inc',
        description: 'Pulls commits, source trees, and pull request discussion records directly into search indexing.',
        iconType: 'github',
        status: 'disconnected',
        credentialsRequired: ['Personal Access Token (PAT)', 'Repository Owner/Path']
      },
      {
        id: 'conn-2',
        name: 'Google Drive Doc Indexer',
        provider: 'Google Workspace',
        description: 'Auto-syncs spreadsheets, slides, documents, and transcript recordings with prompt context databases.',
        iconType: 'drive',
        status: 'connected',
        lastSynced: '2 hours ago',
        credentialsRequired: ['OAuth Client Key', 'Target Directory Folder ID']
      },
      {
        id: 'conn-3',
        name: 'Notion Workspace Notes',
        provider: 'Notion PBC',
        description: 'Indexes personal wiki items, database templates, and weekly journals to synthesize summaries.',
        iconType: 'notion',
        status: 'disconnected',
        credentialsRequired: ['Notion Integration Token', 'Page Shares permissions ID']
      },
      {
        id: 'conn-4',
        name: 'PostgreSQL Datastore',
        provider: 'Supabase / Neon',
        description: 'Runs read queries on operational server tables to extract real schema summaries and row metadata dynamically.',
        iconType: 'postgres',
        status: 'disconnected',
        credentialsRequired: ['DB Secret Connection URI string']
      },
      {
        id: 'conn-5',
        name: 'Slack Active Workspaces',
        provider: 'Slack Technologies',
        description: 'Monitors designated public channels to index active alerts, alerts feedback, and client meeting tasks.',
        iconType: 'slack',
        status: 'connected',
        lastSynced: '4 mins ago',
        credentialsRequired: ['Slack App Botanical Token', 'Channel Name Target ID']
      }
    ];
  });

  const [activeConfigId, setActiveConfigId] = useState<string | null>(null);
  const [credentialsInputs, setCredentialsInputs] = useState<Record<string, string>>({});
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<Record<string, 'success' | 'failed'>>({});

  useEffect(() => {
    localStorage.setItem('frogemind_connectors', JSON.stringify(connectors));
  }, [connectors]);

  const handleOpenConfig = (id: string) => {
    setActiveConfigId(id);
    setTestResult({});
  };

  const handleSaveCredentials = (id: string, e: React.FormEvent) => {
    e.preventDefault();
    setConnectors(connectors.map(c => {
      if (c.id === id) {
        return {
          ...c,
          status: 'connected',
          lastSynced: 'Just initialized'
        };
      }
      return c;
    }));
    setActiveConfigId(null);
  };

  const handleDisconnect = (id: string) => {
    if (window.confirm('Are you sure you want to decouple this connector?')) {
      setConnectors(connectors.map(c => {
        if (c.id === id) {
          return {
            ...c,
            status: 'disconnected',
            lastSynced: undefined
          };
        }
        return c;
      }));
      // Clear inputs for this connector
      const updatedInputs = { ...credentialsInputs };
      const conn = connectors.find(co => co.id === id);
      if (conn) {
        conn.credentialsRequired.forEach(req => {
          delete updatedInputs[`${id}-${req}`];
        });
      }
      setCredentialsInputs(updatedInputs);
    }
  };

  const handleTestPing = (id: string) => {
    setTestingId(id);
    setTimeout(() => {
      setTestingId(null);
      // Let's decide success: succeeds if has inputs or randomly
      const conn = connectors.find(co => co.id === id);
      const isFilled = conn?.credentialsRequired.some(req => credentialsInputs[`${id}-${req}`]);
      if (isFilled || conn?.status === 'connected') {
        setTestResult(prev => ({ ...prev, [id]: 'success' }));
      } else {
        setTestResult(prev => ({ ...prev, [id]: 'failed' }));
      }
    }, 1500);
  };

  // Icon selector
  const renderConnectorIcon = (type: string) => {
    switch (type) {
      case 'github':
        return <Github className="w-5 h-5 text-slate-800" />;
      case 'drive':
        return <Plug className="w-5 h-5 text-indigo-500" />;
      case 'notion':
        return <Database className="w-5 h-5 text-purple-600" />;
      case 'slack':
        return <Slack className="w-5 h-5 text-rose-500" />;
      case 'postgres':
        return <Link2 className="w-5 h-5 text-emerald-600" />;
      default:
        return <Cable className="w-5 h-5 text-slate-500" />;
    }
  };

  return (
    <div className="flex-1 overflow-y-auto bg-white p-6 sm:p-8 text-slate-800 font-sans">
      
      {/* Upper header segment summary */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-6 mb-8 mt-2">
        <div>
          <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-indigo-600">WORKSPACE INTEGRATIONS</span>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Data Connectors
          </h1>
          <p className="text-slate-500 text-xs mt-1.5 leading-relaxed">
            Unfold and secure live webhook connections with third party tools, allowing LLM models to fetch authentic documents.
          </p>
        </div>

        {/* Global info metrics */}
        <div className="flex items-center gap-2 px-4 py-2.5 bg-slate-50 border border-slate-150/60 rounded-2xl shrink-0">
          <Sparkles className="w-4 h-4 text-indigo-500" />
          <span className="text-xs font-semibold text-slate-600">
            {connectors.filter(c => c.status === 'connected').length} of {connectors.length} active pipelines
          </span>
        </div>
      </div>

      {/* Main Grid display of connectors */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pb-12">
        {connectors.map((connector) => {
          const isConnected = connector.status === 'connected';

          return (
            <div 
              key={connector.id}
              className={`p-6 bg-white border rounded-3xl transition-all duration-300 relative flex flex-col justify-between ${
                isConnected 
                  ? 'border-indigo-200/80 shadow-[0_4px_16px_rgba(79,70,229,0.02)]' 
                  : 'border-slate-100 hover:border-slate-200 shadow-xs'
              }`}
            >
              <div>
                
                {/* Header row representation */}
                <div className="flex items-start justify-between gap-2 mb-4">
                  <div className="w-11 h-11 rounded-2xl bg-slate-50 border border-slate-100/80 flex items-center justify-center shadow-xs">
                    {renderConnectorIcon(connector.iconType)}
                  </div>

                  <span className={`text-[8.5px] font-mono font-bold uppercase px-2.5 py-1 rounded-full border ${
                    isConnected 
                      ? 'bg-emerald-50 border-emerald-100 text-emerald-700' 
                      : 'bg-slate-50 border-slate-100 text-slate-400'
                  }`}>
                    {isConnected ? 'Active pipeline' : 'Inactive'}
                  </span>
                </div>

                {/* Name & Provider */}
                <h3 className="text-sm font-bold text-slate-900 leading-tight mb-0.5">{connector.name}</h3>
                <span className="text-[10px] font-semibold text-slate-400 uppercase font-mono block mb-3">{connector.provider}</span>

                {/* Description */}
                <p className="text-xs text-slate-500 leading-relaxed min-h-[48px] mb-5">
                  {connector.description}
                </p>

                {/* Status sync flags */}
                {isConnected && connector.lastSynced && (
                  <div className="border-t border-slate-100 pt-3 mb-5 flex items-center justify-between text-[10px] font-mono text-slate-400 font-bold">
                    <span>Synchronized:</span>
                    <span className="text-slate-650 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping shrink-0" />
                      <span>{connector.lastSynced}</span>
                    </span>
                  </div>
                )}

              </div>

              {/* Activation action CTA */}
              <div className="pt-2">
                {isConnected ? (
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleOpenConfig(connector.id)}
                      className="flex-1 py-2 border border-slate-200 hover:bg-slate-50 hover:border-slate-350 text-slate-600 font-bold text-xs rounded-xl cursor-pointer transition-all"
                    >
                      Settings
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDisconnect(connector.id)}
                      className="p-2 border border-rose-100 hover:bg-rose-50 text-rose-500 rounded-xl cursor-pointer transition-all"
                      title="Deactivate Line"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleOpenConfig(connector.id)}
                    className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl cursor-pointer transition-all shadow-xs"
                  >
                    Configure Connector
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

      {/* Dynamic Overlay Config Drawer Modal */}
      <AnimatePresence>
        {activeConfigId && (() => {
          const activeConn = connectors.find(c => c.id === activeConfigId);
          if (!activeConn) return null;

          return (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 select-none"
            >
              <motion.div
                initial={{ scale: 0.95, y: 15 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.95, y: 15 }}
                className="bg-white border border-slate-200 shadow-xl rounded-[28px] w-full max-w-md p-6 sm:p-8 text-left"
              >
                
                {/* Header segment logo */}
                <div className="flex items-center gap-3 border-b border-slate-100 pb-4.5 mb-6">
                  <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center shrink-0 shadow-xs">
                    {renderConnectorIcon(activeConn.iconType)}
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-slate-900">{activeConn.name}</h3>
                    <span className="text-[10px] text-slate-400 font-bold font-mono tracking-wider uppercase">{activeConn.provider} Settings</span>
                  </div>
                </div>

                {/* Explainer warning */}
                <div className="p-3.5 bg-slate-50 border border-slate-100 rounded-2xl text-xs text-slate-500 leading-relaxed mb-5 flex gap-2">
                  <Lock className="w-4 h-4 text-indigo-500 mt-0.5 shrink-0" strokeWidth={1.5} />
                  <span>
                    Your connection credentials are encrypted on the browser local storage sandbox. No data escapes.
                  </span>
                </div>

                {/* Form configuration fields */}
                <form onSubmit={(e) => handleSaveCredentials(activeConn.id, e)} className="space-y-4">
                  {activeConn.credentialsRequired.map((req, index) => {
                    const key = `${activeConn.id}-${req}`;
                    return (
                      <div key={index}>
                        <label className="block text-xs font-bold text-slate-450 uppercase tracking-wider mb-2 font-mono">
                          {req}
                        </label>
                        <input
                          type={req.toLowerCase().includes('secret') || req.toLowerCase().includes('token') ? 'password' : 'text'}
                          required
                          value={credentialsInputs[key] || ''}
                          onChange={(e) => setCredentialsInputs({ ...credentialsInputs, [key]: e.target.value })}
                          placeholder={`Enter ${req.toLowerCase()} authorization...`}
                          className="w-full px-3.5 py-2.5 bg-slate-50/50 hover:bg-slate-50 focus:bg-white border border-slate-200 focus:border-indigo-400 rounded-xl outline-none text-xs text-slate-800 transition-all font-mono"
                        />
                      </div>
                    );
                  })}

                  {/* Operational Ping diagnostic test */}
                  <div className="pt-2 pb-1.5 flex flex-wrap items-center justify-between gap-2.5">
                    <button
                      type="button"
                      disabled={testingId === activeConn.id}
                      onClick={() => handleTestPing(activeConn.id)}
                      className="inline-flex items-center gap-1.5 text-xs text-indigo-600 hover:text-indigo-800 font-bold transition-all cursor-pointer"
                    >
                      {testingId === activeConn.id ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Pinging...</span>
                        </>
                      ) : (
                        <>
                          <RefreshCw className="w-3.5 h-3.5" />
                          <span>Test connection ping</span>
                        </>
                      )}
                    </button>

                    {/* Ping feedback */}
                    {testResult[activeConn.id] === 'success' && (
                      <span className="inline-flex items-center gap-1 text-[10.5px] font-bold text-emerald-600 font-mono bg-emerald-50 border border-emerald-100 rounded-lg px-2.5 py-0.5">
                        <Check className="w-3.5 h-3.5" />
                        <span>Ping OK</span>
                      </span>
                    )}

                    {testResult[activeConn.id] === 'failed' && (
                      <span className="inline-flex items-center gap-1 text-[10.5px] font-bold text-rose-600 font-mono bg-rose-50 border border-rose-100 rounded-lg px-2.5 py-0.5">
                        <X className="w-3.5 h-3.5" />
                        <span>Need Keys</span>
                      </span>
                    )}
                  </div>

                  {/* Buttons submit and restore */}
                  <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setActiveConfigId(null)}
                      className="px-4 py-2.5 border border-slate-200 hover:bg-slate-50 text-slate-500 text-xs font-bold rounded-xl cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl cursor-pointer shadow-sm"
                    >
                      Save & Sync
                    </button>
                  </div>

                </form>

              </motion.div>
            </motion.div>
          );
        })()}
      </AnimatePresence>

    </div>
  );
}
