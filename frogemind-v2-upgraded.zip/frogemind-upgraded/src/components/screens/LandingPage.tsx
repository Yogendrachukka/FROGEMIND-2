/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Sparkles, 
  ArrowRight, 
  Cpu, 
  Layers, 
  Zap, 
  Shield, 
  Terminal, 
  MessageSquare, 
  Database,
  Star,
  Globe,
  Monitor,
  Check
} from 'lucide-react';

interface LandingPageProps {
  onEnterApp: (screen?: string) => void;
  onEnterAuth: () => void;
}

export default function LandingPage({ onEnterApp, onEnterAuth }: LandingPageProps) {
  const [selectedDemoModel, setSelectedDemoModel] = useState<string>('DeepSeek R1');

  const demoResponses: Record<string, { desc: string, response: string, latency: string, metrics: string }> = {
    'DeepSeek R1': {
      desc: 'Deep analytical thinking and complex logical reasoning.',
      response: '<thinking>\nAnalyzing math logical steps...\nDouble-checking mathematical proofs...\n</thinking>\nMy reasoning is complete. For your custom workspace configuration, optimize routing loops.',
      latency: '1.4s (Reasoning Enabled)',
      metrics: 'Reasoning: 5/5 | Speed: 3/5'
    },
    'GPT-4o': {
      desc: 'Super fast, creative, and highly conversational responses.',
      response: 'Hello! I can help you draft articles, design clean layouts, or configure API integrations in real-time.',
      latency: '0.4s (High Speed)',
      metrics: 'Reasoning: 4/5 | Speed: 5/5'
    },
    'Claude 3.5': {
      desc: 'Excellent software code generation and code structure.',
      response: '```typescript\n// Optimizing workspace components\nexport const configureWorkspace = (id: string) => {\n  return { ok: true, id };\n};\n```',
      latency: '0.8s (Balanced)',
      metrics: 'Reasoning: 5/5 | Speed: 4/5'
    },
    'Gemma 2': {
      desc: 'Fast local model tailored for privacy-first operations.',
      response: 'Gemma Workspace Node Active. Local parameters initialized with zero-knowledge metadata pipelines.',
      latency: '0.1s (Local Edge)',
      metrics: 'Reasoning: 3/5 | Speed: 5/5'
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 overflow-x-hidden font-sans relative">
      
      {/* Dynamic Top Navigation Bar */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-white/80 border-b border-slate-100 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-sky-500 flex items-center justify-center shadow-xs">
              <Cpu className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="font-bold text-base tracking-tight font-display text-slate-900">FrogeMind</span>
              <span className="text-[9px] uppercase font-mono tracking-widest text-[#4f46e5] block -mt-1 font-bold">Studio Platform</span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-8 text-xs font-semibold text-slate-500 font-mono">
            <a href="#features" className="hover:text-slate-800 transition-colors">Features</a>
            <a href="#demo" className="hover:text-slate-800 transition-colors">Compare Models</a>
            <a href="#pricing" className="hover:text-slate-800 transition-colors">Pricing Options</a>
          </div>

          <div className="flex items-center gap-3">
            <button 
              onClick={onEnterAuth}
              className="text-xs font-bold px-4 py-2 hover:text-slate-950 text-slate-600 transition-colors cursor-pointer"
            >
              Sign In
            </button>
            <button 
              onClick={() => onEnterApp('chat')}
              className="relative text-xs font-bold px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white transition-all active:scale-95 flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <span>Launch Playground</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-20 pb-16 px-6 text-center">
        <div className="max-w-4xl mx-auto flex flex-col items-center">
          
          {/* Top Label pill */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-indigo-100 bg-indigo-50/50 text-[10px] font-mono font-bold tracking-wider text-indigo-600 uppercase mb-8 shadow-xs">
            <Sparkles className="w-3 h-3 text-indigo-500" />
            <span>Interactive Multi-Model Platform</span>
          </div>

          <h1 className="text-4xl sm:text-6xl md:text-7xl font-bold tracking-tight mb-6 leading-[1.1] font-display text-slate-900">
            Engineered for <br />
            <span className="bg-gradient-to-r from-indigo-600 to-sky-600 bg-clip-text text-transparent">
              Creative Intelligence
            </span>
          </h1>

          <p className="text-sm sm:text-lg text-slate-500 max-w-2xl leading-relaxed mb-10">
            A minimalist central hub featuring dynamic model switching, a long-term local knowledge vault, and side-by-side performance contrast layouts.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-20 w-full sm:w-auto">
            <button
              onClick={() => onEnterApp('chat')}
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-md transition-all active:scale-97 cursor-pointer"
            >
              Start Free Playground
            </button>
            <button
              onClick={onEnterAuth}
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs transition-all shadow-xs cursor-pointer"
            >
              Create Account
            </button>
          </div>

          {/* Interactive Model Switcher Showcase Widget */}
          <div id="demo" className="w-full rounded-3xl border border-slate-100 bg-white p-4 sm:p-6 shadow-xl text-left max-w-4xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4 mb-5">
              <div className="flex items-center gap-2 text-slate-800">
                <Terminal className="w-4 h-4 text-indigo-500" />
                <span className="text-xs font-mono font-bold">Contrast Model Speed vs Depth</span>
              </div>
              
              {/* Selector buttons */}
              <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-50 rounded-xl border border-slate-100">
                {Object.keys(demoResponses).map((nod) => (
                  <button
                    key={nod}
                    onClick={() => setSelectedDemoModel(nod)}
                    className={`px-3 py-1 text-[10px] font-mono rounded-lg transition-all cursor-pointer ${
                      selectedDemoModel === nod 
                        ? 'bg-white border border-slate-200/50 text-indigo-600 shadow-xs font-bold' 
                        : 'border border-transparent text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {nod}
                  </button>
                ))}
              </div>
            </div>

            {/* Inner demo monitor */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2 flex flex-col gap-3">
                <span className="text-[10px] font-mono text-slate-450 uppercase font-semibold">Live Sandbox Output:</span>
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 font-mono text-xs text-slate-700 min-h-[140px] flex flex-col justify-between relative overflow-hidden">
                  <div className="absolute top-2 right-2 flex items-center gap-1 text-[9px] text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full font-mono font-semibold">
                    <span className="w-1 h-1 rounded-full bg-emerald-500 animate-ping" />
                    <span>Response Live</span>
                  </div>
                  <pre className="whitespace-pre-wrap pr-12 text-slate-700 leading-relaxed font-sans">
                    {demoResponses[selectedDemoModel].response}
                  </pre>
                  <div className="text-[9px] text-slate-400 mt-4 pt-2 border-t border-slate-100">
                    Compiled in {demoResponses[selectedDemoModel].latency}
                  </div>
                </div>
              </div>

              {/* Specifications */}
              <div className="bg-slate-50/50 border border-slate-100 p-4 rounded-xl flex flex-col justify-between">
                <div className="space-y-4">
                  <div>
                    <span className="text-[8px] font-mono text-slate-400 block tracking-wider uppercase font-bold">Model Engine</span>
                    <span className="text-xs font-bold text-slate-800">{selectedDemoModel}</span>
                  </div>
                  <div>
                    <span className="text-[8px] font-mono text-slate-400 block tracking-wider uppercase font-bold">Specialty trait</span>
                    <span className="text-[11px] text-slate-600 leading-relaxed">
                      {demoResponses[selectedDemoModel].desc}
                    </span>
                  </div>
                  <div>
                    <span className="text-[8px] font-mono text-slate-400 block tracking-wider uppercase font-bold">Benchmark Speed</span>
                    <span className="text-[10px] font-mono text-slate-700 font-semibold">
                      {demoResponses[selectedDemoModel].metrics}
                    </span>
                  </div>
                </div>

                <button 
                  onClick={() => onEnterApp('projects')}
                  className="mt-6 w-full py-2 bg-slate-900 hover:bg-slate-800 text-white text-[10px] font-mono uppercase tracking-wide rounded-lg transition-transform active:scale-97 cursor-pointer"
                >
                  Manage Active Projects →
                </button>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* Feature Grid Section */}
      <section id="features" className="py-20 px-6 max-w-7xl mx-auto border-t border-slate-100 bg-white rounded-3xl mb-16 shadow-xs">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-[10px] uppercase font-mono tracking-widest text-[#4f46e5] font-black">All-In-One Workspace</span>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mt-2 text-slate-905 text-slate-950 font-display">
            Designed for Modern Workflows
          </h2>
          <p className="text-slate-500 text-xs sm:text-sm mt-3 leading-relaxed">
            Eliminate cognitive friction and compare responses from the world's most capable AI engines inside a single, beautifully simple workspace.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Card 1 */}
          <div className="p-6 rounded-2xl border border-slate-100 bg-slate-50/40 hover:bg-white hover:shadow-md transition-all flex flex-col justify-between group">
            <div>
              <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center mb-5">
                <Cpu className="w-5 h-5 text-indigo-600" />
              </div>
              <h3 className="text-base font-bold text-slate-800 font-display">Multi-Model Playground</h3>
              <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                Seamlessly direct queries to different model backends in parallel. Compare quality, accuracy and response formats inside one uniform dashboard.
              </p>
            </div>
            <span className="text-[9px] font-mono text-[#4f46e5] uppercase tracking-wider block mt-6">Speed Benchmarking</span>
          </div>

          {/* Card 2 */}
          <div className="p-6 rounded-2xl border border-slate-100 bg-slate-50/40 hover:bg-white hover:shadow-md transition-all flex flex-col justify-between group">
            <div>
              <div className="w-10 h-10 rounded-xl bg-purple-50 border border-purple-100 flex items-center justify-center mb-5">
                <Database className="w-5 h-5 text-purple-600" />
              </div>
              <h3 className="text-base font-bold text-slate-800 font-display">Knowledge Vault</h3>
              <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                Persist custom facts, project definitions and context elements permanently. Allow models to query your secure memory base instantly.
              </p>
            </div>
            <span className="text-[9px] font-mono text-purple-600 uppercase tracking-wider block mt-6">Context Memory Vault</span>
          </div>

          {/* Card 3 */}
          <div className="p-6 rounded-2xl border border-slate-100 bg-slate-50/40 hover:bg-white hover:shadow-md transition-all flex flex-col justify-between group">
            <div>
              <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center mb-5">
                <Layers className="w-5 h-5 text-emerald-600" />
              </div>
              <h3 className="text-base font-bold text-slate-800 font-display">Plugin & Toolbox integrations</h3>
              <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                Mount customizable utilities. Let assistive tools parse codes, generate draft summaries, or organize calendars flawlessly.
              </p>
            </div>
            <span className="text-[9px] font-mono text-emerald-600 uppercase tracking-wider block mt-6">Dynamic Toolkit Matrix</span>
          </div>

        </div>
      </section>

      {/* Pricing Options */}
      <section id="pricing" className="py-16 px-6 max-w-4xl mx-auto scroll-mt-6">
        <div className="text-center mb-10">
          <span className="text-[10px] uppercase font-mono tracking-widest text-[#4f46e5] font-black">Flexible Tier Pricing</span>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 font-display mt-2">
            Pricing Designed for Everyone
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
          
          {/* Plan A */}
          <div className="p-8 rounded-3xl border border-slate-100 bg-white shadow-xs flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-mono uppercase bg-slate-100 text-slate-500 px-3 py-1 rounded-full font-bold">Free Tier</span>
              <div className="my-5">
                <span className="text-4xl font-bold text-slate-900 font-display">$0</span>
                <span className="text-xs text-slate-400">/ forever</span>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed mb-6">
                Perfect for hobbyists and individual researchers testing multi-model capabilities.
              </p>
              
              <ul className="space-y-3 pt-6 border-t border-slate-100 text-xs text-slate-600">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Access to active Free Models</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Interactive Playground chat limits</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Uncapped local knowledge base items</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => onEnterApp('chat')}
              className="mt-8 w-full py-3 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer shadow-xs"
            >
              Get Started Sandbox
            </button>
          </div>

          {/* Plan B */}
          <div className="p-8 rounded-3xl border border-indigo-100 bg-white shadow-lg relative flex flex-col justify-between">
            <div className="absolute top-4 right-4 bg-indigo-50 text-[#4f46e5] font-mono text-[8px] tracking-wider uppercase font-extrabold px-2.5 py-1 rounded-full">
              Recommended Pro
            </div>
            
            <div>
              <span className="text-[10px] font-mono uppercase bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full font-bold">All-Access Pass</span>
              <div className="my-5">
                <span className="text-4xl font-bold text-slate-900 font-display">$19</span>
                <span className="text-xs text-slate-400">/ month</span>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed mb-6">
                Tailored for professional programmers and operations administrators requiring priority speed.
              </p>

              <ul className="space-y-3 pt-6 border-t border-slate-100 text-xs text-slate-600">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#4f46e5] shrink-0" />
                  <span>Access to all premium Pro & Cloud Models</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#4f46e5] shrink-0" />
                  <span>Synchronous Dual comparison split-screen</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-[#4f46e5] shrink-0" />
                  <span>Full Admin Dashboard statistics</span>
                </li>
              </ul>
            </div>

            <button
              onClick={onEnterAuth}
              className="mt-8 w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-97 cursor-pointer"
            >
              Unlock Priority Access
            </button>
          </div>

        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-slate-100/40 py-16 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-sm font-medium italic text-slate-700 leading-relaxed mb-6">
            "We migrated our model testing setup to FrogeMind and saved dozens of coordinate coding hours. Comparing DeepSeek and GPT in split view is an absolute game changer."
          </p>
          <div className="flex items-center justify-center gap-2.5">
            <img 
              src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=80&q=80" 
              alt="developer reviewer portrait" 
              className="w-9 h-9 object-cover rounded-full border border-slate-205" 
            />
            <div className="text-left">
              <span className="text-xs font-bold text-slate-800 block">Sarah Chen</span>
              <span className="text-[9px] font-mono text-slate-400 font-semibold block uppercase">Senior Principal DevOps</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-100 py-12 text-center text-xs text-slate-400 font-mono">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <span>© 2026 FrogeMind Studio. All Rights Reserved.</span>
          <div className="flex gap-6">
            <a href="#features" className="hover:text-slate-700">FAQ</a>
            <a href="#demo" className="hover:text-slate-700">Privacy Policy</a>
            <a href="#pricing" className="hover:text-slate-700">Enterprise SLA</a>
          </div>
        </div>
      </footer>

    </div>
  );
}
