/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Database, 
  Search, 
  Plus, 
  Trash2, 
  Tag, 
  Calendar, 
  Activity, 
  CheckCircle2, 
  TrendingUp, 
  Clock, 
  Cpu,
  Brain
} from 'lucide-react';
import { StoredMemory } from '../../types';

interface MemoryVaultProps {
  memoriesList: StoredMemory[];
  onAddMemory: (content: string, tags: string[], strength: 'Core' | 'Retentive' | 'Fading') => void;
  onRemoveMemory: (id: string) => void;
}

export default function MemoryVault({ 
  memoriesList, 
  onAddMemory, 
  onRemoveMemory 
}: MemoryVaultProps) {
  
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [newContent, setNewContent] = useState<string>('');
  const [newTagsString, setNewTagsString] = useState<string>('metrics, reference');
  const [newStrength, setNewStrength] = useState<'Core' | 'Retentive' | 'Fading'>('Retentive');

  // Submit and clean
  const handleInsert = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContent.trim()) return;

    const parsedTags = newTagsString
      .split(',')
      .map(t => t.trim().toLowerCase())
      .filter(t => t.length > 0);

    onAddMemory(newContent, parsedTags, newStrength);
    setNewContent('');
    setNewTagsString('metrics, reference');
  };

  // Filter memories matching search tags
  const filteredMemories = memoriesList.filter(memo => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      memo.content.toLowerCase().includes(q) ||
      memo.tags.some(t => t.toLowerCase().includes(q))
    );
  });

  return (
    <div className="flex-1 overflow-y-auto bg-white p-6 sm:p-8 text-slate-800 font-sans select-none">
      
      {/* Header element */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-150 pb-6 mb-8 mt-2">
        <div>
          <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-[#4f46e5]">My Saved Facts</span>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            My Memory Vault
          </h1>
          <p className="text-slate-500 text-xs mt-1.5 leading-relaxed">
            Save custom facts, instructions, or rules here. Active AI models will read these notes automatically when replying to your chat messages.
          </p>
        </div>

        {/* Search bar block */}
        <div className="relative self-start md:self-center">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search saved notes..." 
            className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 focus:border-indigo-400 rounded-xl text-xs text-slate-700 outline-none w-64 focus:bg-white transition-all placeholder:text-slate-400"
          />
        </div>
      </div>

      {/* Grid splits: Memory creation form + Interactive memory timeline list */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        
        {/* Creation section form */}
        <div className="bg-slate-50/50 border border-slate-205 border-slate-200/60 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center gap-2 mb-4 text-indigo-650">
            <Brain className="w-4 h-4 text-indigo-650" />
            <h2 className="text-xs font-mono uppercase font-black text-slate-700 tracking-wider">
              Save a New Fact
            </h2>
          </div>

          <form onSubmit={handleInsert} className="space-y-4">
            <div>
              <label className="text-[10px] uppercase font-mono tracking-wider text-slate-450 font-bold block mb-1">
                What should the AI remember?
              </label>
              <textarea
                required
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                placeholder="e.g. My company name is Sunshine Bakery. I prefer conversational, friendly draft files."
                rows={3}
                className="w-full p-3 bg-white border border-slate-200 focus:border-indigo-400 rounded-xl text-xs sm:text-sm text-slate-800 outline-none resize-none transition-all placeholder:text-slate-400"
              />
            </div>

            <div>
              <label className="text-[10px] uppercase font-mono tracking-wider text-slate-455 font-bold block mb-1">
                Search tags (separate with commas)
              </label>
              <input
                type="text"
                required
                value={newTagsString}
                onChange={(e) => setNewTagsString(e.target.value)}
                placeholder="bakery, profile, work"
                className="w-full px-3 py-2 bg-white border border-slate-200 focus:border-indigo-400 rounded-xl text-xs text-slate-800 outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] uppercase font-mono tracking-wider text-slate-455 font-bold block mb-2">
                How long should the AI remember this?
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['Core', 'Retentive', 'Fading'] as const).map((lvl) => {
                  let userTag = "Keep Temp";
                  if (lvl === 'Core') userTag = "Keep Forever";
                  if (lvl === 'Fading') userTag = "Forget Soon";
                  return (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => setNewStrength(lvl)}
                      className={`py-1.5 rounded-lg text-[9px] font-mono font-bold text-center border transition-all cursor-pointer ${
                        newStrength === lvl 
                          ? 'bg-indigo-600 border-transparent text-white shadow-xs' 
                          : 'bg-white border-slate-200 text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      {userTag.toUpperCase()}
                    </button>
                  );
                })}
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs transition-transform active:scale-97 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Save and Remember</span>
            </button>
          </form>

          {/* Quick instructions memo */}
          <div className="mt-5 border-t border-slate-100 pt-4 text-[10px] text-slate-450 leading-relaxed font-sans font-semibold">
            "Forever" memories are always read by the AI, while "Forget soon" notes will be removed over time as you chat.
          </div>
        </div>

        {/* Memory list */}
        <div className="lg:col-span-2 space-y-4">
          
          <div className="flex items-center justify-between font-mono text-xs text-slate-400 border-b border-slate-150 pb-3">
            <div className="flex items-center gap-2 font-bold">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <span>My Saved Memories Log</span>
            </div>
            <span className="font-bold">Count: <b className="text-indigo-600 font-extrabold">{filteredMemories.length} item{filteredMemories.length !== 1 && 's'}</b></span>
          </div>

          <div className="space-y-4">
            {filteredMemories.map((memo) => {
              const dateStr = new Date(memo.createdAt).toLocaleDateString([], {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              });

              return (
                <div 
                  key={memo.id}
                  className="p-5 rounded-2xl border border-slate-100 bg-slate-50/20 flex flex-col sm:flex-row sm:items-start justify-between gap-4 hover:border-slate-225 hover:border-slate-200 hover:bg-white transition-all shadow-xs"
                >
                  <div className="space-y-3 min-w-0">
                    
                    {/* Tags and timer */}
                    <div className="flex flex-wrap items-center gap-2 text-[10px] font-mono font-bold">
                      
                      {/* Strength flag indicator */}
                      <span className={`px-2 py-0.5 rounded-full font-black uppercase tracking-wider text-[8px] ${
                        memo.strength === 'Core' ? 'bg-red-50 text-slate-800 border border-red-200' :
                        memo.strength === 'Retentive' ? 'bg-purple-50 text-indigo-700 border border-purple-200' :
                        'bg-slate-100 text-slate-500 border border-slate-150'
                      }`}>
                        {memo.strength === 'Core' ? 'Keep Forever' : memo.strength === 'Retentive' ? 'Keep Temp' : 'Forget Soon'}
                      </span>

                      <span className="text-slate-400 flex items-center gap-1 font-bold">
                        <Calendar className="w-3.5 h-3.5" />
                        <span>{dateStr}</span>
                      </span>

                    </div>

                    {/* Content text */}
                    <p className="text-xs sm:text-sm text-slate-700 leading-relaxed max-w-xl font-sans select-text">
                      {memo.content}
                    </p>

                    {/* Tags labels row */}
                    {memo.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {memo.tags.map((tg, i) => (
                          <span 
                            key={i} 
                            className="inline-flex items-center gap-1 bg-white border border-slate-150 text-slate-500 text-[9.5px] px-2.5 py-0.5 rounded-full font-mono font-bold"
                          >
                            <Tag className="w-2.5 h-2.5 text-indigo-505 text-indigo-500" />
                            <span>{tg}</span>
                          </span>
                        ))}
                      </div>
                    )}

                  </div>

                  {/* Absolute remove options */}
                  <button
                    onClick={() => onRemoveMemory(memo.id)}
                    className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all self-end sm:self-center border border-transparent hover:border-red-100 cursor-pointer"
                    title="Evict memory node"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>

                </div>
              );
            })}

            {filteredMemories.length === 0 && (
              <div className="py-16 text-center border-2 border-dashed border-slate-150 bg-slate-50/50 rounded-3xl">
                <Brain className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <h3 className="text-sm font-bold text-slate-700 mb-1">Your Memory Vault is Empty</h3>
                <p className="text-xs text-slate-400 max-w-sm mx-auto pr-3 pl-3 leading-relaxed">
                  Use the left panel to save custom facts or helpful rules for the AI chatbot to follow.
                </p>
              </div>
            )}

          </div>

        </div>

      </div>

    </div>
  );
}
