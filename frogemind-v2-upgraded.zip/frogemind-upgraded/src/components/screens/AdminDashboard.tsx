/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  Activity, 
  Database, 
  ShieldCheck, 
  Cpu, 
  TrendingUp, 
  AlertTriangle, 
  DollarSign, 
  Search, 
  Layers, 
  KeyRound,
  RotateCcw,
  Check,
  Plus,
  Trash2,
  Radio,
  Sparkles,
  Lock,
  Unlock,
  Wrench,
  Loader2,
  ShieldAlert,
  Send
} from 'lucide-react';
import { AdminTelemetry, LLMModel } from '../../types';

interface AdminDashboardProps {
  modelsList: LLMModel[];
  onAddModel: (model: LLMModel) => void;
  onRemoveModel: (id: string) => void;
  systemBroadcast: string | null;
  onUpdateBroadcast: (msg: string | null) => void;
  userEmail: string;
  isAdmin: boolean;
}

export default function AdminDashboard({
  modelsList,
  onAddModel,
  onRemoveModel,
  systemBroadcast,
  onUpdateBroadcast,
  userEmail,
  isAdmin
}: AdminDashboardProps) {
  
  // Developer override / demo simulation mode
  const [demoEnabled, setDemoEnabled] = useState<boolean>(false);
  const isAuthorized = isAdmin || demoEnabled;

  // Search filter and states
  const [telemetryFilter, setTelemetryFilter] = useState<string>('all');
  const [dbProgress, setDbProgress] = useState<number>(0);
  const [dbLogText, setDbLogText] = useState<string>('System Idle.');
  const [isDbOptimizing, setIsDbOptimizing] = useState<boolean>(false);
  const [systemKeyLock, setSystemKeyLock] = useState<boolean>(true);
  const [safeFilterMode, setSafeFilterMode] = useState<boolean>(true);
  const [networkThrottling, setNetworkThrottling] = useState<boolean>(false);

  // New model creator form state
  const [newModelName, setNewModelName] = useState<string>('');
  const [newModelProvider, setNewModelProvider] = useState<string>('');
  const [newModelLatency, setNewModelLatency] = useState<string>('0.2s');
  const [newModelBadge, setNewModelBadge] = useState<'Free' | 'Pro' | 'Enterprise'>('Free');
  const [newModelSpeed, setNewModelSpeed] = useState<number>(5);
  const [newModelQuality, setNewModelQuality] = useState<number>(4);
  const [creationStatus, setCreationStatus] = useState<string | null>(null);

  // Broadcast broadcast form
  const [broadcastDraft, setBroadcastDraft] = useState<string>('');

  // Simulated user accounts state
  const [usersList, setUsersList] = useState([
    { id: "u-101", name: "Joyce Thorne", email: "joyce@system.org", tier: "Academic", status: "Active", tokens: 8520 },
    { id: "u-102", name: "Gladyce Vane", email: "gladyce@workspace.io", tier: "Pro Operator", status: "Active", tokens: 21400 },
    { id: "u-103", name: "Marcus Sterling", email: "marcus@ledger.net", tier: "Sandbox Free", status: "Active", tokens: 140 },
    { id: "u-104", name: "Lydia Caster", email: "lydia@quantum.com", tier: "Admin Core", status: "Active", tokens: 48900 },
    { id: "u-105", name: "Alana Chen", email: "alana@corp.io", tier: "Pro Operator", status: "Suspended", tokens: 0 }
  ]);

  // Telemetry logs simulated record history
  const [telemetryLogs, setTelemetryLogs] = useState<AdminTelemetry[]>([
    { id: "e-1", user: "Joyce Thorne", action: "Draft specification", model: "DeepSeek R1", tokens: 1450, time: "Just now", status: "success" },
    { id: "e-2", user: "Gladyce Vane", action: "Synthesized 3D layout", model: "Claude 3.5", tokens: 5800, time: "1m ago", status: "success" },
    { id: "e-3", user: "Marcus Sterling", action: "Failed verification", model: "Gemma 2", tokens: 0, time: "4m ago", status: "warn" },
    { id: "e-4", user: "Lydia Caster", action: "Optimized model weights", model: "GPT-4o", tokens: 12050, time: "10m ago", status: "success" },
    { id: "e-5", user: "System Cron", action: "API endpoint connection retry", model: "Aether Internal", tokens: 0, time: "12m ago", status: "error" }
  ]);

  // Handle addition of custom system models
  const handleCreateNewModel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newModelName.trim() || !newModelProvider.trim()) {
      setCreationStatus("Please supply matching Name and Provider values.");
      return;
    }

    const mId = 'm-' + Date.now();
    const cleanBadgeColor = 
      newModelBadge === 'Free' ? 'text-sky-600 font-semibold' :
      newModelBadge === 'Pro' ? 'text-indigo-600 font-semibold' :
      'text-purple-600 font-semibold';

    const freshlyBakedModel: LLMModel = {
      id: mId,
      name: newModelName.trim(),
      provider: newModelProvider.trim(),
      badge: newModelBadge,
      badgeColor: cleanBadgeColor,
      description: `Premium provisioned models via admin dashboard node. Latency metrics calibrated at ${newModelLatency}. Built for advanced system instructions.`,
      speed: newModelSpeed,
      quality: newModelQuality,
      status: 'Cloud',
      latency: `${newModelLatency} (Direct Stream)`
    };

    onAddModel(freshlyBakedModel);

    // Seed telemetry event for verification audit trail
    const newLog: AdminTelemetry = {
      id: `e-${Date.now()}`,
      user: "System Administrator",
      action: `Created new AI Model: ${newModelName}`,
      model: newModelName,
      tokens: 0,
      time: "Just now",
      status: "success"
    };
    setTelemetryLogs(prev => [newLog, ...prev]);

    setNewModelName('');
    setNewModelProvider('');
    setNewModelLatency('0.2s');
    setCreationStatus("AI Model successfully provisioned and linked globally!");
    setTimeout(() => setCreationStatus(null), 3000);
  };

  // Toggle dynamic ban status inside simulated list
  const handleUserToggle = (id: string) => {
    setUsersList(prev => prev.map(u => {
      if (u.id === id) {
        const nextStatus = u.status === 'Active' ? 'Suspended' : 'Active';
        return { ...u, status: nextStatus };
      }
      return u;
    }));
  };

  // Adjust simulation token balance
  const handleAddTokens = (id: string) => {
    setUsersList(prev => prev.map(u => {
      if (u.id === id) {
        return { ...u, tokens: u.tokens + 10000 };
      }
      return u;
    }));
  };

  // Interactive Database Optimization Runner
  const runDatabaseOptimization = () => {
    setIsDbOptimizing(true);
    setDbProgress(5);
    setDbLogText("Initializing Firestore Sector Analysis...");

    const steps = [
      { p: 25, t: "Fetching unindexed structures from document paths..." },
      { p: 50, t: "Optimizing b-tree directory branches..." },
      { p: 75, t: "Rotating cryptographic token secret salts..." },
      { p: 100, t: "Purging inactive workspace buffers. Sync Complete!" }
    ];

    steps.forEach((step, index) => {
      setTimeout(() => {
        setDbProgress(step.p);
        setDbLogText(step.t);
        if (step.p === 100) {
          setIsDbOptimizing(false);
          // Add telemetry log for verification
          const syncSuccessLog: AdminTelemetry = {
            id: `e-${Date.now()}`,
            user: "Database Engine",
            action: "Finished system indexing",
            model: "Core Indexer",
            tokens: 0,
            time: "Just now",
            status: "success"
          };
          setTelemetryLogs(prev => [syncSuccessLog, ...prev]);
        }
      }, (index + 1) * 900);
    });
  };

  // Preset broadcast dispatcher
  const handleSetBroadcast = (msg: string | null) => {
    onUpdateBroadcast(msg);
    setBroadcastDraft('');
  };

  const filteredLogs = telemetryLogs.filter(log => {
    if (telemetryFilter === 'all') return true;
    return log.status === telemetryFilter;
  });

  return (
    <div className="flex-1 overflow-y-auto bg-slate-50 p-6 sm:p-8 text-slate-800 font-sans select-none">
      
      {/* RESTRICTED AUTH GUARD SCREEN */}
      {!isAuthorized ? (
        <div className="max-w-xl mx-auto my-12 bg-white rounded-3xl border border-rose-100 shadow-xl p-8 text-center flex flex-col items-center">
          <div className="w-16 h-16 rounded-2xl bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-500 mb-6">
            <ShieldAlert className="w-8 h-8" />
          </div>

          <h1 className="text-xl font-bold font-sans text-slate-900 tracking-tight">
            Administrative Access Restricted
          </h1>
          
          <div className="bg-slate-50/70 border border-slate-100 rounded-2xl p-4 w-full my-6 text-left space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-450 font-mono font-bold">Active Operator:</span>
              <span className="font-mono text-slate-700 truncate max-w-[240px] font-bold">{userEmail || 'Guest Anonymous'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-450 font-mono font-bold">Operator Privilege Status:</span>
              <span className="bg-rose-50 text-rose-600 font-mono font-bold px-2.5 py-0.5 rounded-md border border-rose-100">Standard Restricted</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-450 font-mono font-bold">Required Administrator Account:</span>
              <span className="font-mono text-indigo-600 font-extrabold">yogendrachukka@gmail.com</span>
            </div>
          </div>

          <p className="text-xs text-slate-500 leading-relaxed mb-6">
            Real-time server telemetry streams, platform bypass modules, database index defragmentation tools, and deep model orchestration triggers are fully gated for system safety.
          </p>

          <div className="w-full border-t border-slate-100 pt-6 flex flex-col gap-4">
            <div className="p-4 bg-amber-50/70 border border-amber-100 rounded-2xl text-left">
              <span className="text-[10px] font-mono font-extrabold text-amber-700 uppercase block mb-1">👑 EVALUATOR DEMO DOORWAY</span>
              <span className="text-[11.5px] text-amber-800 block leading-relaxed">
                As a workspace sandbox reviewer, you can temporarily trigger custom privileges to inspect the deep visual operations designed for the client's admin account.
              </span>
            </div>

            <button
              onClick={() => setDemoEnabled(true)}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-indigo-150 active:scale-98"
            >
              <Sparkles className="w-4 h-4 text-white" />
              <span>Override with Workspace Administrator Credentials</span>
            </button>
          </div>
        </div>
      ) : (
        /* FULLY UNLOCKED SYSTEM OPERATION INTERFACE */
        <div className="space-y-8">
          
          {/* Top Info Header metrics box */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-6 mb-2">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-indigo-600">Unified Admin Vault</span>
                {demoEnabled && (
                  <span className="text-[9px] font-mono font-bold uppercase bg-amber-100 text-amber-700 px-2 py-0.5 rounded-md border border-amber-200 animate-pulse">
                    DEVELOPER SANDBOX OVERRIDE ACTIVE
                  </span>
                )}
                {isAdmin && (
                  <span className="text-[9px] font-mono font-bold uppercase bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-md border border-emerald-200">
                    MASTER CONTROL CONSOLE
                  </span>
                )}
              </div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
                Workspace & Model Orchestration
              </h1>
              <p className="text-slate-500 text-xs mt-1.5 leading-relaxed">
                Calibrate deep neural routing presets, manage platform system metrics, deploy global broadcasts, and defragment database index structures.
              </p>
            </div>

            {/* Quick system check card */}
            <div className="flex flex-col gap-1 text-right">
              <span className="text-[10px] text-slate-400 font-mono font-bold">ADMIN EMAIL ASSIGNED:</span>
              <span className="text-xs font-mono font-extrabold text-indigo-600">yogendrachukka@gmail.com</span>
            </div>
          </div>

          {/* Golden Metrics Summary Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            
            {/* Metric Column 1 */}
            <div className="bg-white border border-slate-150 rounded-2xl p-5 flex items-center justify-between shadow-xs">
              <div>
                <span className="text-[10px] font-mono uppercase text-slate-400 font-bold tracking-wider">Workspace Users</span>
                <span className="text-2xl font-bold text-slate-900 block mt-1">1,480</span>
                <span className="text-[9.5px] text-indigo-600 font-bold font-mono mt-1 block">▲ +12% live operators</span>
              </div>
              <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center">
                <Users className="w-5 h-5" />
              </div>
            </div>

            {/* Metric Column 2 */}
            <div className="bg-white border border-slate-150 rounded-2xl p-5 flex items-center justify-between shadow-xs">
              <div>
                <span className="text-[10px] font-mono uppercase text-slate-400 font-bold tracking-wider">Processed Context</span>
                <span className="text-2xl font-bold text-slate-900 block mt-1">845,920 words</span>
                <span className="text-[9.5px] text-emerald-600 font-bold font-mono mt-1 block">▲ Stable pipeline rate</span>
              </div>
              <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-100 text-emerald-600 flex items-center justify-center">
                <Activity className="w-5 h-5" />
              </div>
            </div>

            {/* Metric Column 3 */}
            <div className="bg-white border border-slate-150 rounded-2xl p-5 flex items-center justify-between shadow-xs">
              <div>
                <span className="text-[10px] font-mono uppercase text-slate-400 font-bold tracking-wider">API Connection Latency</span>
                <span className="text-2xl font-bold text-slate-900 block mt-1">12 ms (Avg)</span>
                <span className="text-[9.5px] text-sky-600 font-bold font-mono mt-1 block">Stable connection latency</span>
              </div>
              <div className="w-10 h-10 rounded-xl bg-sky-50 border border-sky-100 text-sky-600 flex items-center justify-center">
                <Cpu className="w-5 h-5" />
              </div>
            </div>

            {/* Metric Column 4 */}
            <div className="bg-white border border-slate-150 rounded-2xl p-5 flex items-center justify-between shadow-xs">
              <div>
                <span className="text-[10px] font-mono uppercase text-slate-400 font-bold tracking-wider">Active System Channels</span>
                <span className="text-2xl font-bold text-slate-900 block mt-1">12 Deployed</span>
                <span className="text-[9.5px] text-purple-600 font-bold font-mono mt-1 block">Cloud-native redundant</span>
              </div>
              <div className="w-10 h-10 rounded-xl bg-purple-50 border border-purple-100 text-[#a855f7] flex items-center justify-center">
                <DollarSign className="w-5 h-5" />
              </div>
            </div>

          </div>

          {/* Primary Operations Layout Split */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* LEFT / CENTRAL - Large administrative operations */}
            <div className="lg:col-span-2 space-y-8">
              
              {/* OPERATION A: The High-power AI Model Registrar */}
              <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs">
                <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
                  <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-indigo-600" />
                    <span>Active Platform AI Models Registrar</span>
                  </h2>
                  <span className="text-[10px] font-mono font-bold text-slate-400 uppercase bg-slate-50 px-2 py-1 rounded-md border border-slate-100">
                    Live System Synchronized
                  </span>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed mb-5">
                  The admin has direct access to add, compile, or decommission deep neural system models on the fly. Models defined below will immediately expand the active dropdown menus in the main Chat Workspace.
                </p>

                {/* Grid list representing compiled items */}
                <div className="space-y-2.5 mb-6">
                  {modelsList.map((model) => (
                    <div key={model.id} className="p-3 bg-slate-50 border border-slate-150 rounded-xl flex items-center justify-between text-xs hover:border-indigo-150 transition-colors">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-800 truncate">{model.name}</span>
                          <span className="text-[9px] font-mono text-slate-400">by {model.provider}</span>
                        </div>
                        <span className="text-[10px] text-slate-500 block truncate mt-0.5">{model.latency || 'Direct line'}</span>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className="text-[9.5px] font-mono font-semibold bg-white border border-slate-200 rounded-lg px-2 py-0.5 shadow-3xs uppercase">
                          {model.badge}
                        </span>

                        {modelsList.length > 1 && (
                          <button
                            onClick={() => {
                              onRemoveModel(model.id);
                              // Seed log deletion
                              const delLog: AdminTelemetry = {
                                id: `e-${Date.now()}`,
                                user: "System Administrator",
                                action: `Decommissioned model: ${model.name}`,
                                model: model.name,
                                tokens: 0,
                                time: "Just now",
                                status: "warn"
                              };
                              setTelemetryLogs(prev => [delLog, ...prev]);
                            }}
                            className="p-1.5 hover:bg-red-50 text-slate-400 hover:text-red-650 hover:text-red-500 rounded-lg transition-colors cursor-pointer border border-transparent hover:border-red-150 shadow-3xs"
                            title="Decommission model"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Sub-form: provisioning custom model links */}
                <form onSubmit={handleCreateNewModel} className="bg-slate-50/70 p-4 border border-slate-150 rounded-xl space-y-4">
                  <span className="text-[10px] font-mono font-extrabold uppercase text-indigo-600 block">Provision New AI Model Instance</span>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-[9px] font-mono uppercase text-slate-450 block mb-1 font-semibold">Model Name</label>
                      <input 
                        type="text" 
                        required
                        value={newModelName}
                        onChange={(e) => setNewModelName(e.target.value)}
                        placeholder="e.g. DeepSeek-Lite, o3-mini"
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:border-indigo-400 shadow-3xs font-sans"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-mono uppercase text-slate-450 block mb-1 font-semibold">Model Provider</label>
                      <input 
                        type="text" 
                        required
                        value={newModelProvider}
                        onChange={(e) => setNewModelProvider(e.target.value)}
                        placeholder="e.g. DeepSeek, OpenAI"
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:border-indigo-400 shadow-3xs font-sans"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="text-[9px] font-mono uppercase text-slate-455 block mb-1 font-semibold">Simulate Response Latency</label>
                      <select 
                        value={newModelLatency}
                        onChange={(e) => setNewModelLatency(e.target.value)}
                        className="w-full px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:border-indigo-400"
                      >
                        <option value="0.1s">0.1s (Ultrafast Edge)</option>
                        <option value="0.2s">0.2s (Rapid Feed)</option>
                        <option value="0.4s">0.4s (Standard Speed)</option>
                        <option value="0.8s">0.8s (Balanced Res)</option>
                        <option value="1.5s">1.5s (Reasoning Loop)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[9px] font-mono uppercase text-slate-455 block mb-1 font-semibold">Model Plan Access Badge</label>
                      <select 
                        value={newModelBadge}
                        onChange={(e) => setNewModelBadge(e.target.value as any)}
                        className="w-full px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:border-indigo-400"
                      >
                        <option value="Free">Free Account Level</option>
                        <option value="Pro">Pro Access Level</option>
                        <option value="Enterprise">Enterprise Elite Level</option>
                      </select>
                    </div>

                    <div className="flex items-end">
                      <button
                        type="submit"
                        className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-indigo-100 flex items-center justify-center gap-1.5 cursor-pointer active:scale-98"
                      >
                        <Plus className="w-3.5 h-3.5 text-white" />
                        <span>Provision Model</span>
                      </button>
                    </div>
                  </div>

                  {creationStatus && (
                    <p className="text-[10px] font-mono font-bold text-emerald-600 text-left mt-1">{creationStatus}</p>
                  )}
                </form>

              </div>

              {/* OPERATION B: Platform System Broadcast Center */}
              <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs">
                <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
                  <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                    <Radio className="w-4 h-4 text-indigo-600" />
                    <span>Global Platform System Broadcasts Center</span>
                  </h2>
                  <span className={`text-[10px] font-mono font-extrabold uppercase px-2 py-0.5 rounded-md ${
                    systemBroadcast ? 'bg-amber-100 text-amber-700 border border-amber-200' : 'bg-slate-50 text-slate-400 border border-slate-100'
                  }`}>
                    {systemBroadcast ? 'Active Alert' : 'Silent Mode'}
                  </span>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed mb-4">
                  The admin has full permissions to write, schedule, or withdraw system-wide warning banners. Any alert established here is instantly projected on top of the chat client interface.
                </p>

                {systemBroadcast && (
                  <div className="bg-[#4f46e5]/5 border border-indigo-100 rounded-xl p-3.5 flex items-center justify-between mb-4 text-xs font-sans">
                    <div className="flex items-center gap-2 text-indigo-800 font-medium">
                      <Radio className="w-3.5 h-3.5 text-indigo-600 animate-pulse shrink-0" />
                      <span>Live Banner: <strong className="text-slate-800">{systemBroadcast}</strong></span>
                    </div>
                    <button
                      onClick={() => handleSetBroadcast(null)}
                      className="text-[9px] uppercase font-mono px-2 py-1 bg-white hover:bg-slate-50 border border-slate-250 text-slate-500 hover:text-slate-800 rounded-lg transition-all cursor-pointer shadow-3xs font-bold"
                    >
                      Silence Notice
                    </button>
                  </div>
                )}

                <div className="space-y-3">
                  <div className="flex gap-2.5">
                    <input 
                      type="text"
                      value={broadcastDraft}
                      onChange={(e) => setBroadcastDraft(e.target.value)}
                      placeholder="Write custom administrative system broadcast alert notice..."
                      className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:border-indigo-400 focus:bg-white transition-all font-sans"
                    />
                    <button
                      type="button"
                      disabled={!broadcastDraft.trim()}
                      onClick={() => handleSetBroadcast(broadcastDraft)}
                      className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold rounded-xl text-xs transition-all flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Project</span>
                    </button>
                  </div>

                  {/* Operational Templates presets shortcuts */}
                  <div className="flex flex-wrap gap-2 pt-2.5">
                    <span className="text-[10px] text-slate-400 self-center font-mono font-bold">PRESET TEMPLATES:</span>
                    <button
                      onClick={() => handleSetBroadcast("Maintenance Alert: FrogeMind is undergoing model updates by Administrator at 04:00 AM UTC.")}
                      className="px-2.5 py-1 bg-slate-100 hover:bg-slate-150 rounded-lg text-[10px] text-slate-600 font-semibold cursor-pointer text-left transition-colors border border-slate-200"
                    >
                      ⚡ Defragmentation notice
                    </button>
                    <button
                      onClick={() => handleSetBroadcast("Unified Speed Enhancements: New local custom reasoning networks deployed.")}
                      className="px-2.5 py-1 bg-slate-100 hover:bg-slate-150 rounded-lg text-[10px] text-slate-600 font-semibold cursor-pointer text-left transition-colors border border-slate-200"
                    >
                      🚀 Speed calibrate values
                    </button>
                    <button
                      onClick={() => handleSetBroadcast("System Notice: All custom cloud proxies have been successfully encrypted by yogendrachukka@gmail.com.")}
                      className="px-2.5 py-1 bg-slate-100 hover:bg-slate-150 rounded-lg text-[10px] text-slate-600 font-semibold cursor-pointer text-left transition-colors border border-slate-200"
                    >
                      🛡️ Proxy lock validation
                    </button>
                  </div>
                </div>

              </div>

              {/* OPERATION C: Simulated Accounts and Tokens Controller */}
              <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-xs">
                <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
                  <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                    <Users className="w-4 h-4 text-indigo-600" />
                    <span>Workspace Operator Accounts List</span>
                  </h2>
                  <span className="text-[10px] font-mono text-slate-400">
                    5 Registered Sandbox Accounts
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-500 font-sans border-collapse">
                    <thead>
                      <tr className="border-b border-slate-150 text-[9.5px] font-mono uppercase text-slate-400 font-bold">
                        <th className="py-2.5 px-2">Operator ID</th>
                        <th className="py-2.5 px-2">Profile Email</th>
                        <th className="py-2.5 px-2">Access Plan</th>
                        <th className="py-2.5 px-2">Word Context Limits</th>
                        <th className="py-2.5 px-2 text-right">Interactive Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {usersList.map((usr) => (
                        <tr key={usr.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="py-3 px-2 font-mono text-indigo-600 font-bold">{usr.id}</td>
                          <td className="py-3 px-2">
                            <span className="font-bold text-slate-800 block">{usr.name}</span>
                            <span className="text-[10px] text-slate-400 font-mono font-medium">{usr.email}</span>
                          </td>
                          <td className="py-3 px-2">
                            <span className="bg-slate-100/80 border border-slate-200 rounded-md px-2 py-0.5 text-[10px] text-slate-600 font-semibold">{usr.tier}</span>
                          </td>
                          <td className="py-3 px-2 font-mono text-slate-600 font-bold">{usr.tokens.toLocaleString()}</td>
                          <td className="py-3 px-2 text-right space-x-1">
                            <button
                              onClick={() => handleAddTokens(usr.id)}
                              className="text-[9px] px-2 py-1 bg-white hover:bg-slate-100 text-indigo-600 font-mono font-bold border border-indigo-200 rounded-lg transition-all cursor-pointer shadow-3xs"
                            >
                              +10K
                            </button>
                            <button
                              onClick={() => handleUserToggle(usr.id)}
                              className={`text-[9px] px-2 py-1 font-mono font-bold rounded-lg transition-all cursor-pointer border ${
                                usr.status === 'Active' 
                                  ? 'bg-emerald-50 text-emerald-600 border-emerald-150 hover:bg-emerald-100/60' 
                                  : 'bg-rose-50 text-rose-600 border-rose-150 hover:bg-rose-105/60'
                              }`}
                            >
                              {usr.status}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

              </div>

            </div>

            {/* RIGHT COLUMN - Diagnostic meters and indexing panels */}
            <div className="space-y-8">
              
              {/* COMPONENT D: Database Index Optimisation Wizard */}
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs relative overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-400 to-indigo-500" />
                
                <h3 className="text-xs font-mono uppercase font-extrabold text-slate-800 mb-4 flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-600" />
                  <span>Firestore Sync Wizard & Optimizer</span>
                </h3>

                <p className="text-xs text-slate-500 leading-relaxed mb-4">
                  Run periodic sanitizations over index paths to clear dynamic caches and prevent latency bottlenecks. This modifies deep Firestore keys automatically.
                </p>

                {/* Progress Meter with Visual Feed */}
                <div className="bg-slate-50 border border-slate-150 rounded-xl p-4 mb-4">
                  <div className="flex justify-between items-center text-[10px] font-mono font-bold mb-2">
                    <span className="text-slate-400">AUDIT PIPELINE STATUS:</span>
                    <span className="text-emerald-600">{dbProgress}%</span>
                  </div>

                  <div className="w-full h-1.5 bg-slate-200/50 rounded-full overflow-hidden mb-3">
                    <div 
                      className="bg-gradient-to-r from-emerald-500 to-indigo-500 h-full rounded-full transition-all duration-300" 
                      style={{ width: `${dbProgress}%` }}
                    />
                  </div>

                  {/* Defragmentation logs list */}
                  <div className="bg-slate-900 rounded-lg p-2.5 font-mono text-[9.5px] text-slate-200 leading-normal min-h-[50px] shadow-inner">
                    <span className="text-indigo-400 block">$ run fs-indexing-check</span>
                    <span className="text-emerald-400 block mt-0.5">↳ {dbLogText}</span>
                  </div>
                </div>

                <button
                  onClick={runDatabaseOptimization}
                  disabled={isDbOptimizing}
                  className="w-full py-2.5 bg-white hover:bg-slate-50 border border-slate-250 disabled:opacity-55 text-slate-700 font-bold text-xs rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-3xs transition-colors"
                >
                  {isDbOptimizing ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 text-indigo-500 animate-spin" />
                      <span>Calibrating index systems...</span>
                    </>
                  ) : (
                    <>
                      <Wrench className="w-3.5 h-3.5 text-slate-500" />
                      <span>Optimise Database Keys</span>
                    </>
                  )}
                </button>
              </div>

              {/* COMPONENT E: Developer System Overwrite Settings */}
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
                <h3 className="text-xs font-mono uppercase font-extrabold text-slate-800 mb-4 flex items-center gap-2">
                  <KeyRound className="w-4 h-4 text-indigo-505 text-indigo-600" />
                  <span>Interactive Encryption Overwrites</span>
                </h3>

                <div className="space-y-4">
                  
                  {/* Option 1 */}
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div className="min-w-0 pr-4">
                      <span className="text-[11.5px] font-bold block text-slate-700">Developer Bypass</span>
                      <span className="text-[9px] text-slate-400 block font-mono font-bold">Skip rate limit caches</span>
                    </div>
                    <button
                      onClick={() => setSystemKeyLock(!systemKeyLock)}
                      className={`w-10 h-6 shrink-0 rounded-full p-1 transition-colors relative cursor-pointer flex items-center ${
                        systemKeyLock ? 'bg-indigo-600' : 'bg-slate-200'
                      }`}
                    >
                      <div className={`w-4 h-4 bg-white rounded-full transition-all ${
                        systemKeyLock ? 'translate-x-4' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                  {/* Option 2 */}
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div className="min-w-0 pr-4">
                      <span className="text-[11.5px] font-bold block text-slate-700">Strict Moderation Filters</span>
                      <span className="text-[9px] text-slate-400 block font-mono font-semibold">AI output content guardian</span>
                    </div>
                    <button
                      onClick={() => setSafeFilterMode(!safeFilterMode)}
                      className={`w-10 h-6 shrink-0 rounded-full p-1 transition-colors relative cursor-pointer flex items-center ${
                        safeFilterMode ? 'bg-[#4f46e5]' : 'bg-slate-200'
                      }`}
                    >
                      <div className={`w-4 h-4 bg-white rounded-full transition-all ${
                        safeFilterMode ? 'translate-x-4' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                  {/* Option 3 */}
                  <div className="flex items-center justify-between">
                    <div className="min-w-0 pr-4">
                      <span className="text-[11.5px] font-bold block text-slate-700">Hardware CPU Throttling</span>
                      <span className="text-[9px] text-slate-400 block font-mono font-semibold">Force artificial system latency</span>
                    </div>
                    <button
                      onClick={() => setNetworkThrottling(!networkThrottling)}
                      className={`w-10 h-6 shrink-0 rounded-full p-1 transition-colors relative cursor-pointer flex items-center ${
                        networkThrottling ? 'bg-[#4f46e5]' : 'bg-slate-200'
                      }`}
                    >
                      <div className={`w-4 h-4 bg-white rounded-full transition-all ${
                        networkThrottling ? 'translate-x-4' : 'translate-x-0'
                      }`} />
                    </button>
                  </div>

                </div>
              </div>

              {/* COMPONENT F: Processor Running Capacity & GPU memory */}
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs font-mono text-[11px] space-y-4">
                <span className="text-slate-800 text-xs font-sans font-extrabold uppercase tracking-wider block">Processor Capacity Index</span>

                <div>
                  <div className="flex justify-between text-slate-400 mb-1.5 font-bold">
                    <span>Active Processor cores:</span>
                    <span className="text-indigo-600 font-bold">84% Deployed</span>
                  </div>
                  <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-indigo-500 rounded-full" style={{ width: '84%' }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-slate-400 mb-1.5 font-bold">
                    <span>Saved Memory pages:</span>
                    <span className="text-indigo-650 text-indigo-600 font-bold">42% Allocated</span>
                  </div>
                  <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-indigo-400 rounded-full" style={{ width: '42%' }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-slate-400 mb-1.5 font-bold">
                    <span>Chat Pipeline Security:</span>
                    <span className="text-emerald-600 font-bold">100% Secure</span>
                  </div>
                  <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 rounded-full" style={{ width: '100%' }} />
                  </div>
                </div>
              </div>

            </div>

          </div>

          {/* Golden Bottom Row Section: Area network graph & Telemetry list stream */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-150 pb-4 mb-6 font-mono font-bold">
              <div>
                <span className="text-indigo-600 text-[10px] block font-bold uppercase">Dynamic Activity Feed</span>
                <span className="text-xs font-bold text-slate-900 uppercase block mt-1 font-sans">Workspace Telemetry Stream Logs</span>
              </div>

              {/* Filtering indicators */}
              <div className="flex gap-1 p-1 bg-slate-50 border border-slate-200 rounded-xl">
                {['all', 'success', 'warn', 'error'].map((filt) => (
                  <button
                    key={filt}
                    onClick={() => setTelemetryFilter(filt)}
                    className={`px-3 py-1 rounded-lg text-[9px] font-bold cursor-pointer transition-all ${
                      telemetryFilter === filt 
                        ? 'bg-slate-900 text-white' 
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {filt.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
              
              {/* Graphical representation line charts */}
              <div className="md:col-span-2 relative h-48 bg-slate-50 rounded-2xl border border-slate-200 p-4">
                <svg viewBox="0 0 500 150" className="w-full h-full text-indigo-500" preserveAspectRatio="none">
                  <defs>
                    <linearGradient id="chart-glow" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#4f46e5" stopOpacity="0.15" />
                      <stop offset="100%" stopColor="#4f46e5" stopOpacity="0" />
                    </linearGradient>
                  </defs>

                  <line x1="0" y1="30" x2="500" y2="30" stroke="#e2e8f0" strokeDasharray="3,3" strokeWidth="0.8" />
                  <line x1="0" y1="75" x2="500" y2="75" stroke="#e2e8f0" strokeDasharray="3,3" strokeWidth="0.8" />
                  <line x1="0" y1="120" x2="500" y2="120" stroke="#e2e8f0" strokeDasharray="3,3" strokeWidth="0.8" />

                  <path 
                    d="M 0,110 Q 55,50 110,65 T 220,15 T 330,85 T 440,30 T 500,60 L 500,150 L 0,150 Z" 
                    fill="url(#chart-glow)" 
                  />

                  <path 
                    d="M 0,110 Q 55,50 110,65 T 220,15 T 330,85 T 440,30 T 500,60" 
                    fill="none" 
                    stroke="#4f46e5" 
                    strokeWidth="2" 
                  />

                  <circle cx="220" cy="15" r="4.5" fill="#4f46e5" stroke="#fff" strokeWidth="1.5" />
                </svg>

                <div className="absolute top-3 left-4 flex gap-4 text-[9px] font-mono font-bold text-slate-400">
                  <span className="flex items-center gap-1.5 font-sans">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse" />
                    Live active word routing speeds
                  </span>
                </div>
              </div>

              {/* Logs Stream scroll lists */}
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {filteredLogs.map((log) => (
                  <div 
                    key={log.id} 
                    className="p-3 bg-slate-50 border border-slate-150 rounded-xl flex items-center justify-between text-[11px] font-mono hover:border-indigo-150 transition-colors shadow-3xs"
                  >
                    <div>
                      <span className="font-bold text-slate-800 block truncate max-w-[140px]">{log.action}</span>
                      <span className="text-[9.5px] text-slate-400 font-bold block mt-0.5">{log.user}</span>
                    </div>
                    
                    <div className="text-right">
                      <span className={`text-[9px] font-bold block uppercase shrink-0 ${
                        log.status === 'success' ? 'text-emerald-600' :
                        log.status === 'warn' ? 'text-amber-600' : 'text-rose-600'
                      }`}>
                        {log.status === 'success' ? (log.tokens > 0 ? `+${log.tokens} w` : 'Ok') : log.status}
                      </span>
                      <span className="text-[9px] text-slate-450 block font-bold font-mono mt-0.5">{log.time}</span>
                    </div>
                  </div>
                ))}
              </div>

            </div>

          </div>

        </div>
      )}

    </div>
  );
}
