/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Settings, 
  Sliders, 
  ShieldCheck, 
  Bell, 
  Smartphone, 
  KeyRound, 
  RefreshCw, 
  QrCode, 
  CheckCircle2, 
  Layers, 
  Cpu,
  Info,
  SmartphoneNfc
} from 'lucide-react';

export default function SettingsPanel() {
  const [activeTab, setActiveTab] = useState<'profile' | 'behavior' | 'privacy' | 'devices' | 'apiKeys'>('profile');
  
  // Custom states
  const [temperature, setTemperature] = useState<number>(0.75);
  const [maxTokens, setMaxTokens] = useState<number>(4096);
  const [privacyZkMode, setPrivacyZkMode] = useState<boolean>(true);
  const [customKeyDisplay, setCustomKeyDisplay] = useState<string>('sk-frogemind-••••••••••••••••3fa2');
  const [isCopiedKey, setIsCopiedKey] = useState<boolean>(false);
  const [pairingPin, setPairingPin] = useState<string>('842-915');

  // Trigger PIN regenerations
  const rotatePIN = () => {
    const partA = Math.floor(Math.random() * 900) + 100;
    const partB = Math.floor(Math.random() * 900) + 100;
    setPairingPin(`${partA}-${partB}`);
  };

  const syncDevices = [
    { name: "Elytra's Satellite Phone Sync", type: "Mobile", status: "Active Connected", lastSeen: "Just now" },
    { name: "Core Node 4 Studio Display", type: "Desktop Workstation", status: "Active Connected", lastSeen: "1h ago" },
    { name: "FrogeMind Watch Helix Spec", type: "Wearable Node", status: "Standby Pipeline", lastSeen: "3d ago" }
  ];

  const handleCopy = () => {
    navigator.clipboard.writeText('sk-frogemind-quantum-verification-hash-3fa2-9343');
    setIsCopiedKey(true);
    setTimeout(() => setIsCopiedKey(false), 2000);
  };

  return (
    <div className="flex-1 overflow-y-auto bg-white p-6 sm:p-8 text-slate-800 font-sans select-none">
      
      {/* Top Title element */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-6 mb-8 mt-2">
        <div>
          <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-indigo-600">My Workspace Preferences</span>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Workspace Settings
          </h1>
          <p className="text-slate-500 text-xs mt-1.5 leading-relaxed">
            Manage your personal profile, adjust chatbot creativity levels, toggle data privacy settings, or connect smart devices.
          </p>
        </div>
      </div>

      {/* Settings layout grid split: Left sidebar tabs list. Right is Tab Content glass box */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        
        {/* Left Sidebar Tab selectors list */}
        <div className="flex flex-col gap-1 bg-slate-50 p-2.5 rounded-2xl border border-slate-200/60 self-start">
          
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold font-sans text-left transition-colors cursor-pointer ${
              activeTab === 'profile' 
                ? 'bg-white text-indigo-600 border border-slate-200/60 shadow-xs' 
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100/50 border border-transparent'
            }`}
          >
            <User className="w-4 h-4 shrink-0 text-slate-500 active:text-indigo-600" />
            <span>My Profile</span>
          </button>

          <button
            onClick={() => setActiveTab('behavior')}
            className={`flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold font-sans text-left transition-colors cursor-pointer ${
              activeTab === 'behavior' 
                ? 'bg-white text-indigo-600 border border-slate-200/60 shadow-xs' 
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100/50 border border-transparent'
            }`}
          >
            <Sliders className="w-4 h-4 shrink-0 text-slate-500 active:text-indigo-600" />
            <span>AI Bot Creativity</span>
          </button>

          <button
            onClick={() => setActiveTab('privacy')}
            className={`flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold font-sans text-left transition-colors cursor-pointer ${
              activeTab === 'privacy' 
                ? 'bg-white text-indigo-600 border border-slate-200/60 shadow-xs' 
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100/50 border border-transparent'
            }`}
          >
            <ShieldCheck className="w-4 h-4 shrink-0 text-slate-500 active:text-indigo-600" />
            <span>Privacy & History</span>
          </button>

          <button
            onClick={() => setActiveTab('devices')}
            className={`flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold font-sans text-left transition-colors cursor-pointer ${
              activeTab === 'devices' 
                ? 'bg-white text-indigo-600 border border-slate-200/60 shadow-xs' 
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100/50 border border-transparent'
            }`}
          >
            <Smartphone className="w-4 h-4 shrink-0 text-slate-500 active:text-indigo-600" />
            <span>Sync Devices</span>
          </button>

          <button
            onClick={() => setActiveTab('apiKeys')}
            className={`flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold font-sans text-left transition-colors cursor-pointer ${
              activeTab === 'apiKeys' 
                ? 'bg-white text-indigo-600 border border-slate-200/60 shadow-xs' 
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100/50 border border-transparent'
            }`}
          >
            <KeyRound className="w-4 h-4 shrink-0 text-slate-500 active:text-indigo-600" />
            <span>Developer Keys</span>
          </button>

        </div>

        {/* Right Active Tab content container */}
        <div className="md:col-span-3 bg-white border border-slate-100 shadow-sm rounded-3xl p-5 sm:p-6 min-h-[340px] flex flex-col justify-between relative">
          
          <AnimatePresence mode="wait">
            
            {/* PROFILE SETTINGS TAB */}
            {activeTab === 'profile' && (
              <motion.div
                key="profile"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-5"
              >
                <div>
                  <h3 className="text-sm font-bold text-slate-900 mb-1">User Profile</h3>
                  <p className="text-xs text-slate-500">Update your public name and view account settings details.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-mono text-slate-500 uppercase block mb-1.5 font-bold">Display Name</label>
                    <input 
                      type="text" 
                      defaultValue="Captain Elytra Thorne"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none text-slate-800 focus:border-indigo-400 focus:bg-white transition-all font-sans" 
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-slate-500 uppercase block mb-1.5 font-bold">Account Clearance</label>
                    <input 
                      type="text" 
                      disabled
                      defaultValue="Level 10 Workspace Administrator"
                      className="w-full px-3.5 py-2.5 bg-slate-100/60 border border-slate-200 rounded-xl text-xs outline-none text-slate-500 font-mono" 
                    />
                  </div>
                </div>

                <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex items-center gap-3.5 mt-2">
                  <div className="w-12 h-12 rounded-full overflow-hidden shrink-0 border border-slate-200">
                    <img referrerPolicy="no-referrer" src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80" alt="profile portrait" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <span className="text-xs font-bold block text-slate-900">Elytra Thorne</span>
                    <span className="text-[10px] font-mono font-bold text-indigo-600 block mt-0.5">Profile stored locally on this device</span>
                  </div>
                </div>
              </motion.div>
            )}

            {/* AI BEHAVIOR TAB */}
            {activeTab === 'behavior' && (
              <motion.div
                key="behavior"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                <div>
                  <h3 className="text-sm font-bold text-slate-900 mb-1">AI Chatbot Creativity Settings</h3>
                  <p className="text-xs text-slate-500">Fine-tune how creative or strict and factual the AI replies should be.</p>
                </div>

                {/* Slider 1 temperature */}
                <div>
                  <div className="flex justify-between items-center text-xs text-slate-600 font-mono font-bold mb-2">
                    <span>Creativity Level (Temperature):</span>
                    <span className="text-indigo-600 font-bold">{temperature}</span>
                  </div>
                  <input 
                    type="range" 
                    min={0.0} 
                    max={1.5} 
                    step={0.05}
                    value={temperature}
                    onChange={(e) => setTemperature(Number(e.target.value))}
                    className="w-full bg-slate-105 bg-slate-100 h-1.5 rounded-full accent-indigo-600 outline-none" 
                  />
                  <div className="flex justify-between text-[9px] font-mono text-slate-400 mt-1.5 font-bold uppercase">
                    <span>Precise & Factual (0.00)</span>
                    <span>Creative & Imaginative (1.50)</span>
                  </div>
                </div>

                {/* Slider 2 capacity */}
                <div>
                  <div className="flex justify-between items-center text-xs text-slate-600 font-mono font-bold mb-2">
                    <span>Max Reply Length limit:</span>
                    <span className="text-indigo-600 font-bold">{maxTokens} words</span>
                  </div>
                  <input 
                    type="range" 
                    min={1024} 
                    max={16384} 
                    step={1024}
                    value={maxTokens}
                    onChange={(e) => setMaxTokens(Number(e.target.value))}
                    className="w-full bg-slate-100 h-1.5 rounded-full accent-indigo-600 outline-none" 
                  />
                </div>
              </motion.div>
            )}

            {/* PRIVACY TAB */}
            {activeTab === 'privacy' && (
              <motion.div
                key="privacy"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-5"
              >
                <div>
                  <h3 className="text-sm font-bold text-slate-900 mb-1">Privacy & Security</h3>
                  <p className="text-xs text-slate-500">Shield your saved memories and chatbot transcript logs.</p>
                </div>

                {/* Option checkboxes layout */}
                <div className="space-y-3">
                  
                  {/* Item 1 */}
                  <label className="flex items-start gap-4 p-4 bg-slate-50 border border-slate-100/85 border-slate-100 rounded-2xl cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={privacyZkMode}
                      onChange={() => setPrivacyZkMode(!privacyZkMode)}
                      className="mt-0.5 accent-indigo-600 outline-none rounded shrink-0 h-4 w-4 cursor-pointer" 
                    />
                    <div>
                      <span className="text-xs font-bold block text-slate-800 leading-none">Enable local memory encryption lock</span>
                      <span className="text-[10.5px] text-slate-500 mt-1 leading-relaxed block font-sans">All information stored inside your local brainwave vault is protected with device keys.</span>
                    </div>
                  </label>

                  {/* Item 2 */}
                  <label className="flex items-start gap-4 p-4 bg-slate-50 border border-slate-105 border-slate-100 rounded-2xl cursor-pointer">
                    <input 
                      type="checkbox" 
                      defaultChecked 
                      className="mt-0.5 accent-indigo-600 outline-none rounded shrink-0 h-4 w-4 cursor-pointer" 
                    />
                    <div>
                      <span className="text-xs font-bold block text-slate-800 leading-none">Keep chat logs on this device only</span>
                      <span className="text-[10.5px] text-slate-500 mt-1 leading-relaxed block font-sans">Do not save my conversational history on any remote cloud backup servers.</span>
                    </div>
                  </label>

                </div>
              </motion.div>
            )}

            {/* DEVICES SYNC TAB */}
            {activeTab === 'devices' && (
              <motion.div
                key="devices"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-5"
              >
                <div>
                  <h3 className="text-sm font-bold text-slate-900 mb-1">Pair & Sync Other Devices</h3>
                  <p className="text-xs text-slate-500">Sync with your smart phone or companion watch to browse your chat logs instantly.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-center">
                  
                  {/* Device Sync QR code visual node */}
                  <div className="flex flex-col items-center bg-slate-50 p-4 border border-slate-150 rounded-2xl relative">
                    <div className="absolute top-2.5 right-2.5 text-[8px] font-mono font-bold text-indigo-600 bg-indigo-50 px-2.5 py-0.5 rounded-full">
                      QR Linker
                    </div>
                    {/* Visual Custom QR code blocks */}
                    <div className="w-24 h-24 bg-white p-2 rounded-xl border border-slate-200 flex items-center justify-center mb-3 mt-1 shadow-xs">
                      <QrCode className="w-20 h-20 text-slate-800" />
                    </div>
                    
                    <span className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-wider block">Scan to Link a New Device</span>
                  </div>

                  {/* Device Pairing numerical PIN indicators */}
                  <div className="bg-slate-50 border border-slate-150 p-4 rounded-2xl flex flex-col justify-between h-full min-h-[148px]">
                    <div>
                      <span className="text-[9px] font-mono font-bold uppercase text-slate-400 block mb-1">Device Authorization PIN</span>
                      <span className="text-2xl font-bold font-mono tracking-widest text-indigo-600 block my-1">
                        {pairingPin}
                      </span>
                      <p className="text-[10px] text-slate-500 leading-relaxed font-sans mb-3">
                        Enter this 6-digit pin code inside your phone companion app to login instantly.
                      </p>
                    </div>

                    <button
                      onClick={rotatePIN}
                      className="w-full py-2 bg-white hover:bg-slate-100 text-slate-700 font-bold font-mono text-[10px] uppercase tracking-wide border border-slate-200 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-3xs"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Generate New PIN Code</span>
                    </button>
                  </div>

                </div>

                {/* Synced wearables list layout */}
                <div className="space-y-2 pt-2.5 border-t border-slate-100">
                  <span className="text-[9px] font-mono uppercase text-indigo-600 tracking-wider block mb-2 font-bold">Active Connected Devices</span>
                  {syncDevices.map((dev, i) => (
                    <div key={i} className="p-2.5 bg-slate-50/70 border border-slate-150 text-xs flex items-center justify-between rounded-xl">
                      <div className="flex items-center gap-2.5">
                        <SmartphoneNfc className="w-4 h-4 text-indigo-600 shrink-0" />
                        <div>
                          <span className="font-bold text-slate-800 block leading-none">
                            {dev.name === "Elytra\'s Satellite Phone Sync" ? "Primary Mobile Phone" : 
                             dev.name === "Core Node 4 Studio Display" ? "Office Desktop Monitor" : 
                             "Smart Watch Sync Companion"}
                          </span>
                          <span className="text-[9.5px] text-slate-400 font-mono font-bold block mt-1">{dev.type}</span>
                        </div>
                      </div>
                      <span className="text-[10.5px] font-mono text-emerald-600 font-bold bg-emerald-50 border border-emerald-100/50 rounded-lg px-2.5 py-0.5">
                        {dev.status === "Standby Pipeline" ? "Standby" : "Connected"}
                      </span>
                    </div>
                  ))}
                </div>

              </motion.div>
            )}

            {/* DEVELOPER API KEYS TAB */}
            {activeTab === 'apiKeys' && (
              <motion.div
                key="apiKeys"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-5"
              >
                <div>
                  <h3 className="text-sm font-bold text-slate-900 mb-1">Model Connectors & API Configuration</h3>
                  <p className="text-xs text-slate-500">Unlock authentic real-time outputs from multiple free-tier LLM models including DeepSeek-R1, Gemini 2.5 Flash, Llama 3 (Groq), Qwen 2.5, Llama 3.3, Gemma 2, and NVIDIA NIM.</p>
                </div>

                {/* Advanced Connectors Information Boxes */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  {/* OpenRouter Integration Information Box */}
                  <div className="p-4 bg-indigo-50/50 border border-indigo-150/40 rounded-2xl">
                    <div className="flex items-start gap-3">
                      <span className="flex-shrink-0 w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-mono text-xs font-bold shadow-sm">
                        OR
                      </span>
                      <div>
                        <h4 className="text-xs font-bold text-slate-900 mb-0.5">Free-Tier OpenRouter Models</h4>
                        <p className="text-[11px] text-slate-600 leading-relaxed font-sans mb-3 text-justify">
                          By deploying with an <strong>OPENROUTER_API_KEY</strong>, run active split-screen benchmarks querying real online models side-by-side with zero costs.
                        </p>
                        
                        <div className="flex flex-wrap gap-2 text-[9.5px] font-mono">
                          <span className="bg-white border border-indigo-100/30 text-indigo-700 px-2 py-0.5 rounded font-semibold text-[9.5px]">
                            deepseek/deepseek-r1:free
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Groq Integration Information Box */}
                  <div className="p-4 bg-amber-50/50 border border-amber-150/40 rounded-2xl">
                    <div className="flex items-start gap-3">
                      <span className="flex-shrink-0 w-8 h-8 rounded-xl bg-amber-600 text-white flex items-center justify-center font-mono text-xs font-bold shadow-sm">
                        GR
                      </span>
                      <div>
                        <h4 className="text-xs font-bold text-slate-900 mb-0.5">Direct Groq LPU Engine</h4>
                        <p className="text-[11px] text-slate-600 leading-relaxed font-sans mb-3 text-justify">
                          By deploying with a <strong>GROQ_API_KEY</strong>, query Meta and Mistral models directly at blistering instant physical speed on LPU processors.
                        </p>
                        
                        <div className="flex flex-wrap gap-2 text-[9.5px] font-mono">
                          <span className="bg-white border border-amber-100/30 text-amber-800 px-2 py-0.5 rounded font-semibold text-[9.5px]">
                            llama-3.3-70b-versatile
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* NVIDIA NIM Integration Information Box */}
                  <div className="p-4 bg-green-50/50 border border-green-150/40 rounded-2xl">
                    <div className="flex items-start gap-3">
                      <span className="flex-shrink-0 w-8 h-8 rounded-xl bg-green-600 text-white flex items-center justify-center font-mono text-xs font-bold shadow-sm">
                        NV
                      </span>
                      <div>
                        <h4 className="text-xs font-bold text-slate-900 mb-0.5">NVIDIA NIM GPU Accelerator</h4>
                        <p className="text-[11px] text-slate-600 leading-relaxed font-sans mb-3 text-justify">
                          By deploying with an <strong>NVIDIA_API_KEY</strong>, query advanced Alignment/NIM models directly on ultra-fast GPU hardware nodes.
                        </p>
                        
                        <div className="flex flex-wrap gap-2 text-[9.5px] font-mono">
                          <span className="bg-white border border-green-100/30 text-green-800 px-2 py-0.5 rounded font-semibold text-[9.5px]">
                            llama-3.1-nemotron-70b
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex items-center justify-between font-mono text-xs text-indigo-600">
                  <div>
                    <span className="block text-[8px] font-bold uppercase tracking-wider text-slate-400 mb-1 font-mono">Project Encryption Key Hash</span>
                    <span className="truncate pr-4 font-bold">{customKeyDisplay}</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="shrink-0 p-2 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-800 transition-colors cursor-pointer border border-transparent hover:border-slate-200"
                  >
                    {isCopiedKey ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <QrCode className="w-4 h-4" />}
                  </button>
                </div>

                <div className="p-4 bg-amber-50/50 border border-amber-100 rounded-2xl text-[11.5px] text-amber-800 flex gap-2">
                  <div className="font-bold shrink-0">💡</div>
                  <div className="leading-relaxed">
                    <strong>To configure your Custom API Credentials:</strong> Add <code>OPENROUTER_API_KEY="your_key"</code>, <code>GROQ_API_KEY="your_key"</code>, or <code>NVIDIA_API_KEY="your_key"</code> in your environment variables or secrets settings panel. The server backend will automatically activate actual queries with live streaming breakout or hardware-accelerated fallback.
                  </div>
                </div>

                <div className="flex gap-2.5 mt-4">
                  <button
                    type="button"
                    onClick={() => {
                      const seed = Math.random().toString(36).substring(2, 10);
                      setCustomKeyDisplay(`sk-brainwave-${seed}••••••••3fa2`);
                      alert('Proxy key re-shuffled successfully!');
                    }}
                    className="px-4 py-2 bg-slate-105 bg-slate-100 hover:bg-slate-205 border border-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all cursor-pointer shadow-3xs"
                  >
                    Shuffle Key Seeds
                  </button>
                </div>
              </motion.div>
            )}

          </AnimatePresence>

          {/* Persistent Save message footer inside panel config */}
          <div className="border-t border-slate-100 pt-4 mt-6 flex justify-end gap-2 text-xs">
            <span className="text-[10px] font-mono font-bold text-slate-400 self-center">
              All configurations stored local-persistently.
            </span>
          </div>

        </div>

      </div>

    </div>
  );
}
