/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Cpu, 
  Layers, 
  CheckCircle2, 
  PlusCircle, 
  HelpCircle, 
  Globe, 
  Zap, 
  ShieldCheck, 
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { LLMModel } from '../../types';

interface ModelCatalogProps {
  modelsList: LLMModel[];
  activeModel: LLMModel;
  onSelectModel: (model: LLMModel) => void;
  onToggleModelStatus: (id: string) => void;
}

export default function ModelCatalog({ 
  modelsList, 
  activeModel, 
  onSelectModel,
  onToggleModelStatus
}: ModelCatalogProps) {
  
  const [filterBadge, setFilterBadge] = useState<string>('all');
  const [speedThreshold, setSpeedThreshold] = useState<number>(1);
  const [qualityThreshold, setQualityThreshold] = useState<number>(1);

  const filteredModels = modelsList.filter(model => {
    if (filterBadge !== 'all' && model.badge !== filterBadge) return false;
    if (model.speed < speedThreshold) return false;
    if (model.quality < qualityThreshold) return false;
    return true;
  });

  return (
    <div className="flex-1 overflow-y-auto bg-white p-6 sm:p-8 text-slate-800 font-sans select-none">
      
      {/* Header section with active stats */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-150 pb-6 mb-8 mt-2">
        <div>
          <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-indigo-600">AI Model Library</span>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Explore and Select AI Models
          </h1>
          <p className="text-slate-500 text-xs mt-1.5 leading-relaxed">
            Switch between AI models, turn specific ones on or off, and filter based on their speed, writing quality, or payment plans.
          </p>
        </div>

        {/* Reset configs */}
        <button
          onClick={() => {
            setFilterBadge('all');
            setSpeedThreshold(1);
            setQualityThreshold(1);
          }}
          className="self-start md:self-center flex items-center gap-1.5 text-[11px] font-mono text-slate-500 hover:text-slate-850 bg-slate-50 hover:bg-slate-100 px-3.5 py-2.5 rounded-xl border border-slate-200 cursor-pointer shadow-xs font-bold"
        >
          <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
          <span>Reset Filters</span>
        </button>
      </div>

      {/* Benchmark controller panels */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        
        {/* Sliders container A */}
        <div className="bg-slate-50/50 border border-slate-200/60 rounded-2xl p-4 flex flex-col justify-between shadow-xs">
          <div>
            <span className="text-[9px] font-mono tracking-wider uppercase text-slate-400 font-bold block mb-3 border-b border-slate-150 pb-1.5">
              Filter by Speed
            </span>
            <span className="text-xs text-slate-600 block leading-none mb-2 font-medium">
              Minimum Speed Level: <span className="text-indigo-600 font-bold font-mono">{speedThreshold}/5</span>
            </span>
            <input 
              type="range" 
              min={1} 
              max={5} 
              value={speedThreshold}
              onChange={(e) => setSpeedThreshold(Number(e.target.value))}
              className="w-full accent-indigo-600 bg-slate-200 h-1 rounded-full outline-none cursor-pointer" 
            />
          </div>
          <span className="text-[9px] font-mono text-slate-450 tracking-normal leading-relaxed block mt-4 font-semibold">
            Better for quick, interactive chatbot responses.
          </span>
        </div>

        {/* Sliders container B */}
        <div className="bg-slate-50/50 border border-slate-200/60 rounded-2xl p-4 flex flex-col justify-between shadow-xs">
          <div>
            <span className="text-[9px] font-mono tracking-wider uppercase text-slate-400 font-bold block mb-3 border-b border-slate-150 pb-1.5">
              Filter by Quality
            </span>
            <span className="text-xs text-slate-600 block leading-none mb-2 font-medium">
              Minimum Quality Level: <span className="text-sky-600 font-bold font-mono">{qualityThreshold}/5</span>
            </span>
            <input 
              type="range" 
              min={1} 
              max={5} 
              value={qualityThreshold}
              onChange={(e) => setQualityThreshold(Number(e.target.value))}
              className="w-full accent-sky-600 bg-slate-200 h-1 rounded-full outline-none cursor-pointer" 
            />
          </div>
          <span className="text-[9px] font-mono text-slate-450 tracking-normal leading-relaxed block mt-4 font-semibold">
            Better for smart reasoning, coding, and writing.
          </span>
        </div>

        {/* Dynamic selector metrics filters */}
        <div className="bg-slate-50/50 border border-slate-200/60 rounded-2xl p-4 flex flex-col justify-between shadow-xs">
          <div>
            <span className="text-[9px] font-mono tracking-wider uppercase text-slate-400 font-bold block mb-3 border-b border-slate-150 pb-1.5">
              Filter by Plans
            </span>
            <div className="grid grid-cols-4 gap-1.5 mt-2">
              {['all', 'Free', 'Pro', 'Enterprise'].map((b) => (
                <button
                  key={b}
                  onClick={() => setFilterBadge(b)}
                  className={`py-1.5 rounded-lg text-[9px] font-mono border text-center font-bold transition-all cursor-pointer ${
                    filterBadge === b 
                      ? 'bg-indigo-650 bg-[#4f46e5] text-white border-transparent shadow-xs' 
                      : 'bg-white text-slate-500 border-slate-200 hover:text-slate-800'
                  }`}
                >
                  {b.toUpperCase()}
                </button>
               ))}
            </div>
          </div>
          <span className="text-[9px] font-mono text-slate-450 tracking-normal leading-relaxed block mt-4 font-semibold">
            See which models are free or require pro accounts.
          </span>
        </div>

      </div>

      {/* Main Grid display */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {filteredModels.map((model) => {
          const isActive = activeModel.id === model.id;
          const isOffline = model.status === 'Offline';

          return (
            <div 
              key={model.id}
              className={`p-5 rounded-2xl border transition-all duration-200 relative flex flex-col justify-between ${
                isActive 
                  ? 'border-indigo-200 bg-indigo-50/10 shadow-md shadow-indigo-600/5' 
                  : 'border-slate-100 bg-white hover:border-slate-200 shadow-xs'
              }`}
            >
              
              {/* Top info and status */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  
                  {/* Provider label */}
                  <span className="text-[9px] uppercase font-mono tracking-wider text-slate-400 font-bold">
                    {model.provider}
                  </span>

                  {/* Badges indicators */}
                  <div className="flex items-center gap-1.5">
                    <span className={`text-[8.5px] font-mono tracking-wider px-2 py-0.5 rounded-full font-bold uppercase ${
                      model.badge === 'Free' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' :
                      model.badge === 'Pro' ? 'bg-indigo-50 text-indigo-600 border border-indigo-100' :
                      'bg-purple-50 text-purple-650 border border-purple-100'
                    }`}>
                      {model.badge}
                    </span>

                    {/* Local vs Cloud flag */}
                    <span className={`text-[8.5px] font-mono px-2 py-0.5 rounded-full font-bold uppercase ${
                      model.status === 'Local' ? 'bg-sky-50 text-sky-600 border border-sky-100' :
                      model.status === 'Cloud' ? 'bg-blue-50 text-blue-600 border border-blue-105' :
                      'bg-slate-100 text-slate-400 border border-slate-200'
                    }`}>
                      {model.status}
                    </span>
                  </div>

                </div>

                {/* Primary name and state select click zone */}
                <h3 className="text-sm font-bold text-slate-800 mb-2 flex items-center justify-between">
                  <span>{model.name}</span>
                  {isActive && (
                    <span className="text-[9px] font-mono text-indigo-600 bg-indigo-50/50 border border-indigo-100 px-2.5 py-0.5 rounded-full font-bold">
                      Active
                    </span>
                  )}
                </h3>

                <p className="text-[11px] text-slate-500 leading-relaxed mb-4 min-h-[36px]">
                  {model.description}
                </p>

                {/* Latency and Metrics info */}
                <div className="space-y-2 border-t border-slate-100 pt-3 mb-6">
                  
                  {/* Latency and Speed bars */}
                  <div className="flex items-center justify-between text-[10.5px] font-mono">
                    <span className="text-slate-450 font-semibold">Response Speed:</span>
                    <span className="text-slate-600 font-semibold">{model.latency}</span>
                  </div>

                  {/* Speed Level */}
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-slate-450 font-bold uppercase">Speed Stars:</span>
                    <div className="flex gap-1.5">
                      {Array.from({ length: 5 }).map((_, idx) => (
                        <span 
                          key={idx} 
                          className={`w-2 h-2 rounded-full ${idx < model.speed ? 'bg-sky-400' : 'bg-slate-100'}`} 
                        />
                      ))}
                    </div>
                  </div>

                  {/* Quality rating */}
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-slate-450 font-bold uppercase">Quality Stars:</span>
                    <div className="flex gap-1.5">
                      {Array.from({ length: 5 }).map((_, idx) => (
                        <span 
                          key={idx} 
                          className={`w-2 h-2 rounded-full ${idx < model.quality ? 'bg-indigo-550 bg-indigo-400' : 'bg-slate-100'}`} 
                        />
                      ))}
                    </div>
                  </div>

                </div>
              </div>

              {/* Selection and admin controls */}
              <div className="flex items-center gap-3 mt-4">
                <button
                  onClick={() => {
                    if (!isOffline) onSelectModel(model);
                  }}
                  disabled={isOffline}
                  className={`flex-1 text-xs py-2 rounded-xl transition-all font-bold cursor-pointer border ${
                    isOffline ? 'bg-slate-100 border-transparent text-slate-400' :
                    isActive ? 'bg-slate-900 border-transparent text-white shadow-xs' :
                    'bg-white text-slate-600 hover:text-slate-800 border-slate-200'
                  }`}
                >
                  {isOffline ? 'Offline' : isActive ? 'Active' : 'Select Model'}
                </button>

                {/* Status Toggle Switched Switch block */}
                <button
                  type="button"
                  onClick={() => onToggleModelStatus(model.id)}
                  title="Toggle available/offline state"
                  className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                    isOffline 
                      ? 'bg-red-50 text-red-500 border-red-100' 
                      : 'bg-emerald-50 text-emerald-600 border-emerald-100'
                  }`}
                >
                  {isOffline ? <AlertTriangle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
                </button>
              </div>

            </div>
          );
        })}

        {filteredModels.length === 0 && (
          <div className="col-span-full py-16 text-center border-2 border-dashed border-slate-150 bg-slate-50/50 rounded-3xl">
            <Cpu className="w-12 h-12 text-slate-350 mx-auto mb-4" />
            <h3 className="text-sm font-bold text-slate-700 mb-1">No Models Match Filters</h3>
            <p className="text-xs text-slate-400 leading-relaxed pr-2 pl-2">
              Lower your minimum speed or quality stars to reload options.
            </p>
          </div>
        )}

      </div>

    </div>
  );
}
