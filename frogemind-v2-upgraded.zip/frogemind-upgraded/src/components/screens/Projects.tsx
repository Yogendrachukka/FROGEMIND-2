/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Folder, 
  Plus, 
  Trash2, 
  Code, 
  Cpu, 
  Layers, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Search, 
  ExternalLink,
  ChevronRight,
  Briefcase,
  GitBranch,
  Calendar,
  FileText,
  Sparkles,
  Terminal,
  Activity,
  Server,
  RefreshCw,
  Play,
  Wrench,
  Flame,
  Bot,
  Workflow,
  Atom,
  Send,
  HeartPulse,
  Settings2,
  FileCode,
  Sliders,
  DollarSign
} from 'lucide-react';

interface ProjectItem {
  id: string;
  name: string;
  description: string;
  status: 'planning' | 'active' | 'completed' | 'paused';
  progress: number;
  tags: string[];
  assignedModel: string;
  createdAt: string;
  tasks: { id: string; text: string; done: boolean }[];
}

export interface ModelMeta {
  name: string;
  category: string;
  speed: number;
  logic: number;
  context: string;
  cost: string;
  idealFor: string;
  safety: string;
}

export const DEFAULT_MODELS_META: Record<string, ModelMeta> = {
  'DeepSeek R1': {
    name: 'DeepSeek R1',
    category: 'Reasoning Model',
    speed: 45,
    logic: 98,
    context: '128k tokens',
    cost: 'Free-Tier Orchestration',
    idealFor: 'Complex math, synthesis, deep debug verification',
    safety: 'Dual-step verification isolated'
  },
  'Llama 3.3 70B': {
    name: 'Llama 3.3 70B',
    category: 'Meta AI Open-Weights',
    speed: 80,
    logic: 90,
    context: '128k tokens',
    cost: 'Free-Tier Orchestration',
    idealFor: 'General task planning, robust backend logic synthesis',
    safety: 'LlamaGuard-3 isolation standard'
  },
  'Llama 3.1 8B': {
    name: 'Llama 3.1 8B',
    category: 'Meta AI Open-Weights',
    speed: 120,
    logic: 72,
    context: '128k tokens',
    cost: 'Free-Tier Orchestration',
    idealFor: 'Sub-second syntax scanning, simple routing checks',
    safety: 'Ultra-light secure sandbox'
  },
  'Gemma 2 9B': {
    name: 'Gemma 2 9B',
    category: 'Google AI Lightweight',
    speed: 110,
    logic: 75,
    context: '8k tokens',
    cost: 'Free-Tier Orchestration',
    idealFor: 'Local Windows desktop trays & offline agent layers',
    safety: 'Filtered system instructions'
  },
  'Qwen 2.5 72B': {
    name: 'Qwen 2.5 72B',
    category: 'Alibaba Group Core',
    speed: 70,
    logic: 89,
    context: '32k tokens',
    cost: 'Free-Tier Live Frame',
    idealFor: 'Multilingual data translation and layout alignments',
    safety: 'Input token sanitizer enabled'
  },
  'Qwen 2.5 Coder 32B': {
    name: 'Qwen 2.5 Coder 32B',
    category: 'Alibaba Group Coding Specialist',
    speed: 85,
    logic: 92,
    context: '32k tokens',
    cost: 'Free-Tier Live Frame',
    idealFor: 'Compiling structured React files & Express server paths',
    safety: 'Syntactic integrity pre-compiled bounds'
  },
  'Gemini 2.5 Flash': {
    name: 'Gemini 2.5 Flash',
    category: 'Google AI Core',
    speed: 150,
    logic: 92,
    context: '1,000k (1M) tokens',
    cost: 'Free-Tier Orchestration',
    idealFor: 'Ultra-large workspace context, logs analyzer, auto-fixer',
    safety: 'Google Safety Standards aligned'
  },
  'Gemini 1.5 Flash': {
    name: 'Gemini 1.5 Flash',
    category: 'Google AI Legacy',
    speed: 130,
    logic: 85,
    context: '1,000k (1M) tokens',
    cost: 'Free-Tier Orchestration',
    idealFor: 'Handling lengthy tracebacks & log sequences',
    safety: 'Google Safety Standards aligned'
  },
  'Auto-Select (Smart Router)': {
    name: 'Auto-Select (Smart Router)',
    category: 'Adaptive Dual-Path Router',
    speed: 95,
    logic: 95,
    context: 'Dynamic routing rules',
    cost: 'Highly Efficient Free-Tier',
    idealFor: 'Adaptive compilation. Maps specialized agents automatically.',
    safety: 'Multi-agent sandbox isolated'
  }
};

export default function Projects() {
  const [projects, setProjects] = useState<ProjectItem[]>(() => {
    const saved = localStorage.getItem('frogemind_projects');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error loading projects', e);
      }
    }
    return [
      {
        id: 'proj-1',
        name: 'FrogeMind Desktop Integration',
        description: 'Compiling offline LLM wrappers for local Windows system tray integration, utilizing Electron and Gemma 2.',
        status: 'active',
        progress: 65,
        tags: ['Gemma 2', 'Electron', 'Offline-First'],
        assignedModel: 'Gemma 2 (Google AI)',
        createdAt: '2026-05-20',
        tasks: [
          { id: 't1', text: 'Define secure IPC communication ports', done: true },
          { id: 't2', text: 'Implement reCAPTCHA standalone window', done: true },
          { id: 't3', text: 'Draft background sync worker daemon', done: false }
        ]
      },
      {
        id: 'proj-2',
        name: 'Multi-Agent Code Reviewer',
        description: 'Auto-scrapes GitHub pull requests and runs dual-model academic cross-checks with Claude 3.5 and DeepSeek R1.',
        status: 'active',
        progress: 100,
        tags: ['Claude 3.5', 'Research', 'Git API', 'Consensus'],
        assignedModel: 'Claude 3.5 vs DeepSeek R1 (Smart Router)',
        createdAt: '2026-05-25',
        tasks: [
          { id: 't4', text: 'Design pull request fetch hooks', done: true },
          { id: 't5', text: 'Implement side-by-side consensus comparison', done: true }
        ]
      },
      {
        id: 'proj-3',
        name: 'Automatic SVG Asset Compiler',
        description: 'Interactive canvas compiling vector diagrams generated via prompt interface with fast CSS rendering.',
        status: 'completed',
        progress: 100,
        tags: ['SVG', 'Vector', 'Prompt Engineering'],
        assignedModel: 'Qwen 2.5 Coder 32B',
        createdAt: '2026-05-15',
        tasks: [
          { id: 't6', text: 'Map React canvas SVG renderer', done: true },
          { id: 't7', text: 'Test CSS animations and viewport resizing', done: true }
        ]
      }
    ];
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'planning' | 'active' | 'completed'>('all');
  
  // Create project form states
  const [isCreating, setIsCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newModel, setNewModel] = useState('Auto-Select (Smart Router)');
  const [newTags, setNewTags] = useState('');

  // Selected project for active multi-agent pipeline visualization
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);

  const [workspaceTab, setWorkspaceTab] = useState<'sandbox' | 'code' | 'models'>('sandbox');
  const [selectedFileIndex, setSelectedFileIndex] = useState<number>(0);

  // Custom Model registration and analytics states
  const [customModels, setCustomModels] = useState<{
    name: string;
    provider: string;
    apiEndpoint: string;
    contextLimit: string;
    idealFor: string;
    speed: number;
    logic: number;
  }[]>(() => {
    try {
      const saved = localStorage.getItem('frogemind_custom_models');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [customModelName, setCustomModelName] = useState('');
  const [customModelProvider, setCustomModelProvider] = useState('OpenAI Compatible API');
  const [customModelEndpoint, setCustomModelEndpoint] = useState('https://api.openai.com/v1');
  const [customModelContext, setCustomModelContext] = useState('128k (Tokens)');
  const [customModelIdealFor, setCustomModelIdealFor] = useState('Structured React & server-side generation loops');
  const [customModelSpeed, setCustomModelSpeed] = useState<number>(85);
  const [customModelLogic, setCustomModelLogic] = useState<number>(90);
  const [modelCompareId, setModelCompareId] = useState<string>('DeepSeek R1');

  // Simulation pipeline states for the active workspace
  const [pipelineLogs, setPipelineLogs] = useState<string[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(-1);
  const [pipelineStatus, setPipelineStatus] = useState<'idle' | 'running' | 'completed' | 'failed'>('idle');
  const [generatedFilesCount, setGeneratedFilesCount] = useState<number>(0);
  const [showAppPreview, setShowAppPreview] = useState<boolean>(true);
  
  // Self Healing States
  const [hasCrashBug, setHasCrashBug] = useState<boolean>(false);
  const [isSelfHealing, setIsSelfHealing] = useState<boolean>(false);
  const [healingLogs, setHealingLogs] = useState<string[]>([]);
  
  // Simulated Interactive App variables
  // Proj-1 states (Desktop Gemma Tray)
  const [gemmaPrompt, setGemmaPrompt] = useState<string>('Write a clean socket listener for offline models.');
  const [gemmaOutput, setGemmaOutput] = useState<string>('');
  const [gpuMemory, setGpuMemory] = useState<number>(6);
  const [isGemmaRunning, setIsGemmaRunning] = useState<boolean>(false);

  // Proj-2 states (Code reviewer)
  const [selectedPR, setSelectedPR] = useState<string>('PR #107');
  const [activePRRef, setActivePRRef] = useState<string>('feature/redis-pooling');
  const [isPRReviewing, setIsPRReviewing] = useState<boolean>(false);
  const [reviewerOutput, setReviewerOutput] = useState<boolean>(false);

  // Proj-3 states (SVG Compiler)
  const [svgTemplate, setSvgTemplate] = useState<'quantum' | 'agents' | 'grid'>('quantum');
  const [svgAccent, setSvgAccent] = useState<string>('#6366f1');
  const [svgSpeed, setSvgSpeed] = useState<number>(3);
  const [svgScale, setSvgScale] = useState<number>(100);

  // Custom sandbox message state
  const [sandboxPrompt, setSandboxPrompt] = useState<string>('');
  const [sandboxResponse, setSandboxResponse] = useState<string>('');

  useEffect(() => {
    localStorage.setItem('frogemind_projects', JSON.stringify(projects));
  }, [projects]);

  const getVisibleFilesCount = () => {
    if (generatedFilesCount <= 1) return 1;
    if (generatedFilesCount === 2) return 2;
    if (generatedFilesCount === 4) return 3;
    if (generatedFilesCount === 6) return 4;
    return 100; // Show all
  };

  const getVirtualFiles = (projectId: string) => {
    if (projectId === 'proj-1') {
      return [
        {
          name: 'requirements_prd.md',
          path: '/specs/requirements_prd.md',
          language: 'markdown',
          content: `# Requirements Document: FrogeMind Desktop Integration

## 1. Objectives
Compile local Windows system tray integration wrappers using Gemma-2-9B model parameters. Ensure full offline capabilities with low hardware memory budgets.

## 2. Technical Stack
- Main Process: Electron.js / NodeJS socket wrapper
- Local Neural Logic: Gemma 2.5 (9B parameters) locally hosted with FP16 quantification
- GUI: React with high-contrast Tailwind UI utilities

## 3. Sandboxed Safe Bounds
Disable Node-level remote API scraping. Secure all Inter-Process Communication (IPC) hooks against port vulnerability scans.`
        },
        {
          name: 'agent_plan.json',
          path: '/pipeline/agent_plan.json',
          language: 'json',
          content: `{
  "projectName": "FrogeMind Desktop Integration",
  "routingStrategy": "Google Cloud Gemma Direct",
  "compilationMilestones": [
    { "step": 1, "agent": "Requirement Analyzer", "status": "approved" },
    { "step": 2, "agent": "Project Planner", "status": "approved" },
    { "step": 3, "agent": "PRD Designer", "status": "approved" },
    { "step": 4, "agent": "Frontend Engineer", "status": "compiled" },
    { "step": 5, "agent": "Backend Core Engineer", "status": "compiled" }
  ],
  "securityDirectives": {
    "IPC_isolation": true,
    "VRAM_management": "dynamic_allocator"
  }
}`
        },
        {
          name: 'TrayLauncher.tsx',
          path: '/src/components/TrayLauncher.tsx',
          language: 'typescript',
          content: `import React, { useState } from 'react';
import { Cpu, Play } from 'lucide-react';

export default function TrayLauncher() {
  const [activeModel, setActiveModel] = useState<string>('Gemma 2');
  const [inferenceTime, setInferenceTime] = useState<number>(12);

  return (
    <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
      <div className="flex items-center gap-2 mb-2">
        <Cpu className="text-emerald-400 w-4 h-4" />
        <span className="font-mono text-[11px] text-slate-300">Tray daemon loop active</span>
      </div>
      <p className="text-xs text-slate-400">SystemTray wrapper listening on secure loopback localhost:11434.</p>
    </div>
  );
}`
        },
        {
          name: 'server.ts',
          path: '/server.ts',
          language: 'typescript',
          content: `import express from 'express';
import { ipcMain } from 'electron';

const app = express();
app.use(express.json());

// Main IPC daemon for stand-alone tray interactions
ipcMain.handle('query-gemma', async (event, query, vramConfig) => {
  console.log(\`[IPC_AGENT] Dispatching local prompt loop: \${query}\`);
  const activeBudget = vramConfig || 6;
  
  return {
    state: 'compiled',
    payload: \`[Mock Gemma Local Response - VRAM Budget: \${activeBudget}GB] Socket listener successfully parsed your query.\`
  };
});

app.listen(3000, '0.0.0.0', () => {
  console.log('Windows Desktop Gemma integration process listening on localhost:11434');
});`
        },
        {
          name: 'package.json',
          path: '/package.json',
          language: 'json',
          content: `{
  "name": "gemma-offline-tray-system",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "electron .",
    "build": "electron-builder --dir"
  },
  "dependencies": {
    "express": "^4.18.2",
    "electron": "^28.2.0",
    "lucide-react": "^0.320.0"
  }
}`
        }
      ];
    }

    if (projectId === 'proj-2') {
      return [
        {
          name: 'requirements_specs.md',
          path: '/specs/requirements_specs.md',
          language: 'markdown',
          content: `# Multi-Agent Code Review Consensus Analyzer

## Objective
Automatically retrieve pull request payloads from connected repositories and execute side-by-side consensus evaluation using Claude 3.5 Sonnet and DeepSeek R1 reasoning parameters.

## Core Metrics
- Consensus threshold score: 7.5/10.0
- Reasoning verification loops: Dual-pass validation check`
        },
        {
          name: 'consensus_router.ts',
          path: '/src/lib/consensus_router.ts',
          language: 'typescript',
          content: `export interface CodeAuditReport {
  analyzerName: 'Claude-3.5' | 'DeepSeek-R1';
  severityRating: 'low' | 'medium' | 'high';
  securityConfidence: number;
  syntaxVerification: boolean;
  comments: string;
}

export function analyzeConsensus(reports: CodeAuditReport[]): boolean {
  const ratings = reports.map(r => r.securityConfidence);
  const averageConfidence = ratings.reduce((sum, val) => sum + val, 0) / ratings.length;
  console.log(\`[CORE_ROUTER] Average confidence rating: \${averageConfidence}%\`);
  
  // Both models must agree to flag structural overrides
  return averageConfidence >= 85;
}`
        },
        {
          name: 'server.ts',
          path: '/src/server.ts',
          language: 'typescript',
          content: `import express from 'express';
import { analyzeConsensus } from './lib/consensus_router';

const app = express();
app.use(express.json());

app.post('/api/githook/consensus-review', async (req, res) => {
  const { prDiff, repoId } = req.body;
  console.log(\`[WEBHOOK_INGRESS] Received PR Diff payload for repository identifier: \${repoId}\`);

  const mockClaudeReport = {
    analyzerName: 'Claude-3.5',
    severityRating: 'low',
    securityConfidence: 92,
    syntaxVerification: true,
    comments: 'Structural code loops verified to be free-tier compatible.'
  };

  const mockDeepSeekReport = {
    analyzerName: 'DeepSeek-R1',
    severityRating: 'medium',
    securityConfidence: 81,
    syntaxVerification: true,
    comments: 'Reasoning trails suggest possible race condition in singleton constructor initialization.'
  };

  const passedReview = analyzeConsensus([mockClaudeReport, mockDeepSeekReport]);

  res.json({
    status: 'success',
    passedReview,
    metrics: {
      averageConfidence: 86.5,
      consensualApproval: true
    }
  });
});

app.listen(3000, '0.0.0.0', () => {
  console.log('Consensus Reviewer microservice listening on port 3000');
});`
        }
      ];
    }

    if (projectId === 'proj-3') {
      return [
        {
          name: 'prd_spec.md',
          path: '/specs/prd_spec.md',
          language: 'markdown',
          content: `# Graphic Compile Engine for Dynamic SVG Generation

## Objective
Develop a high-performance vector rendering system capable of updating animated inline XML graphical diagrams dynamically in response to parameter slider events.

## Components
- Accent Color Color-Picker
- Acceleration Speed Modifier Loop
- Precompiled XML Structure Store`
        },
        {
          name: 'svg_templates_store.json',
          path: '/src/data/svg_templates_store.json',
          language: 'json',
          content: `{
  "quantum": {
    "id": "quantum",
    "name": "Quantum Spin Orbitals",
    "components": 5,
    "nativeFPS": 60
  },
  "agents": {
    "id": "agents",
    "name": "Connected Collaborative Agent Nodes",
    "components": 7,
    "nativeFPS": 60
  },
  "grid": {
    "id": "grid",
    "name": "Orthogonal Metric Vector Grids",
    "components": 9,
    "nativeFPS": 60
  }
}`
        },
        {
          name: 'engine.ts',
          path: '/src/lib/engine.ts',
          language: 'typescript',
          content: `export function computeOrbitCoordinates(centerX: number, centerY: number, radius: number, speedMultiplier: number) {
  const angularVelocity = (speedMultiplier * Math.PI) / 180;
  console.log(\`[SVG_COMPILER_LOG] Compiling orbital positions with velocity: \${angularVelocity}\`);
  return {
    isOptimal: true,
    renderFrameRate: 60
  };
}`
        }
      ];
    }

    return [
      {
        name: 'custom_prd.md',
        path: '/specs/custom_prd.md',
        language: 'markdown',
        content: `# Specification: Live Autonomous Active Sandbox

## Requirements
Render a safe and secure local prompt sandbox using a distributed free-tier routing architecture. Provide instant interactive diagnostic checks to test syntax.

## Config
- Host Ingress: Local Node Container Port 3000`
      },
      {
        name: 'server.ts',
        path: '/src/server.ts',
        language: 'typescript',
        content: `import express from 'express';
const app = express();
app.use(express.json());

app.post('/api/sandbox/query', (req, res) => {
  const { userPrompt } = req.body;
  console.log(\`[SANDBOX] Received custom query input: "\${userPrompt}"\`);
  res.json({
    message: "Dynamic sandbox environment response compilation completed. All distributed nodes green."
  });
});

app.listen(3000, '0.0.0.0', () => {
  console.log('Mock Custom Application sandbox listening on port 3000');
});`
      }
    ];
  };

  const activeProject = projects.find(p => p.id === selectedProjectId);

  // Agent descriptions based on user intent docs
  const AGENTS_LIST = [
    { 
      id: 0, 
      name: 'Agent 1 — Requirement Analyzer', 
      model: 'Gemini 2.5 Flash', 
      provider: 'Google AI', 
      task: 'Reads user goals & maps strict PRD boundaries',
      badgeColor: 'bg-blue-50 border-blue-100 text-blue-700'
    },
    { 
      id: 1, 
      name: 'Agent 2 — Project Planner', 
      model: 'Gemini 2.5 Flash', 
      provider: 'Google AI', 
      task: 'Establishes technical stack, roadmap & structure',
      badgeColor: 'bg-blue-50 border-blue-100 text-blue-700'
    },
    { 
      id: 2, 
      name: 'Agent 3 — PRD Generator', 
      model: 'Gemini 1.5 Flash', 
      provider: 'Google AI', 
      task: 'Formats user stories and full technical layouts',
      badgeColor: 'bg-blue-50 border-blue-100 text-blue-700'
    },
    { 
      id: 3, 
      name: 'Agent 4 — UI Designer', 
      model: 'Qwen 2.5 Coder 32B', 
      provider: 'OpenRouter', 
      task: 'Generates responsive layouts & styling matrices',
      badgeColor: 'bg-purple-50 border-purple-100 text-purple-700'
    },
    { 
      id: 4, 
      name: 'Agent 5 — Frontend Engineer', 
      model: 'Llama 3.3 70B', 
      provider: 'GroqCloud', 
      task: 'Assembles React components & animated workflows',
      badgeColor: 'bg-amber-50 border-amber-100 text-amber-700'
    },
    { 
      id: 5, 
      name: 'Agent 6 — Backend Engineer', 
      model: 'Qwen 2.5 Coder 32B', 
      provider: 'OpenRouter', 
      task: 'Injects system endpoints and database routing',
      badgeColor: 'bg-purple-50 border-purple-100 text-purple-700'
    },
    { 
      id: 6, 
      name: 'Agent 7 — QA + Testing Agent', 
      model: 'Llama 3.1 Nemotron 70B', 
      provider: 'NVIDIA Build / NIM', 
      task: 'Validates API payloads, unit tests & coverage',
      badgeColor: 'bg-green-50 border-green-100 text-green-700'
    },
    { 
      id: 7, 
      name: 'Agent 8 — Auto-Fix Agent (Self-Healer)', 
      model: 'Gemini 2.5 Flash', 
      provider: 'Google AI', 
      task: 'Monitors runtime anomalies & repairs code bugs',
      badgeColor: 'bg-emerald-50 border-emerald-100 text-emerald-800'
    }
  ];

  // Starts the multi-agent orchestration simulation
  const startAssemblyLine = () => {
    if (pipelineStatus === 'running' || isSelfHealing) return;
    
    setPipelineStatus('running');
    setPipelineLogs([]);
    setCurrentStepIndex(0);
    setGeneratedFilesCount(0);
    setHasCrashBug(false);
    setHealingLogs([]);
    
    const routerLabel = activeProject?.assignedModel || 'Auto-Select (Smart Router)';
    
    // Stage 1: Requirement Analyzer
    addLog('[ORCHESTRATOR] Initiating distributed AI software assembly line...');
    addLog(`[ORCHESTRATOR] Selected Project Profile: "${activeProject?.name || 'General'}"`);
    addLog(`[ORCHESTRATOR] Master Routing Intelligence: "${routerLabel}"`);
    addLog(`[${routerLabel}] Agent 1 (Requirement Analyzer) booting context parameters...`);
    
    setTimeout(() => {
      setCurrentStepIndex(1);
      addLog(`[${routerLabel}] Agent 1 completed mapping scope. Extracted 5 feature requirements.`);
      addLog(`[${routerLabel}] Agent 2 (Project Planner) starting task-splitting algorithms...`);
      setGeneratedFilesCount(1); // PRD file
    }, 1500);

    // Stage 2: Project Planner
    setTimeout(() => {
      setCurrentStepIndex(2);
      addLog(`[${routerLabel}] Agent 2 laid out folder framework & identified development order.`);
      addLog(`[${routerLabel}] Step 3 (PRD Generator) formatting user stories & file maps...`);
      setGeneratedFilesCount(2); // plan.json
    }, 3000);

    // Stage 3: PRD Generator
    setTimeout(() => {
      setCurrentStepIndex(3);
      addLog(`[${routerLabel}] Agent 3 formatted technical specs successfully. Safe boundaries established.`);
      addLog(`[Qwen 2.5 Coder 32B] Step 4 (UI Designer) crafting Tailwind system and layout configurations...`);
      setGeneratedFilesCount(4); // prd.md, tailwind.config.js
    }, 4500);

    // Stage 4: UI Designer
    setTimeout(() => {
      setCurrentStepIndex(4);
      addLog(`[Qwen 2.5 Coder 32B] Agent 4 completed design token schemas. Responsive components initialized.`);
      addLog(`[Llama 3.3 70B] Step 5 (Frontend Engineer) generating static view templates...`);
      setGeneratedFilesCount(6); // index.html, App.tsx
    }, 6000);

    // Stage 5: Frontend Engineer
    setTimeout(() => {
      setCurrentStepIndex(5);
      addLog(`[Llama 3.3 70B] Agent 5 generated 3 rich interactive screens with clean Framer Motion values.`);
      addLog(`[Qwen 2.5 Coder 32B] Step 6 (Backend Engineer) synthesizing robust Express servers and database maps...`);
      setGeneratedFilesCount(8); // server.ts, db.ts
    }, 7500);

    // Stage 6: Backend Engineer
    setTimeout(() => {
      setCurrentStepIndex(6);
      addLog(`[Qwen 2.5 Coder 32B] Agent 6 built port 3000 listeners and request validators.`);
      addLog(`[Llama 3.1 Nemotron 70B] Step 7 (QA + Testing Agent) starting comprehensive integration suite...`);
      setGeneratedFilesCount(11); // tests.ts, schema.sql, package.json
    }, 9000);

    // Stage 7: QA + Testing (Completes successfully or stays on QA if crash is injected)
    setTimeout(() => {
      addLog(`[Llama 3.1 Nemotron 70B] Initiating simulated unit tests with validation tools...`);
      addLog(`[Llama 3.1 Nemotron 70B] Test Suite #1: Port Verification (OK)`);
      addLog(`[Llama 3.1 Nemotron 70B] Test Suite #2: Express Ingress CORS Bounds (OK)`);
      addLog(`[Llama 3.1 Nemotron 70B] Test Suite #3: Context Injection Flow (OK)`);
      
      setCurrentStepIndex(7);
      addLog(`[${routerLabel}] Agent 8 (Auto-Fix Agent) monitoring deployment stream. Systems standing secure.`);
      setPipelineStatus('completed');
      addLog(`[ORCHESTRATOR] ASSEMBLY LINE SECURED at 100% compilation under control of "${routerLabel}".`);
    }, 11000);
  };

  const addLog = (text: string) => {
    setPipelineLogs(prev => [...prev, `${new Date().toLocaleTimeString([], { hour12: false })} - ${text}`]);
  };

  // Demo dynamic self-healing of crashed code
  const handleSimulateCrash = () => {
    if (pipelineStatus !== 'completed' && currentStepIndex !== 7) return;
    
    setHasCrashBug(true);
    setPipelineStatus('failed');
    
    // Ingress error log triggered
    addLog('[NVIDIA NIM/QA Agent] [FATAL ERROR] Automated server checks failed!');
    addLog('[NVIDIA NIM/QA Agent] Encountered Exception: EADDRINUSE (Address already in use: localhost:3000)');
    addLog('[NVIDIA NIM/QA Agent] Crash detected during initialization loop. Rollback triggered.');
    addLog('[ORCHESTRATOR] Server failure flag identified!');
  };

  const executeSelfHealing = () => {
    if (!hasCrashBug || isSelfHealing) return;
    
    setIsSelfHealing(true);
    const hLogs: string[] = [];
    const pushH = (log: string) => {
      hLogs.push(`${new Date().toLocaleTimeString([], { hour12: false })} - ${log}`);
      setHealingLogs([...hLogs]);
    };

    pushH('[AUTO-FIX AGENT - Google Gemini] Diagnosing exception signatures...');
    
    setTimeout(() => {
      pushH('[AUTO-FIX] Step 1: Read server failure dumps. Found address clash on port 3000.');
    }, 1000);

    setTimeout(() => {
      pushH('[AUTO-FIX] Step 2: Analyzing active host processes. Express was initialized twice.');
    }, 2000);

    setTimeout(() => {
      pushH('[AUTO-FIX] Step 3: Rewriting server.ts code template securely. Port dynamically queries state fallback: (process.env.PORT || 3000).');
    }, 3500);

    setTimeout(() => {
      pushH('[AUTO-FIX] Step 4: Compiling patch. Saving changes. Re-running Llama NIM integration test.');
    }, 5000);

    setTimeout(() => {
      pushH('[AUTO-FIX] Step 5: Patch deployment succeeded. Simulated Port changed to 3001 fallback.');
      pushH('[ORCHESTRATOR] Master system reports full recovery! Code compiled green.');
      
      setIsSelfHealing(false);
      setHasCrashBug(false);
      setPipelineStatus('completed');
    }, 6500);
  };

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    const tagsArray = newTags
      .split(',')
      .map(tag => tag.trim())
      .filter(tag => tag.length > 0);

    const newProj: ProjectItem = {
      id: `proj-${Date.now()}`,
      name: newName,
      description: newDesc,
      status: 'planning',
      progress: 0,
      tags: tagsArray.length > 0 ? tagsArray : ['General'],
      assignedModel: newModel,
      createdAt: new Date().toISOString().split('T')[0],
      tasks: [
        { id: 't-init', text: 'Analyze initial prompt requirements with system agents', done: false },
        { id: 't-comp', text: 'Generate modular code files autonomously', done: false }
      ]
    };

    setProjects([newProj, ...projects]);
    
    // Reset Form
    setNewName('');
    setNewDesc('');
    setNewTags('');
    setIsCreating(false);
  };

  const handleRegisterCustomModel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customModelName.trim()) return;

    const newModelObj = {
      name: customModelName.trim(),
      provider: customModelProvider,
      apiEndpoint: customModelEndpoint.trim(),
      contextLimit: customModelContext,
      idealFor: customModelIdealFor.trim(),
      speed: customModelSpeed,
      logic: customModelLogic
    };

    const nextModels = [...customModels, newModelObj];
    setCustomModels(nextModels);
    localStorage.setItem('frogemind_custom_models', JSON.stringify(nextModels));

    // Reset input fields
    setCustomModelName('');
    
    // Switch the active analytical preview to the newly registered model
    setModelCompareId(newModelObj.name);
  };

  const handleRemoveCustomModel = (nameToClear: string) => {
    if (window.confirm(`Are you sure you want to remove the custom model "${nameToClear}"?`)) {
      const nextModels = customModels.filter(m => m.name !== nameToClear);
      setCustomModels(nextModels);
      localStorage.setItem('frogemind_custom_models', JSON.stringify(nextModels));
      if (modelCompareId === nameToClear) {
        setModelCompareId('DeepSeek R1');
      }
    }
  };

  const handleDeleteProject = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this project?')) {
      setProjects(projects.filter(p => p.id !== id));
      if (selectedProjectId === id) {
        setSelectedProjectId(null);
      }
    }
  };

  const handleToggleTask = (projId: string, taskId: string) => {
    setProjects(projects.map(proj => {
      if (proj.id === projId) {
        const updatedTasks = proj.tasks.map(t => t.id === taskId ? { ...t, done: !t.done } : t);
        const resolvedCount = updatedTasks.filter(t => t.done).length;
        const total = updatedTasks.length;
        const nextProgress = total > 0 ? Math.round((resolvedCount / total) * 100) : 0;
        const nextStatus = nextProgress === 100 ? 'completed' : proj.status === 'planning' ? 'active' : proj.status;
        return {
          ...proj,
          tasks: updatedTasks,
          progress: nextProgress,
          status: nextStatus as any
        };
      }
      return proj;
    }));
  };

  const handleAddTask = (projId: string, text: string) => {
    if (!text.trim()) return;
    setProjects(projects.map(proj => {
      if (proj.id === projId) {
        const newTask = { id: `task-${Date.now()}`, text, done: false };
        const updatedTasks = [...proj.tasks, newTask];
        const resolvedCount = updatedTasks.filter(t => t.done).length;
        const nextProgress = Math.round((resolvedCount / updatedTasks.length) * 100);
        return {
          ...proj,
          tasks: updatedTasks,
          progress: nextProgress,
          status: (nextProgress === 100 ? 'completed' : proj.status) as any
        };
      }
      return proj;
    }));
  };

  const filteredProjects = projects.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesFilter = activeFilter === 'all' || p.status === activeFilter;
    return matchesSearch && matchesFilter;
  });

  // Task text temp state
  const [taskInputs, setTaskInputs] = useState<Record<string, string>>({});

  return (
    <div className="flex-1 overflow-hidden flex flex-col bg-slate-50/50 h-full font-sans text-slate-800">
      
      {/* Header toolbar - only shown when no project is active */}
      {!selectedProjectId && (
        <div className="bg-white border-b border-slate-150/60 p-6 shrink-0 shadow-3xs">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-indigo-650 flex items-center gap-1.5 bg-indigo-50 px-2.5 py-1 rounded-md w-fit">
                <Workflow className="w-3.5 h-3.5 animate-pulse text-indigo-500" />
                <span>MULTIPLE AGENT ASSEMBLY HUB</span>
              </span>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight mt-2 pb-0.5">
                Multi-Agent AI Assembly Line
              </h1>
              <p className="text-slate-500 text-xs sm:text-sm mt-1 leading-relaxed max-w-2xl">
                Configure, test, and render software objects autonomously. We match tasks to optimum LLMs (Gemini, Groq, NVIDIA NIM, and OpenRouter) for structural parity and zero cost overhead.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
                <input 
                  type="text" 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search workspaces..." 
                  className="pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-indigo-400 rounded-xl text-xs text-slate-700 outline-none w-52 sm:w-60 focus:bg-white transition-all placeholder:text-slate-405 font-sans"
                />
              </div>

              {projects.length > 0 && (
                <button
                  onClick={() => {
                    if (window.confirm("Are you sure you want to permanently delete ALL workspaces/projects?")) {
                      setProjects([]);
                      localStorage.setItem('frogemind_projects', JSON.stringify([]));
                    }
                  }}
                  className="flex items-center gap-1.5 px-3 py-2.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 rounded-xl text-xs font-bold transition-all shadow-3xs cursor-pointer"
                  title="Remove All Projects"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Delete All</span>
                </button>
              )}

              <button
                onClick={() => setIsCreating(true)}
                className="flex items-center gap-1.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Assembly App</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Layout Area */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Left Side: Projects Directory */}
        <div className={`w-full ${selectedProjectId ? 'hidden' : 'flex flex-col flex-1 bg-slate-50/20'} overflow-y-auto p-6 sm:p-8`}>
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">My Active Workspaces</h2>
              <p className="text-[11px] text-slate-500 mt-0.5">Select a sandbox profile to trigger model routines & test builds.</p>
            </div>

            <div className="flex items-center gap-3">
              {/* Filter Chips inside directory */}
              <div className="flex items-center gap-1 p-1 bg-slate-100 border border-slate-200/60 rounded-xl">
                {(['all', 'planning', 'active', 'completed'] as const).map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setActiveFilter(filter)}
                    className={`px-3 py-1.5 rounded-lg text-[9.5px] font-mono font-bold transition-all cursor-pointer uppercase ${
                      activeFilter === filter
                        ? 'bg-white text-indigo-600 shadow-3xs border border-slate-200/25'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {filter}
                  </button>
                ))}
              </div>
              
              <span className="text-[10px] bg-indigo-50 border border-indigo-100 text-indigo-600 font-mono font-bold px-2.5 py-1.5 rounded-xl">
                {projects.length} Profiles loaded
              </span>
            </div>
          </div>

          <div className="space-y-3.5">
            {filteredProjects.length === 0 ? (
              <div className="text-center p-12 border border-dashed border-slate-200 rounded-3xl bg-white max-w-md mx-auto mt-8">
                <Folder className="w-8 h-8 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-500 font-medium text-xs">No workspaces match your filters.</p>
                <p className="text-slate-400 text-[11px] mt-1">Try resetting search tokens or click "New Assembly App" above.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredProjects.map((p) => {
                  const isSelected = p.id === selectedProjectId;
                  return (
                    <div 
                      key={p.id}
                      onClick={() => {
                        setSelectedProjectId(p.id);
                        setPipelineLogs([]);
                        setCurrentStepIndex(-1);
                        setPipelineStatus('idle');
                        setHasCrashBug(false);
                        setHealingLogs([]);
                        setWorkspaceTab('sandbox');
                        setSelectedFileIndex(0);
                      }}
                      className="p-5 bg-white border border-slate-200 rounded-2xl cursor-pointer hover:border-indigo-400 hover:shadow-xs transition-all duration-200 flex flex-col justify-between group shadow-3xs hover:scale-[1.015]"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-1.5 mb-2.5">
                          <h3 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors line-clamp-1 flex-1">
                            {p.name}
                          </h3>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <span className={`text-[8.5px] font-mono font-bold uppercase tracking-wider px-1.5 py-0.5 rounded-md border ${
                              p.status === 'completed' ? 'bg-emerald-50 border-emerald-100 text-emerald-700' :
                              p.status === 'active' ? 'bg-indigo-50 border-indigo-150 text-indigo-700' :
                              'bg-amber-50 border-amber-100 text-amber-700'
                            }`}>
                              {p.status}
                            </span>
                            <button
                              onClick={(e) => handleDeleteProject(p.id, e)}
                              className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                              title="Delete Workspace"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <p className="text-[11.5px] text-slate-500 line-clamp-3 leading-relaxed mb-4">
                          {p.description}
                        </p>

                        <div className="flex flex-wrap gap-1 mb-4">
                          {p.tags.slice(0, 3).map((t, i) => (
                            <span key={i} className="text-[9.5px] font-mono px-2 py-0.5 bg-slate-100 text-slate-600 rounded-md border border-slate-200/30">
                              #{t}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center justify-between border-t border-slate-100 pt-3 text-[10.5px] text-slate-400">
                        <span className="flex items-center gap-1">
                          <Cpu className="w-3.5 h-3.5 text-slate-400" />
                          <span className="truncate max-w-[120px] font-medium text-slate-500">{p.assignedModel.split(' ')[0]}</span>
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono bg-indigo-50 text-indigo-600 border border-indigo-100/50 px-2 py-0.5 rounded-md font-bold text-[9px] uppercase">
                            {p.progress}% Ready
                          </span>
                          <span className="text-indigo-600 hidden group-hover:inline-block font-bold text-[10px] animate-pulse">Open Workspace →</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>

        {/* Right Side: Active Workspace Assembly Visualizer */}
        <div className={`flex-1 overflow-y-auto ${selectedProjectId ? 'flex' : 'hidden'} flex-col bg-slate-150/20 p-5 sm:p-6 lg:p-8 min-w-0`}>
          
          {selectedProjectId ? (
            <div className="space-y-6 w-full max-w-6xl mx-auto">
              
              {/* Workspace Navigation back breadcrumb */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/50 pb-4 mb-2">
                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    onClick={() => setSelectedProjectId(null)}
                    className="flex items-center gap-1.5 text-xs text-slate-600 hover:text-slate-900 font-bold bg-white px-3 py-1.5 border border-slate-200 hover:border-slate-350 shadow-3xs rounded-xl cursor-pointer transition-all"
                  >
                    ← Back to Workspaces
                  </button>

                  <div className="flex items-center gap-1.5 text-xs text-slate-450 font-mono">
                    <span>Workspace Center</span>
                    <ChevronRight className="w-3 h-3 text-slate-350" />
                    <span className="text-slate-800 font-bold truncate max-w-[180px] sm:max-w-[320px]">{activeProject?.name}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2.5 shrink-0">
                  {activeProject && (
                    <button
                      onClick={(e) => handleDeleteProject(activeProject.id, e)}
                      className="flex items-center gap-1 px-2.5 py-1.5 text-[11px] text-rose-600 hover:text-white hover:bg-rose-600 bg-rose-50 border border-rose-200/60 rounded-xl transition-all font-bold cursor-pointer"
                      title="Delete Workspace"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete Workspace</span>
                    </button>
                  )}
                  <div className="flex items-center gap-1.5 shrink-0 bg-emerald-50 border border-emerald-100/50 px-2.5 py-1.5 rounded-xl">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                    </span>
                    <span className="text-[9.5px] font-mono text-emerald-600 font-bold uppercase tracking-wider">
                      Live
                    </span>
                  </div>
                </div>
              </div>

              {/* Master Stats Panel */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                
                {/* Router Info */}
                <div className="bg-white border border-slate-150 p-4.5 rounded-2xl shadow-3xs">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <span className="text-[102%] font-bold text-slate-900 font-sans">Distributed Router</span>
                  </div>
                  <div className="space-y-0.5 text-xs">
                    <p className="text-slate-500">Active Pipeline Strategy:</p>
                    <p className="font-mono font-bold text-slate-850 truncate text-[11.5px] uppercase">
                      {activeProject?.assignedModel}
                    </p>
                  </div>
                </div>

                {/* Savings Index */}
                <div className="bg-white border border-slate-150 p-4.5 rounded-2xl shadow-3xs">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-7 h-7 rounded-lg bg-green-50 text-green-600 flex items-center justify-center">
                      <DollarSign className="w-4 h-4" />
                    </div>
                    <span className="text-[102%] font-bold text-slate-900 font-sans">Cost Efficiency Index</span>
                  </div>
                  <div className="space-y-0.5 text-xs">
                    <p className="text-slate-500">Estimated Expenses Saved:</p>
                    <p className="font-mono font-bold text-green-600 text-[11.5px] flex items-center gap-1.5">
                      <span>98.6% Save Rate</span>
                      <span className="bg-green-50 text-green-700 px-1.5 rounded text-[8.5px] py-0.5 uppercase">Free-Tier Hub</span>
                    </p>
                  </div>
                </div>

                {/* File Count */}
                <div className="bg-white border border-slate-150 p-4.5 rounded-2xl shadow-3xs">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-7 h-7 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                      <FileCode className="w-4 h-4" />
                    </div>
                    <span className="text-[102%] font-bold text-slate-900 font-sans">Compiled Artifacts</span>
                  </div>
                  <div className="space-y-0.5 text-xs">
                    <p className="text-slate-500">Host Virtual Files Written:</p>
                    <p className="font-mono font-bold text-slate-850 text-[11.5px]">
                      {generatedFilesCount > 0 ? `${generatedFilesCount} code files generated` : 'Standing By to Compile'}
                    </p>
                  </div>
                </div>

                {/* Second Brain Ingest status */}
                <div className="bg-white border border-slate-150 p-4.5 rounded-2xl shadow-3xs">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-7 h-7 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
                      <Sliders className="w-4 h-4" />
                    </div>
                    <span className="text-[102%] font-bold text-slate-900 font-sans">Second Brain Context</span>
                  </div>
                  <div className="space-y-0.5 text-xs">
                    <p className="text-slate-500">Cognitive Memories Injected:</p>
                    <p className="font-mono font-bold text-purple-600 text-[11.5px] flex items-center gap-1">
                      <span>Active</span>
                      <span className="text-[10px] text-slate-400 font-normal">(Styling preferences parsed)</span>
                    </p>
                  </div>
                </div>

              </div>

              {/* Master Control Board Card */}
              <div className="bg-white border border-slate-150 rounded-2xl p-6 shadow-xs relative overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-green-500" />
                
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                  <div>
                    <h2 className="text-lg font-bold text-slate-900 tracking-tight">Orchestrated Multi-Agent Assembly Line</h2>
                    <p className="text-slate-500 text-xs mt-0.5">
                      Launch the pipeline sequence to trigger collaborative code layout, planning, diagnostics, and testing.
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {/* Assemblies Launch Actions */}
                    {pipelineStatus === 'running' ? (
                      <div className="flex items-center gap-2 px-4 py-2 border border-slate-200 font-mono text-[11px] rounded-xl text-indigo-600 bg-indigo-50/40 font-bold">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>AGENTS GENERATING CODE...</span>
                      </div>
                    ) : (
                      <button
                        onClick={startAssemblyLine}
                        className="flex items-center gap-1.5 px-4.5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Launch Project Pipeline</span>
                      </button>
                    )}

                    {pipelineStatus === 'completed' && !hasCrashBug && (
                      <button
                        onClick={handleSimulateCrash}
                        className="flex items-center gap-1.5 px-4 py-2 bg-rose-50 border border-rose-100 text-rose-700 rounded-xl text-xs font-bold hover:bg-rose-100 transition-all cursor-pointer"
                      >
                        <Flame className="w-3.5 h-3.5" />
                        <span>Inject Syntax Bug</span>
                      </button>
                    )}

                    {hasCrashBug && (
                      <button
                        onClick={executeSelfHealing}
                        disabled={isSelfHealing}
                        className={`flex items-center gap-1.5 px-4 py-2 ${isSelfHealing ? 'bg-amber-100 text-amber-800' : 'bg-emerald-600 text-white hover:bg-emerald-700'} rounded-xl text-xs font-bold transition-all animate-bounce cursor-pointer`}
                      >
                        <Wrench className={`w-3.5 h-3.5 ${isSelfHealing ? 'animate-spin' : ''}`} />
                        <span>{isSelfHealing ? 'Auto-Repair Active...' : 'Trigger Auto-Fix Loop'}</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Pipeline Flow Grid Representation */}
                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 gap-4 border border-slate-100 p-5.5 rounded-2xl bg-slate-50/50 mb-6">
                  {AGENTS_LIST.map((step) => {
                    const isPassed = currentStepIndex > step.id || pipelineStatus === 'completed';
                    const isActive = currentStepIndex === step.id && pipelineStatus === 'running';
                    const isTargetFailed = hasCrashBug && step.id === 6; // Fail QA on crash injection

                    let statusNode = null;
                    let borderClass = 'border-slate-200';
                    let textClass = 'text-slate-450';
                    let bgClass = 'bg-white';

                    if (isTargetFailed) {
                      borderClass = 'border-rose-400 bg-rose-50/20';
                      textClass = 'text-rose-800';
                      statusNode = <span className="text-[9.5px] text-rose-600 font-mono font-bold bg-rose-100 px-1.5 py-0.5 rounded">CRASHED (Syntax PRD)</span>;
                    } else if (isActive) {
                      borderClass = 'border-indigo-500 animate-pulse bg-indigo-50/10 ring-2 ring-indigo-150';
                      textClass = 'text-indigo-900';
                      statusNode = <span className="text-[9.5px] text-indigo-600 font-mono font-bold animate-ping uppercase">Generating...</span>;
                    } else if (isPassed) {
                      borderClass = 'border-emerald-300 bg-emerald-50/10';
                      textClass = 'text-slate-700';
                      statusNode = <span className="text-[9.5px] text-emerald-700 font-mono font-semibold flex items-center gap-1">✓ Active Spec</span>;
                    } else {
                      statusNode = <span className="text-[9.5px] text-slate-400 font-mono">Standby Operator</span>;
                    }

                    return (
                      <div 
                        key={step.id} 
                        className={`p-3.5 border rounded-xl flex flex-col justify-between transition-all ${borderClass} ${bgClass}`}
                      >
                        <div>
                          <div className="flex items-center justify-between gap-1.5 mb-1.5">
                            <span className="text-[10px] font-bold text-slate-400 font-mono">Agent #{step.id + 1}</span>
                            <span className={`text-[8.5px] uppercase font-mono px-1 border rounded scale-90 ${step.badgeColor}`}>
                              {step.provider}
                            </span>
                          </div>
                          
                          <p className={`text-xs font-bold leading-tight ${textClass} mb-1`}>
                            {step.name.split(' — ')[1]}
                          </p>
                          <p className="text-[10.5px] text-slate-500 leading-snug line-clamp-2">
                            {step.task}
                          </p>
                        </div>

                        <div className="border-t border-slate-100/60 pt-2.5 mt-3 flex items-center justify-between text-[10px] font-mono">
                          <span className="text-slate-450 truncate font-semibold">{step.model}</span>
                          <span>{statusNode}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Dual Console Panels (Streaming Terminal & Self-Healing logs) */}
                <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                  
                  {/* Assembly Line Live Output console */}
                  <div className="lg:col-span-3 flex flex-col">
                    <div className="flex items-center gap-2 mb-2 text-xs font-bold text-slate-800 font-mono">
                      <Terminal className="w-4 h-4 text-slate-500" />
                      <span>LIVE TELEMETRY COMPILE LOGS</span>
                    </div>

                    <div className="bg-slate-900 rounded-xl p-4 font-mono text-[11px] text-emerald-400 h-64 overflow-y-auto leading-relaxed border border-slate-800 shadow-inner">
                      {pipelineLogs.length === 0 ? (
                        <div className="text-slate-500 flex items-center justify-center h-full flex-col">
                          <Activity className="w-6 h-6 mb-2 animate-pulse text-slate-700" />
                          <span>Telemetry inactive. Press "Launch Project Pipeline" to begin.</span>
                        </div>
                      ) : (
                        <div className="space-y-1">
                          {pipelineLogs.map((log, index) => (
                            <div key={index} className="whitespace-pre-wrap">
                              {log}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Diagnosing Self-Healing Logs Panel */}
                  <div className="lg:col-span-2 flex flex-col">
                    <div className="flex items-center gap-2 mb-2 text-xs font-bold text-slate-800 font-mono">
                      <HeartPulse className="w-4 h-4 text-emerald-600" />
                      <span>SELF-HEALING CONTROLLER / DIAGNOSTIC PANEL</span>
                    </div>

                    <div className="bg-white border border-slate-200/80 rounded-xl p-4.5 flex-1 min-h-[256px] flex flex-col justify-between shadow-3xs">
                      
                      {/* Diagnostic header logic */}
                      <div>
                        {hasCrashBug ? (
                          <div className="p-3 bg-rose-50 border border-rose-100 text-rose-800 rounded-xl mb-3 flex items-start gap-2.5">
                            <span className="text-lg">⚠️</span>
                            <div>
                              <p className="text-xs font-bold leading-tight">Crash Exception Triggered</p>
                              <p className="text-[10px] text-rose-600 leading-normal mt-0.5">QA simulation detected port conflicts. Standby Auto-Fix loop to repair file headers.</p>
                            </div>
                          </div>
                        ) : (
                          <div className="p-3 bg-emerald-50/55 border border-emerald-100 text-emerald-800 rounded-xl mb-3 flex items-start gap-2.5">
                            <span className="text-lg">✓</span>
                            <div>
                              <p className="text-xs font-bold leading-tight">System Status: Optimal</p>
                              <p className="text-[10px] text-emerald-600 leading-normal mt-0.5">Integrity logs are clear. Free-tier open-source routing algorithm successfully routed to local container caches.</p>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Display Healing Action Logs */}
                      <div className="font-mono text-[10.5px] text-slate-650 bg-slate-50 border border-slate-100 p-3 rounded-lg flex-1 overflow-y-auto mb-3 max-h-40">
                        {healingLogs.length === 0 ? (
                          <span className="text-slate-400 block text-center mt-6">Diagnostic monitor idle.</span>
                        ) : (
                          <div className="space-y-1.5">
                            {healingLogs.map((hL, idx) => (
                              <div key={idx} className="leading-relaxed">
                                {hL}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      <div>
                        {hasCrashBug ? (
                          <button
                            onClick={executeSelfHealing}
                            disabled={isSelfHealing}
                            className={`w-full py-2 ${isSelfHealing ? 'bg-amber-100 text-amber-800' : 'bg-emerald-600 hover:bg-emerald-700 text-white font-bold'} text-xs rounded-xl font-sans transition-all flex items-center justify-center gap-2 cursor-pointer shadow-3xs`}
                          >
                            <Sparkles className="w-4 h-4" />
                            <span>{isSelfHealing ? 'Repairing Server Framework...' : 'Auto-Healed Node (Express Server)'}</span>
                          </button>
                        ) : (
                          <button
                            disabled
                            className="w-full py-2 bg-slate-100 border border-slate-200 text-slate-400 text-xs rounded-xl font-mono cursor-not-allowed text-center"
                          >
                            Standing By... No bugs currently injected
                          </button>
                        )}
                      </div>

                    </div>

                  </div>

                </div>

              </div>

              {/* Live Sandbox Interactive Compiler Container */}
              {selectedProjectId && (
                <div className="bg-white border border-slate-200/90 rounded-2xl overflow-hidden shadow-md">
                  
                  {/* Live preview header */}
                  <div className="bg-slate-900 px-5.5 py-3 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5 shrink-0">
                      <div className="w-3 h-3 rounded-full bg-rose-500 hover:scale-110 transition-transform" />
                      <div className="w-3 h-3 rounded-full bg-amber-500 hover:scale-110 transition-transform" />
                      <div className="w-3 h-3 rounded-full bg-emerald-500 hover:scale-110 transition-transform" />
                      <span className="text-xs font-mono text-slate-400 font-bold ml-1 uppercase tracking-wider">
                        Workspace Deployment Ingress Hub
                      </span>
                    </div>

                    {/* Active Tab Select Controls */}
                    <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 shrink-0 select-none">
                      <button
                        type="button"
                        onClick={() => setWorkspaceTab('sandbox')}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all relative cursor-pointer ${
                          workspaceTab === 'sandbox'
                            ? 'bg-indigo-600 text-white shadow-3xs'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <span>🌐 Live App Sandbox</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setWorkspaceTab('code')}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all relative cursor-pointer ${
                          workspaceTab === 'code'
                            ? 'bg-indigo-600 text-white shadow-3xs'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <span>💻 View Source Code ({generatedFilesCount} Files)</span>
                        {generatedFilesCount > 0 && pipelineStatus === 'running' && (
                          <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping shrink-0" />
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => setWorkspaceTab('models')}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all relative cursor-pointer ${
                          workspaceTab === 'models'
                            ? 'bg-indigo-600 text-white shadow-3xs'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <span>🧬 LLM Routing Hub</span>
                        {customModels.length > 0 && (
                          <span className="px-1.5 py-0.5 rounded text-[8.5px] bg-indigo-500/20 text-indigo-400 border border-indigo-500/35">
                            +{customModels.length}
                          </span>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Sandbox rendering based on selected project */}
                  {workspaceTab === 'sandbox' && (
                    <div>
                      {pipelineStatus === 'idle' && (
                        <div className="flex flex-col items-center justify-center p-12 bg-slate-950 text-slate-100 text-center min-h-[380px] rounded-b-2xl select-none animate-fadeIn">
                          <div className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-850 text-slate-400 flex items-center justify-center text-lg mb-4 animate-pulse">
                            🔌
                          </div>
                          <p className="text-white text-sm font-bold">Simulator Standby</p>
                          <p className="text-slate-450 text-xs max-w-sm mt-1">
                            Press <strong className="text-indigo-400 font-bold">"Launch Project Pipeline"</strong> above to spark the 8 distributed agents and deploy the virtual server container!
                          </p>
                        </div>
                      )}

                      {pipelineStatus === 'running' && (
                        <div className="flex flex-col items-center justify-center p-12 bg-slate-950 text-slate-100 text-center min-h-[380px] rounded-b-2xl select-none animate-fadeIn">
                          <div className="relative mb-6">
                            <div className="w-14 h-14 rounded-full border-4 border-dashed border-indigo-500 animate-spin flex items-center justify-center" />
                            <Sparkles className="w-6 h-6 text-indigo-400 absolute top-4 left-4" />
                          </div>
                          <p className="text-white text-sm font-bold">Collaborative AI Construction Active</p>
                          <p className="text-indigo-400 font-mono text-[10.5px] mt-1 bg-indigo-950/40 border border-indigo-900/30 px-3 py-1 rounded-full uppercase tracking-wider font-bold">
                            {AGENTS_LIST[currentStepIndex]?.name || 'Auto-Selecting Best Free-Tier Models...'}
                          </p>
                          <p className="text-slate-450 text-[11px] max-w-sm mt-3.5 leading-normal">
                            Agents are currently assembling code layout logic, mapping PRDs, and testing database routes. Click the <strong className="text-indigo-400">View Source Code</strong> tab above to check the code stream in real-time!
                          </p>
                        </div>
                      )}

                      {pipelineStatus === 'failed' && (
                        <div className="flex flex-col items-center justify-center p-12 bg-slate-950 text-rose-400 text-center min-h-[380px] rounded-b-2xl select-none animate-fadeIn">
                          <div className="w-12 h-12 rounded-xl bg-rose-950/30 border border-rose-900/30 text-rose-500 flex items-center justify-center text-lg mb-4 animate-bounce">
                            ⚠️
                          </div>
                          <p className="text-white text-sm font-bold">QA Integrity Check Failed</p>
                          <p className="text-slate-400 text-xs max-w-sm mt-1 mb-4">
                            Ingress check triggered. EADDRINUSE conflict caught on host listener. Execute the <strong className="text-emerald-400 font-bold">Auto-Healer</strong> panel above to deploy hotpatches securely.
                          </p>
                        </div>
                      )}

                      {pipelineStatus === 'completed' && (
                        <div>
                          {activeProject?.id === 'proj-1' && (
                    <div className="p-6 bg-slate-950 text-slate-200 min-h-[380px]">
                      
                      <div className="max-w-4xl mx-auto space-y-6">
                        <div className="flex items-start justify-between border-b border-slate-800/80 pb-4">
                          <div>
                            <span className="text-[10px] text-emerald-400 font-mono uppercase tracking-widest block font-bold">PROJECT SANDBOX</span>
                            <h3 className="text-base font-bold text-white mt-1">FrogeMind Desktop Gemma Tray Engine</h3>
                            <p className="text-xs text-slate-400 mt-0.5">Simulate system calls and model memory allocation parameter sliders directly.</p>
                          </div>

                          <div className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl text-xs font-mono text-indigo-300">
                            Local Environment: <span className="text-emerald-400 font-bold">Connected</span>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                          
                          <div className="md:col-span-5 bg-slate-900 border border-slate-800 p-5 rounded-xl space-y-4">
                            <h4 className="text-xs font-bold text-slate-350 uppercase tracking-wider border-b border-slate-800 pb-2">Hardware Alloc Modifiers</h4>
                            
                            <div>
                              <div className="flex justify-between text-xs mb-1.5 font-mono">
                                <span className="text-slate-400">GPU VRAM Cap:</span>
                                <span className="text-emerald-400 font-bold">{gpuMemory} GB</span>
                              </div>
                              <input 
                                type="range" 
                                min={2} 
                                max={16} 
                                value={gpuMemory}
                                onChange={(e) => setGpuMemory(Number(e.target.value))}
                                className="w-full accent-indigo-500 bg-slate-800 outline-none rounded"
                              />
                              <p className="text-[9.5px] text-slate-500 font-mono mt-1">Increasing VRAM allows larger context window processing.</p>
                            </div>

                            <div>
                              <div className="flex justify-between text-xs mb-1.5 font-mono">
                                <span className="text-slate-400">Offline Framework:</span>
                                <span className="text-indigo-400 font-semibold">Ollama standalone</span>
                              </div>
                              <div className="inline-flex gap-1.5 mt-1 bg-slate-950 px-2.5 py-1.5 rounded border border-slate-800 text-[10.5px] font-mono text-slate-300">
                                <span className="text-emerald-500 font-bold">●</span>
                                <span>Local Server: v0.1.48 ready</span>
                              </div>
                            </div>
                          </div>

                          <div className="md:col-span-7 space-y-3.5">
                            <div>
                              <label className="block text-xs text-slate-450 uppercase mb-1.5 font-mono font-semibold">Test Local Compile Prompt</label>
                              <div className="flex gap-2">
                                <input 
                                  type="text" 
                                  value={gemmaPrompt}
                                  onChange={(e) => setGemmaPrompt(e.target.value)}
                                  placeholder="e.g., Explain standard Electron browser windows..."
                                  className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-100 outline-none focus:border-indigo-500 font-mono"
                                />
                                <button
                                  onClick={() => {
                                    setIsGemmaRunning(true);
                                    setGemmaOutput('Loading local instruction maps...');
                                    setTimeout(() => {
                                      setIsGemmaRunning(false);
                                      setGemmaOutput(`[Gemma-2-9B Offline compilation] Success! Received payload response under ${gpuMemory}GB boundaries:
"Here is your customized local ipc socket setup in Node:
const { ipcMain } = require('electron');
ipcMain.handle('query-gemma', async (event, query) => {
  return invokeLocalHostNIM(query, { maxTokens: 512, cacheSize: ${gpuMemory * 1024} });
});"`);
                                    }, 1200);
                                  }}
                                  disabled={isGemmaRunning}
                                  className="px-4 py-2 bg-indigo-505 bg-indigo-600 font-bold text-white rounded-xl text-xs hover:bg-indigo-700 transition"
                                >
                                  {isGemmaRunning ? 'Processing...' : 'Run Query'}
                                </button>
                              </div>
                            </div>

                            <div className="bg-slate-900 border border-slate-800 p-4.5 rounded-xl min-h-[140px] font-mono text-xs text-indigo-300 leading-relaxed whitespace-pre-wrap">
                              {gemmaOutput || '// Click "Run Query" above to simulate local hardware instruction execution.'}
                            </div>
                          </div>

                        </div>
                      </div>

                    </div>
                  )}

                  {activeProject?.id === 'proj-2' && (
                    <div className="p-6 bg-slate-900 text-slate-100 min-h-[380px]">
                      
                      <div className="max-w-4xl mx-auto space-y-6">
                        <div className="flex items-start justify-between border-b border-slate-800 pb-3">
                          <div>
                            <span className="text-[10px] text-purple-400 font-mono uppercase tracking-widest block font-bold">COMPILER SANDBOX PREVIEW</span>
                            <h3 className="text-base font-bold text-white mt-1">Multi-Agent Pull Request Consensus Reviewer</h3>
                            <p className="text-xs text-slate-400 mt-0.5">Test simulated code checking logic across models concurrently to check consensus scoring.</p>
                          </div>

                          <div className="bg-purple-950/40 border border-purple-900 text-purple-300 px-3.5 py-2.5 rounded-2xl">
                            Consensus State: <span className="text-emerald-400 font-bold uppercase">Evaluated </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 pb-2">
                          <span className="text-xs text-slate-400 font-mono font-semibold uppercase">PR File Change Targets:</span>
                          {(['PR #107', 'PR #42', 'PR #23'] as const).map((pr) => (
                            <button
                              key={pr}
                              onClick={() => {
                                setSelectedPR(pr);
                                setReviewerOutput(false);
                                if (pr === 'PR #107') {
                                  setActivePRRef('feature/redis-pooling');
                                } else if (pr === 'PR #42') {
                                  setActivePRRef('patch/express-port-heal');
                                } else {
                                  setActivePRRef('feature/recaptha-window');
                                }
                              }}
                              className={`px-3 py-1 text-xs rounded-lg font-mono tracking-tight font-bold border transition ${
                                selectedPR === pr
                                  ? 'bg-purple-600 text-white border-purple-400'
                                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                              }`}
                            >
                              {pr}
                            </button>
                          ))}
                        </div>

                        <div className="bg-slate-955 bg-slate-950 p-4.5 rounded-xl border border-slate-800 font-mono text-[11.5px] text-slate-350">
                          <span className="text-purple-400">diff --git a/server.ts b/server.ts</span>
                          <p className="text-slate-500 mt-1">Index: 12abf84..a2182c4 100644</p>
                          {selectedPR === 'PR #107' && (
                            <div className="mt-2 space-y-0.5">
                              <p className="text-rose-500 hover:bg-rose-950/20">{"- const client = redis.createClient();"}</p>
                              <p className="text-emerald-500 hover:bg-emerald-950/20">{"+ const redisPool = new RedisConnectionPool({ maxActive: 15, timeout: 5000 });"}</p>
                              <p className="text-emerald-500 hover:bg-emerald-950/20">{"+ const client = await redisPool.acquire();"}</p>
                            </div>
                          )}
                          {selectedPR === 'PR #42' && (
                            <div className="mt-2 space-y-0.5">
                              <p className="text-rose-500 hover:bg-rose-950/20">{"- app.listen(3000);"}</p>
                              <p className="text-emerald-500 hover:bg-emerald-950/20">{"+ const PORT = process.env.PORT || 3000;"}</p>
                              <p className="text-emerald-500 hover:bg-emerald-950/20">{"+ app.listen(PORT, \"0.0.0.0\", () => console.log('Active port: ' + PORT));"}</p>
                            </div>
                          )}
                          {selectedPR === 'PR #23' && (
                            <div className="mt-2 space-y-0.5">
                              <p className="text-rose-500 hover:bg-rose-950/20">{"- window.open(\"https://auth.com\");"}</p>
                              <p className="text-emerald-500 hover:bg-emerald-950/20">{"+ const popupFrame = iframeBuilder.renderOverlay(\"https://auth.com\");"}</p>
                              <p className="text-emerald-500 hover:bg-emerald-950/20">{"+ document.body.appendChild(popupFrame);"}</p>
                            </div>
                          )}
                        </div>

                        <div className="flex justify-center">
                          <button
                            onClick={() => {
                              setIsPRReviewing(true);
                              setTimeout(() => {
                                setIsPRReviewing(false);
                                setReviewerOutput(true);
                              }, 1500);
                            }}
                            className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold rounded-xl text-xs hover:from-purple-500 hover:to-indigo-500 shadow transition-all cursor-pointer"
                          >
                            {isPRReviewing ? 'Running Cross-Model Consensus audit...' : 'Generate Claude vs DeepSeek dual-audited consensus'}
                          </button>
                        </div>

                        {reviewerOutput && (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
                              <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
                                <span className="text-xs font-bold text-white">Anthropic Claude 3.5</span>
                                <span className="text-[9px] bg-sky-950 text-sky-400 px-1.5 py-0.5 rounded font-mono">Structural Optimization</span>
                              </div>
                              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                                "The connection pool is syntactically clean and avoids garbage handler leaks. Code follows standard modular practices. Consider setting maximum idle connections dynamically."
                              </p>
                            </div>

                            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
                              <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
                                <span className="text-xs font-bold text-white">DeepSeek R1</span>
                                <span className="text-[9px] bg-emerald-950 text-emerald-400 px-1.5 py-0.5 rounded font-mono">Reasoning & Logic Reviewer</span>
                              </div>
                              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                                "Reasoning path indicates a race condition is possible if <code>redisPool.acquire()</code> is called concurrently before initial handshakes finish. Highly advise wrapping in single-instance singleton loader."
                              </p>
                            </div>
                          </div>
                        )}

                      </div>

                    </div>
                  )}

                  {activeProject?.id === 'proj-3' && (
                    <div className="p-6 bg-slate-900 text-slate-100 min-h-[380px]">
                      
                      <div className="max-w-4xl mx-auto space-y-6">
                        <div className="flex items-start justify-between border-b border-slate-800 pb-3">
                          <div>
                            <span className="text-[10px] text-indigo-400 font-mono uppercase tracking-widest block font-bold">GRAPHIC COMPILE OUTPUT</span>
                            <h3 className="text-base font-bold text-white mt-1">Automatic Vector SVG Asset Compiler</h3>
                            <p className="text-xs text-slate-400 mt-0.5">Intelligently renders vector graphics and geometric animations generated dynamically by Qwen-Coder.</p>
                          </div>

                          <div className="bg-indigo-950/40 border border-indigo-900 text-indigo-300 px-3.5 py-1.5 rounded-xl text-xs font-mono">
                            Renderer: <span className="text-indigo-400 font-bold">Dynamic SVG</span>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                          
                          <div className="md:col-span-5 bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4 font-sans text-xs">
                            <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono border-b border-slate-800 pb-2">Modify Graphic Node Settings</h4>
                            
                            <div>
                              <span className="text-slate-400 block mb-1.5">Accent Color Modifier:</span>
                              <div className="flex items-center gap-2">
                                <input 
                                  type="color" 
                                  value={svgAccent} 
                                  onChange={(e) => setSvgAccent(e.target.value)}
                                  className="w-10 h-8 bg-transparent border border-slate-800 rounded cursor-pointer"
                                />
                                <span className="font-mono text-slate-300">{svgAccent}</span>
                              </div>
                            </div>

                            <div>
                              <div className="flex justify-between mb-1 text-slate-400">
                                <span>Animation Speed:</span>
                                <span className="text-indigo-400 font-bold">{svgSpeed}s loop</span>
                              </div>
                              <input 
                                type="range" 
                                min={1} 
                                max={8} 
                                value={svgSpeed}
                                onChange={(e) => setSvgSpeed(Number(e.target.value))}
                                className="w-full accent-indigo-500 bg-slate-800 rounded outline-none"
                              />
                            </div>

                            <div>
                              <span className="text-slate-400 block mb-1.5">Graphic Vector Template:</span>
                              <div className="grid grid-cols-3 gap-1.5 font-mono text-[10px]">
                                {(['quantum', 'agents', 'grid'] as const).map((temp) => (
                                  <button
                                    key={temp}
                                    onClick={() => setSvgTemplate(temp)}
                                    className={`py-1 rounded border text-center transition ${
                                      svgTemplate === temp
                                        ? 'bg-indigo-600 text-white border-indigo-500 font-bold'
                                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                                    }`}
                                  >
                                    {temp.toUpperCase()}
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>

                          <div className="md:col-span-7 flex flex-col items-center justify-center bg-slate-950 border border-slate-805 p-6 rounded-2xl min-h-[250px]">
                            
                            {/* Renders animated inline SVGs according to options */}
                            <div className="w-full max-w-[200px]" style={{ transform: `scale(${svgScale / 100})` }}>
                              {svgTemplate === 'quantum' && (
                                <svg viewBox="0 0 100 100" className="w-full h-full">
                                  <defs>
                                    <linearGradient id="glow" x1="0%" y1="0%" x2="100%" y2="100%">
                                      <stop offset="0%" stopColor={svgAccent} />
                                      <stop offset="100%" stopColor="#ec4899" />
                                    </linearGradient>
                                  </defs>
                                  {/* Multi orbital paths */}
                                  <ellipse cx="50" cy="50" rx="40" ry="12" fill="none" stroke="url(#glow)" strokeWidth="1.5" strokeDasharray="4,4" transform="rotate(30 50 50)">
                                    <animateTransform attributeName="transform" type="rotate" from="30 50 50" to="390 50 50" dur={`${svgSpeed * 2}s`} repeatCount="indefinite" />
                                  </ellipse>
                                  <ellipse cx="50" cy="50" rx="40" ry="12" fill="none" stroke="url(#glow)" strokeWidth="1.5" transform="rotate(120 50 50)">
                                    <animateTransform attributeName="transform" type="rotate" from="120 50 50" to="480 50 50" dur={`${svgSpeed}s`} repeatCount="indefinite" />
                                  </ellipse>
                                  <circle cx="50" cy="50" r="10" fill={svgAccent} className="animate-pulse" />
                                  {/* Satellites */}
                                  <circle cx="90" cy="50" r="3" fill="#ffffff" transform="rotate(30 50 50)">
                                    <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur={`${svgSpeed}s`} repeatCount="indefinite" />
                                  </circle>
                                </svg>
                              )}

                              {svgTemplate === 'agents' && (
                                <svg viewBox="0 0 100 100" className="w-full h-full">
                                  {/* Triangle agent graph */}
                                  <polygon points="50,15 15,80 85,80" fill="none" stroke="#2563eb" strokeWidth="1.5" />
                                  {/* Circles on corners */}
                                  <circle cx="50" cy="15" r="7" fill={svgAccent}>
                                    <animate attributeName="r" values="6;8;6" dur={`${svgSpeed}s`} repeatCount="indefinite" />
                                  </circle>
                                  <circle cx="15" cy="80" r="7" fill="#b91c1c" />
                                  <circle cx="85" cy="80" r="7" fill="#15803d" />
                                  
                                  {/* Center interconnecting atom */}
                                  <circle cx="50" cy="55" r="5" fill="#ffffff" className="animate-bounce" />
                                  <line x1="50" y1="15" x2="50" y2="55" stroke="#ffffff" strokeWidth="1" strokeDasharray="2,2" />
                                  <line x1="15" y1="80" x2="50" y2="55" stroke="#ffffff" strokeWidth="1" strokeDasharray="2,2" />
                                  <line x1="85" y1="80" x2="50" y2="55" stroke="#ffffff" strokeWidth="1" strokeDasharray="2,2" />
                                </svg>
                              )}

                              {svgTemplate === 'grid' && (
                                <svg viewBox="0 0 100 100" className="w-full h-full">
                                  {/* Grid representation */}
                                  <rect x="10" y="10" width="22" height="22" rx="4" fill="none" stroke={svgAccent} strokeWidth="1.5" />
                                  <rect x="39" y="10" width="22" height="22" rx="4" fill="none" stroke={svgAccent} strokeWidth="1.5" />
                                  <rect x="68" y="10" width="22" height="22" rx="4" fill="none" stroke={svgAccent} strokeWidth="1.5" />
                                  
                                  <rect x="10" y="39" width="22" height="22" rx="4" fill="none" stroke={svgAccent} strokeWidth="1.5" />
                                  <rect x="39" y="39" width="22" height="22" rx="4" fill={svgAccent} strokeWidth="1.5" className="animate-pulse" />
                                  <rect x="68" y="39" width="22" height="22" rx="4" fill="none" stroke={svgAccent} strokeWidth="1.5" />
                                  
                                  <rect x="10" y="68" width="22" height="22" rx="4" fill="none" stroke={svgAccent} strokeWidth="1.5" />
                                  <rect x="39" y="68" width="22" height="22" rx="4" fill="none" stroke={svgAccent} strokeWidth="1.5" />
                                  <rect x="68" y="68" width="22" height="22" rx="4" fill="none" stroke={svgAccent} strokeWidth="1.5" />
                                </svg>
                              )}
                            </div>

                            <span className="text-[10.5px] font-mono text-slate-500 mt-5 block text-center leading-normal max-w-sm">
                              SVG parameters successfully loaded dynamic configurations. Graphic output runs at 60 FPS natively.
                            </span>

                          </div>

                        </div>
                      </div>

                    </div>
                  )}

                  {/* Standard newly created project sandbox template */}
                  {activeProject?.id !== 'proj-1' && activeProject?.id !== 'proj-2' && activeProject?.id !== 'proj-3' && (
                    <div className="p-6 bg-slate-900 text-slate-200 min-h-[380px]">
                      
                      <div className="max-w-4xl mx-auto space-y-6">
                        <div className="flex items-start justify-between border-b border-slate-800 pb-3">
                          <div>
                            <span className="text-[10px] text-indigo-400 font-mono uppercase tracking-widest block font-bold">AUTONOMOUS BUILD TEMPLATE</span>
                            <h3 className="text-base font-bold text-white mt-1">{activeProject?.name || 'Custom Application'}</h3>
                            <p className="text-xs text-slate-400 mt-0.5">A completely functional messaging endpoint mapped by our Multi-Agent loop.</p>
                          </div>

                          <div className="bg-slate-800 border border-slate-705 px-3 py-1 text-xs font-mono text-indigo-300 rounded">
                            Host: <span className="text-emerald-400 font-bold">Local Container</span>
                          </div>
                        </div>

                        <div className="bg-slate-950 p-5 rounded-2xl space-y-4">
                          <p className="text-[11.5px] text-slate-400 font-sans leading-relaxed">
                            "This system has successfully integrated with your designated Smart Router instructions. Test simulated prompts below to communicate with the virtual Multi-Agent cluster."
                          </p>

                          <div className="space-y-3">
                            <div className="bg-slate-900 p-4 rounded-xl min-h-[100px] border border-slate-850 font-mono text-xs text-slate-350">
                              {sandboxResponse ? (
                                <p className="leading-relaxed whitespace-pre-wrap">{sandboxResponse}</p>
                              ) : (
                                <span className="text-slate-550 italic">// No prompt executed yet. Complete the form to run.</span>
                              )}
                            </div>

                            <div className="flex gap-2.5">
                              <input 
                                type="text"
                                placeholder="Query the newly deployed mock environment..."
                                value={sandboxPrompt}
                                onChange={(e) => setSandboxPrompt(e.target.value)}
                                className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white outline-none focus:border-indigo-400 font-sans"
                              />
                              <button
                                onClick={() => {
                                  if (!sandboxPrompt.trim()) return;
                                  setSandboxResponse('Synthesizing agent pipeline nodes...');
                                  setTimeout(() => {
                                    setSandboxResponse(`[Distributed Assembler Hub] Prompt captured: "${sandboxPrompt}"
- Agent 1 (Analyzer) checked intent: General Dialogue.
- Agent 4 (UI Designer) recommended standard system cards.
- Qwen 2.5 Coder response outputted:
"Your custom task execution for '${sandboxPrompt}' has completed compilation successfully under distributed LLM routing grids. All status variables are running green."`);
                                  }, 1100);
                                }}
                                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 font-bold text-white rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-3xs"
                              >
                                <Send className="w-3.5 h-3.5" />
                                <span>Query sandbox</span>
                              </button>
                            </div>
                          </div>
                        </div>

                      </div>

                    </div>
                  )}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Compiled Code Editor View Tab (IDE layout) */}
                  {workspaceTab === 'code' && (
                    <div className="bg-slate-950 grid grid-cols-1 md:grid-cols-12 min-h-[380px] text-slate-200 divide-y md:divide-y-0 md:divide-x divide-slate-850 border-t border-slate-850 animate-fadeIn">
                      
                      {/* Left Sidebar: Compiled Files list */}
                      <div className="md:col-span-4 p-4.5 space-y-3.5 flex flex-col justify-between bg-slate-950 select-none">
                        <div>
                          <span className="text-[10px] uppercase font-mono tracking-wider text-slate-500 font-bold block mb-2.5">
                            Autonomous Source Files:
                          </span>
                          
                          <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
                            {getVirtualFiles(activeProject?.id || '')
                              .slice(0, Math.max(1, Math.min(getVirtualFiles(activeProject?.id || '').length, getVisibleFilesCount())))
                              .map((file, idx) => {
                                const isSelected = selectedFileIndex === idx;
                                return (
                                  <button
                                    type="button"
                                    key={idx}
                                    onClick={() => setSelectedFileIndex(idx)}
                                    className={`w-full flex items-center justify-between text-left px-3 py-2 rounded-xl text-xs font-mono transition-all border cursor-pointer ${
                                      isSelected 
                                        ? 'bg-indigo-950/40 text-indigo-400 border-indigo-900/40 font-bold shadow-3xs' 
                                        : 'text-slate-400 hover:text-slate-200 border-transparent hover:bg-slate-900/60'
                                    }`}
                                  >
                                    <div className="flex items-center gap-2 truncate">
                                      {file.name.endsWith('.md') ? <FileText className="w-3.5 h-3.5 text-blue-400" /> :
                                       file.name.endsWith('.json') ? <Sliders className="w-3.5 h-3.5 text-amber-400" /> :
                                       <Code className="w-3.5 h-3.5 text-indigo-405" />}
                                      <span className="truncate">{file.name}</span>
                                    </div>
                                    <span className="text-[8px] bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800 text-slate-500 scale-90 select-none uppercase font-bold shrink-0 font-sans">
                                      {file.language}
                                    </span>
                                  </button>
                                );
                              })}
                          </div>
                        </div>

                        {/* Telemetry info widget */}
                        <div className="bg-slate-900/50 border border-slate-800/60 p-3.5 rounded-xl">
                          <div className="flex items-center gap-2 text-[9.5px] font-mono text-indigo-400 uppercase font-bold mb-1">
                            <Atom className="w-4 h-4 text-indigo-400 animate-spin" />
                            <span>Simulation Sandbox VVM</span>
                          </div>
                          <p className="text-[10px] text-slate-455 text-slate-405 leading-relaxed font-sans">
                            Hot-mounted server tree registering **{generatedFilesCount}** compile references safely isolated on local processes.
                          </p>
                        </div>
                      </div>

                      {/* Right column: Dark code viewer block */}
                      <div className="md:col-span-8 p-5 flex flex-col bg-slate-950">
                        <div className="flex items-center justify-between border-b border-slate-850 pb-2.5 mb-3 text-[10.5px] font-mono">
                          <span className="text-slate-400 truncate pr-3">{getVirtualFiles(activeProject?.id || '')[selectedFileIndex]?.path || '/src/main.ts'}</span>
                          <span className="text-indigo-400 bg-indigo-950/50 border border-indigo-900/30 px-2 py-0.5 rounded uppercase font-bold shrink-0 text-[10px] tracking-wider select-none font-sans">
                            {getVirtualFiles(activeProject?.id || '')[selectedFileIndex]?.language || 'typescript'} syntax
                          </span>
                        </div>

                        {/* Code block */}
                        <div className="flex-1 overflow-auto bg-slate-900/35 border border-slate-850 rounded-xl p-4 font-mono text-xs leading-relaxed text-slate-300 max-h-[290px] select-text">
                          <pre className="whitespace-pre overflow-x-auto select-text font-mono">
                            {getVirtualFiles(activeProject?.id || '')[selectedFileIndex]?.content || '// No source files generated yet. Complete step items to generate code components.'}
                          </pre>
                        </div>
                      </div>

                    </div>
                  )}

                  {/* LLM Engine Analytics and Custom Provisioning Hub */}
                  {workspaceTab === 'models' && (
                    <div className="bg-slate-950 p-6 rounded-b-2xl text-slate-200 animate-fadeIn border-t border-slate-850">
                      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 text-left">
                        
                        {/* Left column: Model Metrics Specs & Interactive Analyzer (col-span-12 lg:col-span-7) */}
                        <div className="col-span-12 lg:col-span-7 space-y-5">
                          
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                            <div>
                              <h4 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
                                <span className="p-1 rounded bg-indigo-950 text-indigo-400">🔬</span>
                                <span>Analytical Specifications Engine</span>
                              </h4>
                              <p className="text-[11px] text-slate-400 mt-1 leading-normal">
                                Evaluate key processing metrics, recommended configurations and safety isolation thresholds for active LLMs.
                              </p>
                            </div>
                            
                            {/* Comparison Selector Dropdown */}
                            <div className="flex items-center gap-2 shrink-0">
                              <span className="text-[10px] font-mono text-slate-400 font-bold uppercase tracking-wider">Active:</span>
                              <select
                                value={modelCompareId}
                                onChange={(e) => setModelCompareId(e.target.value)}
                                className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-indigo-400 outline-none font-bold cursor-pointer"
                              >
                                {Object.keys(DEFAULT_MODELS_META).map((mKey) => (
                                  <option key={mKey} value={mKey}>{mKey}</option>
                                ))}
                                {customModels.map((cm, idx) => (
                                  <option key={`c-${idx}`} value={cm.name}>{cm.name} (Custom)</option>
                                ))}
                              </select>
                            </div>
                          </div>

                          {/* Computed Metrics Block */}
                          {(() => {
                            // Find metadata
                            let currentMeta: ModelMeta | null = null;
                            const standardMeta = DEFAULT_MODELS_META[modelCompareId];
                            if (standardMeta) {
                              currentMeta = standardMeta;
                            } else {
                              const foundCustom = customModels.find(cm => cm.name === modelCompareId);
                              if (foundCustom) {
                                currentMeta = {
                                  name: foundCustom.name,
                                  category: foundCustom.provider,
                                  speed: foundCustom.speed,
                                  logic: foundCustom.logic,
                                  context: foundCustom.contextLimit,
                                  cost: 'Private Ingress / Token proxy',
                                  idealFor: foundCustom.idealFor,
                                  safety: 'SSL Loopback Encrypted Bridge'
                                };
                              }
                            }

                            if (!currentMeta) {
                              return <p className="text-xs text-slate-400">Loading model specifications...</p>;
                            }

                            return (
                              <div className="space-y-4">
                                
                                {/* Header badge block */}
                                <div className="p-4 bg-slate-900/40 border border-slate-850 rounded-xl flex items-center justify-between">
                                  <div>
                                    <span className="text-[10px] uppercase font-mono tracking-widest text-indigo-400 font-bold block">
                                      {currentMeta.category}
                                    </span>
                                    <span className="text-base font-bold text-white mt-0.5 block">{currentMeta.name}</span>
                                  </div>
                                  <div className="text-right">
                                    <span className="text-[10px] font-mono text-slate-400 block uppercase font-bold">Context Limit</span>
                                    <span className="text-xs font-mono font-bold text-emerald-400 mt-0.5 block">{currentMeta.context}</span>
                                  </div>
                                </div>

                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-sans">
                                  {/* Speed Gauge bar */}
                                  <div className="bg-slate-900/25 border border-slate-900 p-4 rounded-xl">
                                    <div className="flex justify-between items-center text-xs mb-1.5 animate-slideUp">
                                      <span className="text-slate-400 font-medium">Coding Speed & Throughput</span>
                                      <span className="font-mono text-indigo-400 font-bold">{currentMeta.speed} Tokens/s</span>
                                    </div>
                                    <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                                      <div 
                                        style={{ width: `${Math.min(100, (currentMeta.speed / 150) * 105)}%` }}
                                        className="h-full bg-indigo-500 rounded-full transition-all duration-500"
                                      />
                                    </div>
                                    <p className="text-[10px] text-slate-500 mt-1.5 leading-normal">Estimates processing latency during heavy AST syntax tree assembly loops.</p>
                                  </div>

                                  {/* Logic Gauge bar */}
                                  <div className="bg-slate-900/25 border border-slate-900 p-4 rounded-xl">
                                    <div className="flex justify-between items-center text-xs mb-1.5 animate-slideUp">
                                      <span className="text-slate-400 font-medium">Reasoning Depth & Logic</span>
                                      <span className="font-mono text-emerald-400 font-bold">{currentMeta.logic}/100 Score</span>
                                    </div>
                                    <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                                      <div 
                                        style={{ width: `${currentMeta.logic}%` }}
                                        className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                                      />
                                    </div>
                                    <p className="text-[10px] text-slate-500 mt-1.5 leading-normal">Demonstrates semantic consistency and complex multi-agent error-correction capability.</p>
                                  </div>
                                </div>

                                {/* Deep analytical rows */}
                                <div className="bg-slate-900/30 border border-slate-850 rounded-xl divide-y divide-slate-850 p-1 text-xs">
                                  <div className="p-3 flex justify-between gap-4">
                                    <span className="text-slate-400 font-medium shrink-0">Ideal Developer Scenario:</span>
                                    <span className="text-slate-200 text-right font-sans leading-relaxed">{currentMeta.idealFor}</span>
                                  </div>
                                  <div className="p-3 flex justify-between gap-4">
                                    <span className="text-slate-400 font-medium shrink-0">Pricing & Cost Plan:</span>
                                    <span className="text-indigo-400 font-mono text-[11px] bg-slate-900 px-2 py-0.5 rounded border border-slate-800">{currentMeta.cost}</span>
                                  </div>
                                  <div className="p-3 flex justify-between gap-4">
                                    <span className="text-slate-400 font-medium shrink-0">Safety & Sandboxed Guard:</span>
                                    <span className="text-slate-300 font-mono text-[11px]">{currentMeta.safety}</span>
                                  </div>
                                </div>

                                {/* Active project switch helper actions */}
                                {activeProject ? (
                                  <div className="bg-slate-900/35 border border-indigo-950/40 p-4 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-inner">
                                    <div>
                                      <p className="text-xs font-bold text-white">Apply {currentMeta.name} to selected workspace?</p>
                                      <p className="text-[11px] text-slate-400 mt-0.5 leading-normal">This sets the active compilation engine for **{activeProject.name}**.</p>
                                    </div>
                                    <button
                                      type="button"
                                      disabled={activeProject.assignedModel === currentMeta.name}
                                      onClick={() => {
                                        setProjects(projects.map(p => p.id === activeProject.id ? { ...p, assignedModel: currentMeta!.name } : p));
                                        addLog(`[SYSTEM] Modified workspace logic node to: "${currentMeta!.name}" successfully.`);
                                      }}
                                      className={`px-4 py-1.5 text-xs font-bold rounded-lg cursor-pointer transition-all shrink-0 ${
                                        activeProject.assignedModel === currentMeta.name
                                          ? 'bg-slate-850 text-slate-500 border border-transparent cursor-not-allowed'
                                          : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-3xs'
                                      }`}
                                    >
                                      {activeProject.assignedModel === currentMeta.name ? 'Already Checked' : 'Route Workspace Gateway'}
                                    </button>
                                  </div>
                                ) : (
                                  <div className="p-4 bg-slate-900/30 border border-slate-850 rounded-xl text-center text-xs text-slate-400 font-medium">
                                    Select an active project workspace in the sidebar to assign this LLM routing logic directly.
                                  </div>
                                )}

                              </div>
                            );
                          })()}

                        </div>

                        {/* Right column: Form to register a brand new dynamic Custom LLM Parameter (col-span-12 lg:col-span-5) */}
                        <div className="col-span-12 lg:col-span-5 bg-slate-900/20 border border-slate-850 p-5 rounded-2xl flex flex-col justify-between">
                          
                          <div>
                            <div className="flex items-center gap-2 mb-3.5 pb-2.5 border-b border-slate-850">
                              <Plus className="w-4 h-4 text-emerald-400" />
                              <h4 className="text-xs font-bold font-mono uppercase tracking-wider text-white">
                                Integrate Custom LLM Endpoint
                              </h4>
                            </div>

                            <form onSubmit={handleRegisterCustomModel} className="space-y-4 font-sans text-left">
                              <div>
                                <label className="block text-[10px] font-bold text-slate-405 uppercase tracking-widest mb-1 font-mono">
                                  Model Identifier Name
                                </label>
                                <input
                                  type="text"
                                  required
                                  value={customModelName}
                                  onChange={(e) => setCustomModelName(e.target.value)}
                                  placeholder="e.g., Llama-3-Fintech-Tuned"
                                  className="w-full text-xs px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl focus:border-indigo-500 outline-none focus:bg-slate-900/60 text-slate-200 font-bold"
                                />
                              </div>

                              <div>
                                <label className="block text-[10px] font-bold text-slate-455 uppercase tracking-widest mb-1 font-mono">
                                  Client Model Provider
                                </label>
                                <select
                                  value={customModelProvider}
                                  onChange={(e) => setCustomModelProvider(e.target.value)}
                                  className="w-full text-xs px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl focus:border-indigo-500 outline-none text-slate-305 cursor-pointer"
                                >
                                  <option value="OpenAI Compatible API">OpenAI Compatible API</option>
                                  <option value="Ollama (Local Host Engine)">Ollama (Local Hub)</option>
                                  <option value="Google Vertex AI Core">Google Vertex AI Core</option>
                                  <option value="Anthropic API proxy">Anthropic AWS / API Bedrock</option>
                                  <option value="HuggingFace Space Native">HuggingFace Space Inference</option>
                                  <option value="DeepSeek Official Endpoint">DeepSeek Official API Ingress</option>
                                </select>
                              </div>

                              <div>
                                <label className="block text-[10px] font-bold text-slate-455 uppercase tracking-widest mb-1 font-mono">
                                  Target API Base Endpoint URL
                                </label>
                                <input
                                  type="text"
                                  required
                                  value={customModelEndpoint}
                                  onChange={(e) => setCustomModelEndpoint(e.target.value)}
                                  placeholder="e.g., https://api.openai.com/v1"
                                  className="w-full text-xs px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl focus:border-indigo-500 outline-none text-slate-250 font-mono"
                                />
                              </div>

                              <div className="grid grid-cols-2 gap-3.5">
                                <div>
                                  <label className="block text-[10px] font-bold text-slate-455 uppercase tracking-widest mb-1 font-mono">
                                    Context Window
                                  </label>
                                  <select
                                    value={customModelContext}
                                    onChange={(e) => setCustomModelContext(e.target.value)}
                                    className="w-full text-xs px-2.5 py-1.5 bg-slate-900 border border-slate-800 rounded-lg focus:border-indigo-500 outline-none text-slate-305 font-mono cursor-pointer"
                                  >
                                    <option value="8k tokens">8k Tokens</option>
                                    <option value="32k tokens">32k Tokens</option>
                                    <option value="128k tokens">128k Tokens</option>
                                    <option value="1M+ Ultra-Scale font-mono">1M+ Tokens</option>
                                  </select>
                                </div>

                                <div>
                                  <label className="block text-[10px] font-bold text-slate-405 uppercase tracking-widest mb-1 font-mono font-medium">
                                    Security Isolation
                                  </label>
                                  <div className="text-[10.5px] font-mono text-emerald-400 bg-emerald-950/20 px-2 py-1.5 rounded border border-emerald-900/30 text-center font-bold">
                                    🔒 Isolated Sandbox
                                  </div>
                                </div>
                              </div>

                              <div>
                                <label className="block text-[10px] font-bold text-slate-405 uppercase tracking-widest mb-1 font-mono font-sans font-semibold text-slate-400">
                                  Ideal Developer Use case
                                </label>
                                <input
                                  type="text"
                                  required
                                  value={customModelIdealFor}
                                  onChange={(e) => setCustomModelIdealFor(e.target.value)}
                                  placeholder="Describe what tasks this custom model is great for"
                                  className="w-full text-xs px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl focus:border-indigo-500 outline-none text-slate-200"
                                />
                              </div>

                              <div className="grid grid-cols-2 gap-3.5 font-sans">
                                <div>
                                  <label className="block text-[10px] font-bold text-slate-405 uppercase tracking-widest mb-1 font-mono">
                                    Speed (tok/s)
                                  </label>
                                  <input
                                    type="number"
                                    min={10}
                                    max={300}
                                    value={customModelSpeed}
                                    onChange={(e) => setCustomModelSpeed(Number(e.target.value))}
                                    className="w-full text-xs px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg focus:border-indigo-550 text-slate-350 font-mono"
                                  />
                                </div>

                                <div>
                                  <label className="block text-[10px] font-bold text-slate-455 uppercase tracking-widest mb-1 font-mono">
                                    Logic Accuracy (1-100)
                                  </label>
                                  <input
                                    type="number"
                                    min={10}
                                    max={100}
                                    value={customModelLogic}
                                    onChange={(e) => setCustomModelLogic(Number(e.target.value))}
                                    className="w-full text-xs px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg focus:border-indigo-550 text-slate-350 font-mono"
                                  />
                                </div>
                              </div>

                              <div className="pt-3">
                                <button
                                  type="submit"
                                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl cursor-pointer shadow-3xs flex items-center justify-center gap-1.5 transition-all"
                                >
                                  <span>🚀 Add LLM Model Gateway</span>
                                </button>
                              </div>
                            </form>
                          </div>

                          {/* Render custom integrated list */}
                          {customModels.length > 0 && (
                            <div className="mt-5 pt-4.5 border-t border-slate-850 text-left">
                              <span className="text-[10.5px] font-bold font-mono text-slate-500 uppercase tracking-widest block mb-2">
                                Registered Gateways ({customModels.length})
                              </span>
                              <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                                {customModels.map((cm, idx) => (
                                  <div key={idx} className="flex items-center justify-between p-2 bg-slate-900 border border-slate-850 rounded-lg text-xs">
                                    <div className="truncate max-w-[160px]">
                                      <p className="font-bold text-slate-100 truncate">{cm.name}</p>
                                      <p className="text-[10px] text-slate-500 font-mono truncate">{cm.apiEndpoint}</p>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => handleRemoveCustomModel(cm.name)}
                                      className="text-rose-400 hover:text-rose-500 bg-rose-950/20 px-2.5 py-1 rounded border border-rose-900/30 text-[10px] font-bold cursor-pointer transition-all shrink-0"
                                    >
                                      Delete
                                    </button>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                        </div>

                      </div>
                    </div>
                  )}

                </div>
              )}

              {/* Traditional Tasks and milestone list section */}
              <div className="bg-white border border-slate-150 rounded-2xl p-6 shadow-xs">
                
                <div className="flex items-center justify-between gap-3 border-b border-slate-100 pb-4 mb-4.5">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 uppercase tracking-widest font-mono">WORKSPACE CHECKLIST & OBJECTIVES</h3>
                    <p className="text-slate-500 text-[11px] mt-0.5">Ensure specific milestones align before invoking the final production release tags.</p>
                  </div>

                  <span className="text-xs font-mono font-bold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-xl">
                    {activeProject?.progress}% Total Completeness
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Milestones Left */}
                  <div className="space-y-2.5">
                    <span className="text-[10px] uppercase font-mono font-bold text-slate-400">Pending goals</span>
                    
                    <div className="space-y-2">
                      {activeProject?.tasks.map((task) => (
                        <div 
                          key={task.id}
                          onClick={() => handleToggleTask(activeProject?.id || '', task.id)}
                          className="flex items-start gap-3 bg-slate-50/40 hover:bg-slate-50 p-3 rounded-xl border border-slate-150/50 cursor-pointer select-none transition-colors"
                        >
                          <input
                            type="checkbox"
                            checked={task.done}
                            onChange={() => {}} // Controlled by outer div click
                            className="mt-0.5 rounded border-slate-300 text-indigo-600 focus:ring-0 accent-indigo-600 cursor-pointer"
                          />
                          <span className={`text-[12px] leading-tight ${task.done ? 'line-through text-slate-400' : 'text-slate-700 font-medium'}`}>
                            {task.text}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Add action task form */}
                  <div className="space-y-4 bg-slate-50/50 border border-slate-200/60 p-5 rounded-2xl">
                    <div>
                      <h4 className="text-xs font-bold text-slate-800">Add custom project requirement</h4>
                      <p className="text-slate-500 text-[10.5px] mt-0.5">These items feed into Agentic analysis during next pipeline pass.</p>
                    </div>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="e.g., Setup secure JWT authentication endpoints..."
                        value={taskInputs[activeProject?.id || ''] || ''}
                        onChange={(e) => setTaskInputs({ ...taskInputs, [activeProject?.id || '']: e.target.value })}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            handleAddTask(activeProject?.id || '', taskInputs[activeProject?.id || ''] || '');
                            setTaskInputs({ ...taskInputs, [activeProject?.id || '']: '' });
                          }
                        }}
                        className="flex-1 text-xs px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl focus:border-indigo-400 outline-none font-sans"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          handleAddTask(activeProject?.id || '', taskInputs[activeProject?.id || ''] || '');
                          setTaskInputs({ ...taskInputs, [activeProject?.id || '']: '' });
                        }}
                        className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-all cursor-pointer shadow-3xs"
                      >
                        Add
                      </button>
                    </div>
                  </div>

                </div>

              </div>

            </div>
          ) : (
            
            // Welcome screen of Workspace Board (Prompt entry / introductory visual OS)
            <div className="flex-1 flex flex-col items-center justify-center text-center p-6 max-w-2xl mx-auto my-auto">
              
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-indigo-500 via-indigo-600 to-sky-500 flex items-center justify-center text-white font-mono font-bold text-lg shadow-md mb-6 animate-pulse">
                <Atom className="w-8 h-8" />
              </div>

              <span className="text-[10px] font-mono font-bold text-indigo-600 uppercase tracking-widest bg-indigo-50 px-3 py-1 rounded-full mb-3">
                Distributed multi-agent pipeline ready
              </span>

              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                Welcome to FrogeMind Engineering Workspace
              </h2>

              <p className="text-slate-500 text-xs sm:text-sm leading-relaxed mt-2.5 mb-8">
                In this environment, you do not just prompt a single model — your prompts automatically deploy an entire **8-Agent Pipeline** utilizing our smart routing engine. We distribute tasks to the best free-tier open models (Gemini Flash, Groq LPUs, and NVIDIA hardware nodes) to plan, design, write, test, and self-heal your codebases efficiently.
              </p>

              {/* Quick Workspace Template Starters */}
              <div className="w-full space-y-4">
                <div className="text-left">
                  <span className="text-[9px] uppercase font-mono tracking-wider text-slate-400 font-bold block mb-2 px-1">
                    Select a workspace template below to explore the visual pipeline:
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  {projects.map((p) => (
                    <div 
                      key={p.id}
                      onClick={() => {
                        setSelectedProjectId(p.id);
                        setPipelineLogs([]);
                        setCurrentStepIndex(-1);
                        setPipelineStatus('idle');
                        setHasCrashBug(false);
                        setHealingLogs([]);
                        setWorkspaceTab('sandbox');
                        setSelectedFileIndex(0);
                      }}
                      className="text-left p-4.5 bg-white border border-slate-200/80 rounded-2xl hover:border-indigo-400 hover:bg-indigo-50/5 cursor-pointer shadow-3xs hover:shadow-xs transition-all flex flex-col justify-between min-h-[140px]"
                    >
                      <div>
                        <span className="text-[9px] font-mono font-bold text-indigo-500 uppercase block tracking-wider mb-1">
                          #{p.tags[0]}
                        </span>
                        <h4 className="text-xs font-bold text-slate-900 line-clamp-1 mb-1">{p.name}</h4>
                        <p className="text-[10.5px] text-slate-500 leading-normal line-clamp-3">
                          {p.description}
                        </p>
                      </div>

                      <span className="text-[9.5px] font-mono text-slate-400 block border-t border-slate-100/60 pt-2 mt-2 leading-none font-bold">
                        Open Workspace →
                      </span>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

        </div>

      </div>

      <AnimatePresence>
        {isCreating && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-900/45 backdrop-blur-xs flex items-center justify-center p-4 select-none"
          >
            <motion.div
              initial={{ scale: 0.95, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 10 }}
              className="bg-white border border-slate-200 shadow-xl rounded-3xl w-full max-w-lg p-6 sm:p-8"
            >
              <div className="flex items-center gap-2 mb-1">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-600" />
                <h3 className="text-base font-bold text-slate-900 tracking-tight">Create Assembly App</h3>
              </div>
              <p className="text-slate-550 text-xs mb-6">Initialize a structured workspace to start generating modular components with system agents.</p>

              <form onSubmit={handleCreateProject} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">Project Name</label>
                  <input
                    type="text"
                    required
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="e.g., Slack Analytics Bot"
                    className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-400 outline-none focus:bg-white transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">Objective / Purpose</label>
                  <textarea
                    required
                    rows={3}
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                    placeholder="Describe what the multi-agent pipeline is building..."
                    className="w-full text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-400 outline-none focus:bg-white transition-all resize-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">Primary Context Router</label>
                    <select
                      value={newModel}
                      onChange={(e) => setNewModel(e.target.value)}
                      className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-400 outline-none focus:bg-white transition-all font-sans"
                    >
                      <option value="Auto-Select (Smart Router)">Auto-Select (Smart Router)</option>
                      <optgroup label="Direct Cloud Free-Tier">
                        <option value="DeepSeek R1">DeepSeek R1</option>
                        <option value="Llama 3.3 70B">Llama 3.3 70B (Meta AI)</option>
                        <option value="Llama 3.1 8B">Llama 3.1 8B (Meta AI)</option>
                        <option value="Gemma 2 9B">Gemma 2 9B (Google AI)</option>
                        <option value="Qwen 2.5 72B">Qwen 2.5 72B (Alibaba Group)</option>
                        <option value="Qwen 2.5 Coder 32B">Qwen 2.5 Coder 32B (Alibaba Group)</option>
                        <option value="Mistral 7B">Mistral 7B (Mistral AI)</option>
                        <option value="Phi 3 Medium">Phi 3 Medium (Microsoft Corp)</option>
                        <option value="OpenChat 3.5">OpenChat 3.5 (TSINGHUA)</option>
                        <option value="Hermes 3 8B">Hermes 3 8B (Nous Research)</option>
                        <option value="Gemini 2.5 Flash">Gemini 2.5 Flash (Google AI)</option>
                        <option value="Gemini 1.5 Flash">Gemini 1.5 Flash (Google AI)</option>
                      </optgroup>
                      <optgroup label="Groq LPU Instant Accelerations">
                        <option value="Llama 3 8B (Groq)">Llama 3 8B (Groq)</option>
                        <option value="Llama 3.3 70B (Groq)">Llama 3.3 70B (Groq)</option>
                        <option value="Llama 3.1 8B (Groq)">Llama 3.1 8B (Groq)</option>
                        <option value="Mixtral 8x7B (Groq)">Mixtral 8x7B (Groq)</option>
                      </optgroup>
                      <optgroup label="NVIDIA NIM GPU Accelerations">
                        <option value="Llama 3.1 Nemotron 70B (Nvidia)">Llama 3.1 Nemotron 70B (Nvidia)</option>
                        <option value="Llama 3.3 70B (Nvidia)">Llama 3.3 70B (Nvidia)</option>
                        <option value="Mixtral 8x22B (Nvidia)">Mixtral 8x22B (Nvidia)</option>
                      </optgroup>
                      {customModels.length > 0 && (
                        <optgroup label="Custom Integrated Gateways">
                          {customModels.map((cm, idx) => (
                            <option key={`c-opt-${idx}`} value={cm.name}>
                              {cm.name}
                            </option>
                          ))}
                        </optgroup>
                      )}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">Stack Tags (Comma separated)</label>
                    <input
                      type="text"
                      value={newTags}
                      onChange={(e) => setNewTags(e.target.value)}
                      placeholder="Node, React, API"
                      className="w-full text-xs px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-400 outline-none focus:bg-white transition-all"
                    />
                  </div>
                </div>

                <div className="pt-4.5 flex items-center justify-end gap-2.5 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsCreating(false)}
                    className="px-4 py-2 border border-slate-250 hover:bg-slate-50 text-slate-500 text-xs font-bold rounded-xl cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl cursor-pointer shadow-3xs"
                  >
                    Initialize Assembly
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
