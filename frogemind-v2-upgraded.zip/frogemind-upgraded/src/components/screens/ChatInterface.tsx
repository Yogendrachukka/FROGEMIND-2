/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Sparkles,
  Send,
  Mic,
  Paperclip,
  Image as ImageIcon,
  Columns,
  Copy,
  Check,
  Activity,
  Database,
  Terminal,
  VolumeX,
  Volume2,
  Radio,
  FileText,
  User,
  Bot,
  Share2,
  Zap,
  Code2,
  MessageCircle,
  X,
  ChevronDown
} from 'lucide-react';
import { ChatMessage, LLMModel } from '../../types';

interface ChatInterfaceProps {
  modelsList: LLMModel[];
  activeModel: LLMModel;
  onSelectModel: (model: LLMModel) => void;
  memoriesCount: number;
  systemBroadcast?: string | null;
}

// ── Smart Router: improved intent-based model selection ────────────────────────
function smartRoute(message: string, attachments: any[]): { model: string; reason: string; category: string } {
  const msg = message.toLowerCase().trim();

  // Vision / multimodal
  if (attachments.some((a: any) => a.type === 'image')) {
    return { model: 'Gemini 2.5 Flash', reason: 'Image detected → multimodal model', category: 'vision' };
  }

  // Code / dev patterns — Qwen Coder
  const codePatterns = /\b(function|const|let|var|import|export|class|interface|type|enum|return|async|await|promise|api|npm|yarn|pnpm|typescript|javascript|python|rust|golang|java|php|html|css|scss|json|yaml|sql|bash|shell|script|debug|error|bug|fix|refactor|component|hook|useState|useEffect|fetch|axios|express|react|nextjs|vue|angular|docker|git|github|deploy|build|compile|webpack|vite|tailwind|database|query|migration|algorithm|data structure|leetcode|hackerrank)\b/i;
  if (codePatterns.test(msg) || msg.includes('```') || msg.includes('code') || msg.includes('write a') && /program|script|function|class/.test(msg)) {
    return { model: 'Qwen 2.5 Coder 32B', reason: 'Code/dev query → Qwen Coder 32B', category: 'coding' };
  }

  // Deep reasoning / math / analysis — DeepSeek R1
  const reasoningPatterns = /\b(math|calcul|integral|derivative|equation|proof|theorem|formula|logic|reasoning|step.by.step|analysis|explain why|how does|what causes|compare|contrast|evaluate|assess|critique|pros and cons|trade.?off|strategy|philosophy|science|physics|chemistry|biology|research|study|paper|hypothesis|experiment)\b/i;
  if (reasoningPatterns.test(msg) || msg.length > 300) {
    return { model: 'DeepSeek R1', reason: 'Deep reasoning query → DeepSeek R1', category: 'reasoning' };
  }

  // Multilingual / translation / writing — Qwen 2.5 72B
  const multilingualPatterns = /\b(translate|translation|spanish|french|german|chinese|japanese|korean|arabic|hindi|portuguese|italian|multilingual|essay|article|blog|write about|summarize|summary|report|document|draft|creative writing|story|poem|narrative)\b/i;
  if (multilingualPatterns.test(msg)) {
    return { model: 'Qwen 2.5 72B', reason: 'Writing/multilingual query → Qwen 2.5 72B', category: 'writing' };
  }

  // Quick greetings / simple chat — fast model
  const quickPatterns = /^(hi|hello|hey|yo|sup|what|who|where|when|how are|thanks|ok|sure|yes|no|please|help me|can you)[^.!?]*[.!?]?$/i;
  if (quickPatterns.test(msg.trim()) || msg.length < 40) {
    return { model: 'Gemini 2.5 Flash', reason: 'Short/casual query → Gemini 2.5 Flash', category: 'chat' };
  }

  // Normal conversation — Llama 3.3
  const conversationalPatterns = /\b(tell me|what is|what are|explain|describe|give me|show me|list|examples|ideas|suggest|recommend|opinion|think|feel|believe|prefer|favorite|best|worst|top|popular|latest|news|update|recent)\b/i;
  if (conversationalPatterns.test(msg)) {
    return { model: 'Llama 3.3 70B', reason: 'General conversation → Llama 3.3 70B', category: 'conversation' };
  }

  // Default — balanced general model
  return { model: 'Llama 3.3 70B', reason: 'General query → Llama 3.3 70B', category: 'general' };
}

// ── Markdown renderer (minimal, no extra deps) ─────────────────────────────────
function renderMarkdown(text: string): React.ReactNode {
  if (!text) return null;

  // Split on code blocks first
  const parts = text.split(/(```[\s\S]*?```)/g);

  return parts.map((part, i) => {
    if (part.startsWith('```')) {
      const lines = part.slice(3, -3).split('\n');
      const lang = lines[0]?.trim() || 'code';
      const code = lines.slice(1).join('\n').trimEnd();
      return (
        <div key={i} className="my-3 rounded-xl overflow-hidden border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between px-4 py-2 bg-slate-800 border-b border-slate-700">
            <div className="flex items-center gap-2">
              <Code2 className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">{lang}</span>
            </div>
            <CopyCodeBtn code={code} />
          </div>
          <pre className="bg-slate-900 p-4 overflow-x-auto text-[12px] text-slate-200 leading-relaxed font-mono m-0">
            <code>{code}</code>
          </pre>
        </div>
      );
    }

    // Process inline markdown
    const lines = part.split('\n');
    const elements: React.ReactNode[] = [];
    let listBuffer: string[] = [];
    let listType: 'ul' | 'ol' | null = null;

    const flushList = () => {
      if (listBuffer.length === 0) return;
      const items = listBuffer.map((li, idx) => (
        <li key={idx} className="text-slate-600 text-[13px] leading-relaxed">{inlineFormat(li)}</li>
      ));
      elements.push(
        listType === 'ul'
          ? <ul key={elements.length} className="list-disc pl-5 space-y-1 my-1.5">{items}</ul>
          : <ol key={elements.length} className="list-decimal pl-5 space-y-1 my-1.5">{items}</ol>
      );
      listBuffer = [];
      listType = null;
    };

    lines.forEach((line, idx) => {
      // Headings
      if (line.startsWith('### ')) {
        flushList();
        elements.push(<h3 key={idx} className="font-bold text-slate-800 text-sm mt-3 mb-1 font-display">{line.slice(4)}</h3>);
        return;
      }
      if (line.startsWith('## ')) {
        flushList();
        elements.push(<h2 key={idx} className="font-bold text-slate-900 text-sm mt-4 mb-1.5 font-display">{line.slice(3)}</h2>);
        return;
      }
      if (line.startsWith('# ')) {
        flushList();
        elements.push(<h1 key={idx} className="font-bold text-slate-900 text-base mt-4 mb-2 font-display">{line.slice(2)}</h1>);
        return;
      }

      // Horizontal rule
      if (/^[-*_]{3,}$/.test(line.trim())) {
        flushList();
        elements.push(<hr key={idx} className="border-slate-200 my-3" />);
        return;
      }

      // Blockquote
      if (line.startsWith('> ')) {
        flushList();
        elements.push(
          <blockquote key={idx} className="border-l-2 border-slate-300 pl-3 text-slate-500 italic text-[13px] my-1.5">
            {inlineFormat(line.slice(2))}
          </blockquote>
        );
        return;
      }

      // Unordered list
      if (/^[-*+] /.test(line)) {
        if (listType !== 'ul') { flushList(); listType = 'ul'; }
        listBuffer.push(line.slice(2));
        return;
      }

      // Ordered list
      if (/^\d+\. /.test(line)) {
        if (listType !== 'ol') { flushList(); listType = 'ol'; }
        listBuffer.push(line.replace(/^\d+\. /, ''));
        return;
      }

      flushList();

      if (line.trim() === '') {
        elements.push(<div key={idx} className="h-1.5" />);
        return;
      }

      elements.push(
        <p key={idx} className="text-slate-700 text-[13px] leading-relaxed">
          {inlineFormat(line)}
        </p>
      );
    });

    flushList();
    return <div key={i}>{elements}</div>;
  });
}

// Helper: copy button for code blocks
function CopyCodeBtn({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
      className="flex items-center gap-1 text-[10px] font-mono text-slate-400 hover:text-white transition-colors cursor-pointer"
    >
      {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
      {copied ? 'Copied' : 'Copy'}
    </button>
  );
}

// Helper: inline markdown formatting
function inlineFormat(text: string): React.ReactNode {
  if (!text.includes('**') && !text.includes('*') && !text.includes('`') && !text.includes('[')) {
    return text;
  }

  const parts: React.ReactNode[] = [];
  let remaining = text;
  let idx = 0;

  while (remaining.length > 0) {
    // Bold
    const boldMatch = remaining.match(/\*\*(.+?)\*\*/);
    // Italic
    const italicMatch = remaining.match(/\*(.+?)\*/);
    // Inline code
    const codeMatch = remaining.match(/`([^`]+)`/);
    // Link
    const linkMatch = remaining.match(/\[(.+?)\]\((https?:\/\/[^\)]+)\)/);

    const candidates = [boldMatch, italicMatch, codeMatch, linkMatch]
      .filter(Boolean)
      .map(m => ({ match: m!, start: m!.index! }));

    if (candidates.length === 0) {
      parts.push(<span key={idx++}>{remaining}</span>);
      break;
    }

    const first = candidates.reduce((a, b) => a.start <= b.start ? a : b);
    const { match, start } = first;

    if (start > 0) {
      parts.push(<span key={idx++}>{remaining.slice(0, start)}</span>);
    }

    if (match === boldMatch) {
      parts.push(<strong key={idx++} className="font-semibold text-slate-800">{match[1]}</strong>);
    } else if (match === italicMatch) {
      parts.push(<em key={idx++} className="italic text-slate-600">{match[1]}</em>);
    } else if (match === codeMatch) {
      parts.push(<code key={idx++} className="font-mono text-[11px] bg-slate-100 text-indigo-600 px-1.5 py-0.5 rounded border border-slate-200">{match[1]}</code>);
    } else if (match === linkMatch) {
      parts.push(<a key={idx++} href={match[2]} target="_blank" rel="noopener noreferrer" className="text-indigo-600 underline underline-offset-2 hover:text-indigo-800">{match[1]}</a>);
    }

    remaining = remaining.slice(start + match[0].length);
  }

  return <>{parts}</>;
}

// ── Category badge map ─────────────────────────────────────────────────────────
const CATEGORY_CONFIG: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  coding:       { label: 'Code',        color: 'bg-violet-50 text-violet-700 border-violet-200',   icon: <Code2 className="w-3 h-3" /> },
  reasoning:    { label: 'Reasoning',   color: 'bg-amber-50 text-amber-700 border-amber-200',      icon: <Activity className="w-3 h-3" /> },
  writing:      { label: 'Writing',     color: 'bg-sky-50 text-sky-700 border-sky-200',            icon: <FileText className="w-3 h-3" /> },
  vision:       { label: 'Vision',      color: 'bg-pink-50 text-pink-700 border-pink-200',         icon: <ImageIcon className="w-3 h-3" /> },
  chat:         { label: 'Chat',        color: 'bg-emerald-50 text-emerald-700 border-emerald-200', icon: <MessageCircle className="w-3 h-3" /> },
  conversation: { label: 'Conversation',color: 'bg-blue-50 text-blue-700 border-blue-200',         icon: <MessageCircle className="w-3 h-3" /> },
  general:      { label: 'General',     color: 'bg-slate-50 text-slate-600 border-slate-200',      icon: <Sparkles className="w-3 h-3" /> },
};

// ── Main Component ─────────────────────────────────────────────────────────────
export default function ChatInterface({
  modelsList,
  activeModel,
  onSelectModel,
  memoriesCount,
  systemBroadcast
}: ChatInterfaceProps) {

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-1',
      sender: 'ai',
      content: '👋 Welcome to **FrogeMind**!\n\nI\'m your intelligent multi-model assistant. Here\'s what I can do:\n\n- **Auto-Router** picks the best AI for your query automatically\n- **Coding** tasks go to *Qwen 2.5 Coder 32B* for best results\n- **Conversations** use *Llama 3.3 70B* for natural dialogue\n- **Deep reasoning** routes to *DeepSeek R1*\n- **Quick chats** use *Gemini 2.5 Flash* for fast replies\n\nType anything to get started!',
      modelUsed: 'FrogeMind',
      timestamp: new Date().toISOString()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isSplitScreen, setIsSplitScreen] = useState(false);
  const [modelB, setModelB] = useState<LLMModel>(modelsList[1] || modelsList[0]);
  const [messagesModelB, setMessagesModelB] = useState<ChatMessage[]>([
    {
      id: 'welcome-b',
      sender: 'ai',
      content: 'Second model comparison window ready.\n\nType a message below to compare responses side-by-side in real-time.',
      modelUsed: modelsList[1]?.name || 'Llama 3.3 70B',
      timestamp: new Date().toISOString()
    }
  ]);

  const [isMemoryEnabled, setIsMemoryEnabled] = useState(true);
  const [isStreaming, setIsStreaming] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [sharedId, setSharedId] = useState<string | null>(null);
  const [isMicActive, setIsMicActive] = useState(false);
  const [audioPlaybackId, setAudioPlaybackId] = useState<string | null>(null);
  const [micStateMsg, setMicStateMsg] = useState<string | null>(null);
  const [attachedFiles, setAttachedFiles] = useState<{ name: string; type: 'image' | 'file'; url?: string }[]>([]);
  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [lastRouteInfo, setLastRouteInfo] = useState<{ model: string; reason: string; category: string } | null>(null);
  const [showModelDropdown, setShowModelDropdown] = useState(false);

  const chatBottomRef = useRef<HTMLDivElement>(null);
  const chatBottomBRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);
  const isRecordingRef = useRef(false);
  const mediaRecorderRef = useRef<any>(null);
  const audioChunksRef = useRef<any[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    chatBottomBRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messagesModelB]);

  useEffect(() => {
    return () => {
      if (recognitionRef.current) { try { recognitionRef.current.abort(); } catch (e) {} }
    };
  }, []);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 160) + 'px';
    }
  }, [inputText]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDragOver = (e: React.DragEvent) => { e.preventDefault(); setIsDraggingOver(true); };
  const handleDragLeave = (e: React.DragEvent) => { e.preventDefault(); setIsDraggingOver(false); };
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(false);
    const files = e.dataTransfer.files;
    if (!files || files.length === 0) return;
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();
      const fileType = file.type.startsWith('image/') ? 'image' as const : 'file' as const;
      reader.onload = (event) => {
        setAttachedFiles(prev => [...prev, { name: file.name, type: fileType, url: event.target?.result as string }]);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, intendedType: 'image' | 'file') => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const reader = new FileReader();
      const fileType = intendedType === 'image' || file.type.startsWith('image/') ? 'image' as const : 'file' as const;
      reader.onload = (event) => {
        setAttachedFiles(prev => [...prev, { name: file.name, type: fileType, url: event.target?.result as string }]);
      };
      reader.readAsDataURL(file);
    }
    e.target.value = '';
  };

  const fetchModelResponse = async (modelName: string, activeMsg: string, isModelB: boolean) => {
    try {
      const relevantHistory = isModelB ? messagesModelB.slice(-8) : messages.slice(-8);
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: activeMsg,
          model: modelName,
          history: relevantHistory,
          memoryActive: isMemoryEnabled,
          attachments: attachedFiles
        })
      });
      if (!response.ok) throw new Error('Server error');
      const data = await response.json();
      return { content: data.content || '', modelUsed: data.modelUsed || modelName };
    } catch (err) {
      return {
        content: getModelResponseMock(modelName, activeMsg, isMemoryEnabled, attachedFiles),
        modelUsed: modelName
      };
    }
  };

  const streamText = (
    text: string,
    msgId: string,
    modelUsed: string,
    setMsgs: React.Dispatch<React.SetStateAction<ChatMessage[]>>,
    onDone?: () => void
  ) => {
    let idx = 0;
    const interval = setInterval(() => {
      idx += Math.ceil(Math.random() * 10) + 5;
      if (idx >= text.length) {
        clearInterval(interval);
        setMsgs(prev => prev.map(m => m.id === msgId ? { ...m, content: text, isStreaming: false, modelUsed } : m));
        if (onDone) onDone();
      } else {
        setMsgs(prev => prev.map(m => m.id === msgId ? { ...m, content: text.slice(0, idx), modelUsed } : m));
      }
    }, 20);
  };

  const sendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() && attachedFiles.length === 0) return;
    if (isStreaming) return;

    const userMsgContent = inputText.trim();
    const currentAttachments = [...attachedFiles];
    setInputText('');
    setAttachedFiles([]);

    // Smart routing for auto-select
    let resolvedModelName = activeModel.name;
    let routeInfo: { model: string; reason: string; category: string } | null = null;
    if (activeModel.name.toLowerCase().includes('auto')) {
      routeInfo = smartRoute(userMsgContent, currentAttachments);
      resolvedModelName = routeInfo.model;
      setLastRouteInfo(routeInfo);
    } else {
      setLastRouteInfo(null);
    }

    const newUserMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      content: userMsgContent,
      timestamp: new Date().toISOString(),
      attachments: currentAttachments
    };

    setMessages(prev => [...prev, newUserMsg]);
    if (isSplitScreen) setMessagesModelB(prev => [...prev, newUserMsg]);
    setIsStreaming(true);

    // Model A
    (async () => {
      const result = await fetchModelResponse(resolvedModelName, userMsgContent, false);
      const aiId = `ai-a-${Date.now()}`;
      const aiMsg: ChatMessage = {
        id: aiId, sender: 'ai', content: '', modelUsed: result.modelUsed,
        timestamp: new Date().toISOString(), isStreaming: true
      };
      setMessages(prev => [...prev, aiMsg]);
      streamText(result.content, aiId, result.modelUsed, setMessages, () => {
        if (!isSplitScreen) setIsStreaming(false);
      });
    })();

    // Model B (split screen)
    if (isSplitScreen) {
      (async () => {
        const result = await fetchModelResponse(modelB.name, userMsgContent, true);
        const aiId = `ai-b-${Date.now()}`;
        const aiMsg: ChatMessage = {
          id: aiId, sender: 'ai', content: '', modelUsed: result.modelUsed,
          timestamp: new Date().toISOString(), isStreaming: true
        };
        setMessagesModelB(prev => [...prev, aiMsg]);
        streamText(result.content, aiId, result.modelUsed, setMessagesModelB, () => setIsStreaming(false));
      })();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  // Voice input
  const toggleMicListening = async () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (isMicActive || isRecordingRef.current) {
      if (recognitionRef.current) { try { recognitionRef.current.stop(); } catch (e) {} recognitionRef.current = null; }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        try { mediaRecorderRef.current.stop(); } catch (e) {}
      }
      setIsMicActive(false);
      isRecordingRef.current = false;
      return;
    }

    if (SpeechRecognition) {
      try {
        const rec = new SpeechRecognition();
        rec.continuous = true;
        rec.interimResults = true;
        rec.lang = 'en-US';
        let finalTranscript = '';
        rec.onstart = () => { setIsMicActive(true); isRecordingRef.current = true; setMicStateMsg('Listening...'); };
        rec.onresult = (event: any) => {
          let interim = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            if (event.results[i].isFinal) finalTranscript += event.results[i][0].transcript;
            else interim += event.results[i][0].transcript;
          }
          const text = finalTranscript || interim;
          if (text) { setInputText(text); setMicStateMsg(`"${text.substring(0, 30)}${text.length > 30 ? '...' : ''}"`); }
        };
        rec.onerror = (event: any) => {
          if (event.error !== 'aborted') setMicStateMsg(`Error: ${event.error}`);
          setIsMicActive(false); isRecordingRef.current = false; recognitionRef.current = null;
        };
        rec.onend = () => { setIsMicActive(false); isRecordingRef.current = false; recognitionRef.current = null; setTimeout(() => setMicStateMsg(null), 2000); };
        recognitionRef.current = rec;
        rec.start();
        return;
      } catch (err) {}
    }

    // Fallback mock
    setIsMicActive(true);
    setMicStateMsg('Simulating voice...');
    setTimeout(() => {
      setInputText('Tell me about the latest advancements in AI reasoning models.');
      setIsMicActive(false);
      setMicStateMsg(null);
    }, 1500);
  };

  const isAutoMode = activeModel.name.toLowerCase().includes('auto');

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className="flex-1 flex flex-col min-h-0 bg-white text-slate-800 font-sans select-none relative"
    >
      {/* Drag overlay */}
      <AnimatePresence>
        {isDraggingOver && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="absolute inset-0 bg-indigo-600/85 backdrop-blur-sm z-50 flex items-center justify-center text-white pointer-events-none"
          >
            <div className="flex flex-col items-center gap-3 text-center">
              <div className="w-14 h-14 rounded-2xl bg-white/15 border border-white/25 flex items-center justify-center">
                <Paperclip className="w-7 h-7 text-white" />
              </div>
              <p className="text-sm font-semibold">Drop files to attach</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* System broadcast */}
      <AnimatePresence>
        {systemBroadcast && (
          <motion.div
            initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="bg-amber-50 border-b border-amber-100 px-5 py-2.5 flex items-center gap-2.5 text-xs text-amber-800 shrink-0"
          >
            <Radio className="w-3.5 h-3.5 text-amber-600 animate-pulse shrink-0" />
            <span className="font-mono font-bold text-amber-600 uppercase text-[9px] tracking-widest shrink-0">Broadcast</span>
            <span className="font-medium truncate">{systemBroadcast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="px-5 py-3 border-b border-slate-100 bg-white/95 backdrop-blur-sm flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          {/* Model A Selector */}
          <div className="relative">
            <button
              onClick={() => setShowModelDropdown(!showModelDropdown)}
              className="flex items-center gap-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
            >
              <Bot className="w-3.5 h-3.5 text-indigo-500" />
              <span className="max-w-[150px] truncate">{activeModel.name}</span>
              {isAutoMode && <Zap className="w-3 h-3 text-amber-500" />}
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>
            {showModelDropdown && (
              <div className="absolute top-full left-0 mt-1.5 w-64 bg-white border border-slate-200 rounded-2xl shadow-xl z-30 py-1.5 max-h-80 overflow-y-auto">
                {modelsList.map(m => (
                  <button
                    key={m.id}
                    onClick={() => { onSelectModel(m); setShowModelDropdown(false); }}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 text-xs text-left transition-colors cursor-pointer ${
                      activeModel.id === m.id ? 'bg-indigo-50 text-indigo-700' : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${activeModel.id === m.id ? 'bg-indigo-500' : 'bg-slate-300'}`} />
                    <div className="min-w-0">
                      <div className="font-semibold truncate">{m.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono truncate">{m.provider}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {showModelDropdown && (
            <div className="fixed inset-0 z-20" onClick={() => setShowModelDropdown(false)} />
          )}

          {/* Split screen */}
          <button
            onClick={() => setIsSplitScreen(!isSplitScreen)}
            className={`flex items-center gap-1.5 text-xs font-semibold border rounded-xl px-3 py-2 transition-colors cursor-pointer ${
              isSplitScreen
                ? 'bg-indigo-50 text-indigo-600 border-indigo-200'
                : 'bg-white text-slate-500 border-slate-200 hover:text-slate-800 hover:border-slate-300'
            }`}
          >
            <Columns className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Compare</span>
          </button>
        </div>

        {/* Right controls */}
        <div className="flex items-center gap-2.5">
          {/* Smart router info */}
          {isAutoMode && lastRouteInfo && (
            <motion.div
              initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }}
              className={`hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[10px] font-mono font-semibold ${
                CATEGORY_CONFIG[lastRouteInfo.category]?.color || 'bg-slate-50 text-slate-600 border-slate-200'
              }`}
            >
              {CATEGORY_CONFIG[lastRouteInfo.category]?.icon}
              <span>{lastRouteInfo.model}</span>
            </motion.div>
          )}

          {/* Memory toggle */}
          <button
            onClick={() => setIsMemoryEnabled(!isMemoryEnabled)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-[10px] font-mono font-semibold transition-all cursor-pointer ${
              isMemoryEnabled
                ? 'bg-indigo-50 border-indigo-100 text-indigo-600'
                : 'bg-slate-50 border-slate-200 text-slate-400'
            }`}
          >
            <Database className="w-3 h-3" />
            <span className="hidden sm:inline">Memory {isMemoryEnabled ? 'ON' : 'OFF'}</span>
          </button>

          {/* Mic status */}
          {(isMicActive || micStateMsg) && (
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-indigo-600 bg-indigo-50 border border-indigo-100 px-2.5 py-1.5 rounded-xl">
              <span className={`w-1.5 h-1.5 rounded-full bg-indigo-500 ${isMicActive ? 'animate-ping' : ''}`} />
              <span>{micStateMsg || 'Mic active'}</span>
            </div>
          )}
        </div>
      </div>

      {/* Chat area */}
      <div className="flex-1 flex min-h-0 overflow-hidden">
        {/* Panel A */}
        <div className="flex-1 flex flex-col min-h-0 overflow-y-auto px-4 py-5 space-y-4">
          {messages.map((msg) => (
            <ChatMessageCard
              key={msg.id}
              msg={msg}
              copiedId={copiedId}
              onCopy={copyToClipboard}
              onPlay={(id) => setAudioPlaybackId(id)}
              activePlaybackId={audioPlaybackId}
              sharedId={sharedId}
              onShare={(id) => { setSharedId(id); setTimeout(() => setSharedId(null), 2000); }}
            />
          ))}

          {isStreaming && (
            <div className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-slate-50 border border-slate-100 max-w-xs">
              <div className="w-7 h-7 rounded-xl bg-slate-100 flex items-center justify-center shrink-0">
                <Bot className="w-3.5 h-3.5 text-slate-500" />
              </div>
              <div className="flex gap-1.5">
                <span className="w-2 h-2 rounded-full bg-slate-400 dot-1" />
                <span className="w-2 h-2 rounded-full bg-slate-400 dot-2" />
                <span className="w-2 h-2 rounded-full bg-slate-400 dot-3" />
              </div>
            </div>
          )}
          <div ref={chatBottomRef} />
        </div>

        {/* Panel B */}
        <AnimatePresence>
          {isSplitScreen && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: '48%', opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              className="flex flex-col min-h-0 border-l border-slate-100 bg-slate-50/30 overflow-hidden"
            >
              <div className="px-4 py-2.5 bg-white border-b border-slate-100 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-slate-400 font-bold">Model B</span>
                  <select
                    value={modelB.id}
                    onChange={(e) => { const f = modelsList.find(m => m.id === e.target.value); if (f) setModelB(f); }}
                    className="bg-transparent text-xs text-sky-600 outline-none border-none font-semibold cursor-pointer pr-2"
                  >
                    {modelsList.map(m => <option key={m.id} value={m.id} className="bg-white text-slate-700">{m.name}</option>)}
                  </select>
                </div>
                <button onClick={() => setIsSplitScreen(false)} className="p-1 hover:bg-slate-100 rounded-lg cursor-pointer">
                  <X className="w-3.5 h-3.5 text-slate-400" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto px-4 py-5 space-y-4">
                {messagesModelB.map((msg) => (
                  <ChatMessageCard
                    key={`b-${msg.id}`}
                    msg={msg}
                    copiedId={copiedId}
                    onCopy={copyToClipboard}
                    onPlay={(id) => setAudioPlaybackId(id)}
                    activePlaybackId={audioPlaybackId}
                    sharedId={sharedId}
                    onShare={(id) => { setSharedId(id); setTimeout(() => setSharedId(null), 2000); }}
                  />
                ))}
                <div ref={chatBottomBRef} />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Input bar */}
      <div className="px-4 py-4 border-t border-slate-100 bg-white shrink-0">
        <div className="max-w-4xl mx-auto">
          {/* Attachments */}
          {attachedFiles.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-2.5">
              {attachedFiles.map((f, idx) => (
                <div key={idx} className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 px-2.5 py-1.5 rounded-lg text-[11px] font-mono text-slate-600">
                  {f.type === 'image' && f.url
                    ? <img src={f.url} alt="" className="w-5 h-5 rounded object-cover" />
                    : f.type === 'image' ? <ImageIcon className="w-3.5 h-3.5 text-violet-500" /> : <FileText className="w-3.5 h-3.5 text-amber-500" />
                  }
                  <span className="max-w-[120px] truncate">{f.name}</span>
                  <button type="button" onClick={() => setAttachedFiles(prev => prev.filter((_, i) => i !== idx))} className="ml-0.5 hover:text-red-500 cursor-pointer">
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Input row */}
          <div className={`flex items-end gap-2 rounded-2xl border p-2 transition-all input-ring ${
            isMicActive
              ? 'border-indigo-400 bg-indigo-50/40'
              : 'border-slate-200 bg-slate-50 focus-within:bg-white focus-within:border-indigo-300'
          }`}>
            {/* Attach buttons */}
            <div className="flex items-center gap-0.5 pb-1.5">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-2 hover:bg-slate-200/60 rounded-xl text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                title="Attach file"
              >
                <Paperclip className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => imageInputRef.current?.click()}
                className="p-2 hover:bg-slate-200/60 rounded-xl text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                title="Attach image"
              >
                <ImageIcon className="w-4 h-4" />
              </button>
            </div>

            {/* Textarea */}
            <textarea
              ref={textareaRef}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              rows={1}
              placeholder={
                isMicActive
                  ? 'Listening... speak now'
                  : isAutoMode
                  ? 'Auto-Router will pick the best model...'
                  : `Message ${activeModel.name}...`
              }
              className="flex-1 bg-transparent px-2 py-2 text-sm text-slate-800 outline-none resize-none placeholder:text-slate-400 font-sans leading-relaxed"
              style={{ minHeight: '36px', maxHeight: '160px' }}
            />

            {/* Action buttons */}
            <div className="flex items-center gap-1.5 pb-1.5">
              <button
                type="button"
                onClick={toggleMicListening}
                className={`p-2 rounded-xl transition-all cursor-pointer ${
                  isMicActive
                    ? 'bg-rose-500 text-white shadow-sm'
                    : 'hover:bg-slate-200/60 text-slate-400 hover:text-slate-700'
                }`}
              >
                <Mic className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => sendMessage()}
                disabled={!inputText.trim() && attachedFiles.length === 0}
                className="p-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-200 disabled:cursor-not-allowed text-white rounded-xl transition-all active:scale-95 cursor-pointer shadow-sm"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>

          <p className="text-center text-[10px] font-mono text-slate-400 mt-2 tracking-wider">
            Enter to send · Shift+Enter for new line · Memories {isMemoryEnabled ? 'active' : 'off'}
          </p>
        </div>

        {/* Hidden inputs */}
        <input type="file" ref={fileInputRef} onChange={(e) => handleFileChange(e, 'file')} className="hidden" multiple />
        <input type="file" ref={imageInputRef} accept="image/*" onChange={(e) => handleFileChange(e, 'image')} className="hidden" multiple />
      </div>
    </div>
  );
}

// ── Message Card ───────────────────────────────────────────────────────────────
interface ChatMessageCardProps {
  msg: ChatMessage;
  copiedId: string | null;
  onCopy: (text: string, id: string) => void;
  onPlay: (id: string | null) => void;
  activePlaybackId: string | null;
  sharedId: string | null;
  onShare: (id: string) => void;
}

function ChatMessageCard({ msg, copiedId, onCopy, onPlay, activePlaybackId, sharedId, onShare }: ChatMessageCardProps) {
  const isUser = msg.sender === 'user';
  const isPlaying = activePlaybackId === msg.id;
  const isAutoRouted = msg.modelUsed?.includes('➔');

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className={`flex gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
    >
      {/* Avatar */}
      <div className={`w-8 h-8 rounded-xl shrink-0 flex items-center justify-center mt-0.5 ${
        isUser ? 'bg-indigo-100 text-indigo-600' : 'bg-slate-100 text-slate-600'
      }`}>
        {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
      </div>

      {/* Bubble */}
      <div className={`max-w-[80%] flex flex-col gap-1.5 ${isUser ? 'items-end' : 'items-start'}`}>
        {/* Model label */}
        <div className={`flex items-center gap-2 px-0.5 ${isUser ? 'flex-row-reverse' : ''}`}>
          {isUser ? (
            <span className="text-[10px] font-mono text-slate-400 font-semibold">You</span>
          ) : isAutoRouted ? (
            <span className="inline-flex items-center gap-1.5 bg-indigo-50 border border-indigo-200 text-indigo-700 px-2 py-0.5 rounded-lg text-[9px] font-mono font-bold">
              <Zap className="w-2.5 h-2.5" />
              {msg.modelUsed}
            </span>
          ) : (
            <span className="text-[10px] font-mono text-slate-400 font-semibold">
              {msg.modelUsed || 'AI'}
            </span>
          )}
          <span className="text-[9px] font-mono text-slate-300">
            {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>

        {/* Message content */}
        <div className={`rounded-2xl px-4 py-3 text-sm leading-relaxed ${
          isUser
            ? 'bg-indigo-600 text-white rounded-tr-sm'
            : 'bg-white border border-slate-100 shadow-sm text-slate-700 rounded-tl-sm'
        }`}>
          {isUser ? (
            <div className="text-[13px] leading-relaxed whitespace-pre-wrap text-white/95 select-text">
              {msg.content}
            </div>
          ) : (
            <div className="select-text">
              {msg.isStreaming && msg.content.length === 0 ? (
                <div className="flex gap-1.5 py-1">
                  <span className="w-2 h-2 rounded-full bg-slate-300 dot-1" />
                  <span className="w-2 h-2 rounded-full bg-slate-300 dot-2" />
                  <span className="w-2 h-2 rounded-full bg-slate-300 dot-3" />
                </div>
              ) : (
                renderMarkdown(msg.content)
              )}
              {msg.isStreaming && msg.content.length > 0 && (
                <span className="inline-block w-1 h-3.5 bg-indigo-400 rounded-sm animate-pulse ml-0.5 align-middle" />
              )}
            </div>
          )}

          {/* Attachments */}
          {msg.attachments && msg.attachments.length > 0 && (
            <div className={`flex flex-wrap gap-2 mt-2.5 ${msg.isStreaming ? '' : 'pt-2.5 border-t border-slate-100'}`}>
              {msg.attachments.map((at, i) => (
                <div key={i}>
                  {at.type === 'image' && at.url ? (
                    <img src={at.url} alt={at.name} className="max-w-[180px] max-h-[120px] rounded-xl object-cover border border-white/30" />
                  ) : (
                    <div className="flex items-center gap-1.5 bg-white/20 px-2.5 py-1.5 rounded-lg text-[11px] font-mono">
                      <FileText className="w-3 h-3" />
                      <span>{at.name}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Actions (AI only) */}
        {!isUser && !msg.isStreaming && (
          <div className="flex items-center gap-3 px-1 text-[10px] font-mono text-slate-400">
            <button
              onClick={() => onCopy(msg.content, msg.id)}
              className="flex items-center gap-1 hover:text-slate-700 cursor-pointer transition-colors"
            >
              {copiedId === msg.id ? (
                <><Check className="w-3 h-3 text-emerald-500" /><span className="text-emerald-600">Copied</span></>
              ) : (
                <><Copy className="w-3 h-3" /><span>Copy</span></>
              )}
            </button>
            <button
              onClick={() => onPlay(isPlaying ? null : msg.id)}
              className="flex items-center gap-1 hover:text-indigo-600 cursor-pointer transition-colors"
            >
              {isPlaying ? (
                <><Volume2 className="w-3 h-3 text-indigo-500" /><span className="text-indigo-600">Playing</span></>
              ) : (
                <><VolumeX className="w-3 h-3" /><span>Listen</span></>
              )}
            </button>
            <button
              onClick={() => onShare(msg.id)}
              className="flex items-center gap-1 hover:text-indigo-600 cursor-pointer transition-colors"
            >
              {sharedId === msg.id ? (
                <><Check className="w-3 h-3 text-indigo-500" /><span className="text-indigo-600">Copied!</span></>
              ) : (
                <><Share2 className="w-3 h-3" /><span>Share</span></>
              )}
            </button>
          </div>
        )}
      </div>
    </motion.div>
  );
}

// ── Mock responses (improved, per-model) ──────────────────────────────────────
function getModelResponseMock(model: string, query: string, memoryActive: boolean, attachments?: any[]): string {
  const q = query.toLowerCase();
  const memNote = memoryActive ? '*[Memory context active]*\n\n' : '';

  if (attachments && attachments.some((a: any) => a.type === 'image')) {
    return `${memNote}I can see the attached image(s). Here's my analysis:\n\nThe visual content appears to show relevant details that I've processed. For a full analysis with live vision capability, please ensure a **Gemini API key** is configured in your \`.env\` file.\n\n**To enable live responses:**\n\`\`\`bash\n# .env\nGEMINI_API_KEY=your_key_here\nOPENROUTER_API_KEY=your_key_here\n\`\`\``;
  }

  const codeQ = /\b(function|const|let|class|code|script|api|bug|fix|build|deploy|typescript|python|javascript|sql|html|css)\b/i.test(q);
  if (codeQ || model.toLowerCase().includes('coder')) {
    return `${memNote}Here's a clean implementation for your request:\n\n\`\`\`typescript\n// ${query.substring(0, 40)}\ninterface Config {\n  id: string;\n  enabled: boolean;\n  options?: Record<string, unknown>;\n}\n\nexport async function processRequest(\n  config: Config,\n  payload: unknown\n): Promise<{ success: boolean; data?: unknown }> {\n  if (!config.enabled) {\n    return { success: false };\n  }\n  \n  try {\n    // Process payload with config\n    const result = await handlePayload(payload, config.options);\n    return { success: true, data: result };\n  } catch (error) {\n    console.error('Processing failed:', error);\n    throw error;\n  }\n}\n\`\`\`\n\n**Key points:**\n- Proper TypeScript typing with interfaces\n- Async/await error handling\n- Clean separation of concerns\n\nWant me to expand any part of this?`;
  }

  if (model.includes('DeepSeek')) {
    return `${memNote}Let me reason through this step by step:\n\n**Analysis of: "${query.substring(0, 60)}"**\n\n**Step 1 — Understanding the context**\nThe query relates to ${q.includes('why') ? 'causal reasoning' : 'conceptual analysis'}. Breaking this down systematically...\n\n**Step 2 — Core considerations**\n- Primary factor: logical consistency of the premise\n- Secondary factor: applicable frameworks or models\n- Edge cases: boundary conditions that affect the conclusion\n\n**Step 3 — Synthesis**\nBased on the above reasoning chain, the most supported conclusion is that careful, multi-step analysis yields better outcomes than intuitive first-pass responses.\n\n**Confidence:** High (based on reasoning chain quality)\n\nWould you like me to elaborate on any step?`;
  }

  if (model.includes('Gemini')) {
    return `${memNote}Great question! Here's a comprehensive response:\n\n${query} is a topic I can address with high confidence.\n\n**Key insights:**\n- This involves several interconnected concepts worth exploring\n- Modern approaches suggest a multi-faceted perspective\n- Practical applications span multiple domains\n\n**Summary:** The most effective approach combines theoretical understanding with practical application. I can provide more detail on any aspect — just ask!`;
  }

  if (model.includes('Qwen') && !model.includes('Coder')) {
    return `${memNote}Comprehensive response to your query:\n\n**"${query.substring(0, 60)}"**\n\nThis is a well-formed question that I can address thoroughly. Based on my knowledge:\n\n1. **Primary perspective** — The foundational understanding here involves recognizing the core components at play\n2. **Supporting evidence** — Multiple sources and frameworks converge on similar conclusions\n3. **Practical implications** — This knowledge directly applies to real-world scenarios\n\n*Note: For live responses with current information, connect your OpenRouter API key.*`;
  }

  return `${memNote}I've processed your message: *"${query.substring(0, 80)}${query.length > 80 ? '...' : ''}"*\n\nHere's my response using **${model}**:\n\nThis is a simulated response. To get real AI responses, configure your API keys in the \`.env\` file:\n\n\`\`\`bash\nOPENROUTER_API_KEY=your_key\nGEMINI_API_KEY=your_key\n\`\`\`\n\nOnce configured, all ${model.includes('Auto') ? 'auto-routed' : model} queries will return live results.`;
}
