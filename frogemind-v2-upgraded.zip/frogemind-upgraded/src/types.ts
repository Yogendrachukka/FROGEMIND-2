/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface LLMModel {
  id: string;
  name: string;
  provider: string;
  badge: 'Free' | 'Pro' | 'Enterprise' | 'Groq' | 'Nvidia';
  badgeColor: string;
  description: string;
  speed: number; // 1-5 scale
  quality: number; // 1-5 scale
  status: 'Cloud' | 'Local' | 'Offline';
  latency: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  content: string;
  modelUsed?: string;
  timestamp: string;
  isStreaming?: boolean;
  attachments?: {
    name: string;
    type: 'image' | 'file';
    url?: string;
  }[];
}

export interface StoredMemory {
  id: string;
  content: string;
  tags: string[];
  createdAt: string;
  strength: 'Core' | 'Retentive' | 'Fading';
}

export interface MarketplaceTool {
  id: string;
  name: string;
  description: string;
  category: 'Writing' | 'Coding' | 'Image generation' | 'Research' | 'Productivity' | 'Automation';
  badge: string;
  popularity: number;
  apiCost: string;
  iconName: string;
}

export interface AdminTelemetry {
  id: string;
  user: string;
  action: string;
  model: string;
  tokens: number;
  time: string;
  status: 'success' | 'warn' | 'error';
}

export interface ShapeSpec {
  type: 'cube' | 'sphere' | 'cylinder' | 'pyramid' | 'torus' | 'cone' | 'grid' | 'ring' | 'crystal';
  color: string;
  size: [number, number, number];
  position: [number, number, number];
  rotation: [number, number, number];
  opacity?: number;
}

export interface GeneratedAsset {
  id: string;
  name: string;
  description: string;
  category: string;
  modelUsed: string;
  price: string;
  status: 'Active' | 'Offline' | 'Draft';
  createdAt: string;
  colors: string[];
  shapes: ShapeSpec[];
  comment?: {
    user: string;
    avatar: string;
    text: string;
    time: string;
  };
}

export interface ProductItem {
  id: string;
  name: string;
  category: string;
  price: string;
  status: 'Active' | 'Offline';
  imagePlaceholderColor: string;
}

export interface CommentItem {
  id: string;
  user: string;
  avatar: string;
  targetProduct: string;
  time: string;
  text: string;
  sentiment?: 'positive' | 'neutral' | 'question';
}

export interface MetricCard {
  title: string;
  value: string;
  change: string;
  status: 'up' | 'down';
  labelText: string;
}
