/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Sidebar from './components/Sidebar';

// Firebase imports
import { auth } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';

// Modular Screen Imports
import LandingPage from './components/screens/LandingPage';
import AuthUI from './components/screens/AuthUI';
import ChatInterface from './components/screens/ChatInterface';
import ModelCatalog from './components/screens/ModelCatalog';
import MemoryVault from './components/screens/MemoryVault';
import ToolsMarketplace from './components/screens/ToolsMarketplace';
import AdminDashboard from './components/screens/AdminDashboard';
import SettingsPanel from './components/screens/SettingsPanel';
import Projects from './components/screens/Projects';
import Connectors from './components/screens/Connectors';

import { LLMModel, StoredMemory } from './types';

const INITIAL_MODELS: LLMModel[] = [
  { 
    id: 'm-auto', 
    name: 'Auto-Select (Smart Router)', 
    provider: 'System Intelligence', 
    description: 'Dynamically routes to the best LLM based on query type. Coding → Qwen Coder. Reasoning → DeepSeek R1. Chat → Llama 3.3. Vision → Gemini Flash.', 
    speed: 5, quality: 5, status: 'Cloud', latency: 'Dynamic', badge: 'Pro',
    badgeColor: 'text-indigo-600 font-bold shadow-xs bg-indigo-50/50 px-1.5 py-0.5 rounded-md'
  },
  { 
    id: 'm-1', name: 'DeepSeek R1', provider: 'DeepSeek Co', 
    description: 'Best for: deep reasoning, math proofs, step-by-step analysis, research, and complex logic chains. Think-before-answer architecture.',
    speed: 3, quality: 5, status: 'Cloud', latency: '1.4s (Reasoning)', badge: 'Free',
    badgeColor: 'text-emerald-600 font-semibold'
  },
  { 
    id: 'm-2', name: 'Llama 3.3 70B', provider: 'Meta AI', 
    description: 'Best for: natural conversation, general knowledge, summarization, and instruction-following. Balanced and highly capable.',
    speed: 4, quality: 5, status: 'Cloud', latency: '0.9s (Balanced)', badge: 'Free',
    badgeColor: 'text-emerald-600 font-semibold'
  },
  { 
    id: 'm-3', name: 'Llama 3.1 8B', provider: 'Meta AI', 
    description: 'Best for: quick lookups, simple tasks, low-latency pipelines. Very fast with good instruction accuracy.',
    speed: 5, quality: 4, status: 'Cloud', latency: '0.4s (Very Fast)', badge: 'Free',
    badgeColor: 'text-emerald-600 font-semibold'
  },
  { 
    id: 'm-4', name: 'Gemma 2 9B', provider: 'Google AI', 
    description: 'Best for: creative writing, contextual accuracy, fast general chat. Google open-weights model.',
    speed: 5, quality: 4, status: 'Cloud', latency: '0.3s (Extremely Fast)', badge: 'Free',
    badgeColor: 'text-emerald-600 font-semibold'
  },
  { 
    id: 'm-5', name: 'Qwen 2.5 72B', provider: 'Alibaba Group', 
    description: 'Best for: multilingual tasks, essay writing, translation, structured generation. Exceptional in non-English languages.',
    speed: 4, quality: 5, status: 'Cloud', latency: '1.0s (Strong)', badge: 'Free',
    badgeColor: 'text-emerald-600 font-semibold'
  },
  { 
    id: 'm-6', name: 'Qwen 2.5 Coder 32B', provider: 'Alibaba Group', 
    description: 'Best for: code generation, debugging, refactoring, SQL, APIs, and all software engineering tasks. Top coding model.',
    speed: 4, quality: 5, status: 'Cloud', latency: '0.8s (Developer)', badge: 'Free',
    badgeColor: 'text-emerald-600 font-semibold'
  },
  { 
    id: 'm-7', name: 'Mistral 7B', provider: 'Mistral AI', 
    description: 'Best for: concise responses, text summarization, extraction, and classification tasks.',
    speed: 5, quality: 3, status: 'Cloud', latency: '0.3s (Fast)', badge: 'Free',
    badgeColor: 'text-emerald-600 font-semibold'
  },
  { 
    id: 'm-8', name: 'Phi 3 Medium', provider: 'Microsoft Corp', 
    description: 'Best for: compact reasoning, math, precise task execution. Small but powerful Microsoft model.',
    speed: 5, quality: 3, status: 'Cloud', latency: '0.3s (Compact)', badge: 'Free',
    badgeColor: 'text-emerald-600 font-semibold'
  },
  { 
    id: 'm-9', name: 'OpenChat 3.5', provider: 'TSINGHUA', 
    description: 'Best for: chat-style interactions, roleplay, instruction following. Recursive alignment framework.',
    speed: 5, quality: 3, status: 'Cloud', latency: '0.4s (Creative)', badge: 'Free',
    badgeColor: 'text-emerald-600 font-semibold'
  },
  { 
    id: 'm-10', name: 'Hermes 3 8B', provider: 'Nous Research', 
    description: 'Best for: conversational freedom, roleplay, logic framing, and agentic use cases.',
    speed: 5, quality: 4, status: 'Cloud', latency: '0.4s (Synthetic)', badge: 'Free',
    badgeColor: 'text-emerald-600 font-semibold'
  },
  { 
    id: 'm-11', name: 'Gemini 2.5 Flash', provider: 'Google AI', 
    description: 'Best for: quick chat, vision/image analysis, multimodal tasks. Ultra-fast Google model.',
    speed: 5, quality: 4, status: 'Cloud', latency: '0.2s (Ultra Fast)', badge: 'Free',
    badgeColor: 'text-emerald-600 font-semibold'
  },
  { 
    id: 'm-12', name: 'Gemini 1.5 Flash', provider: 'Google AI', 
    description: 'Best for: bulk summaries, document processing, fast general chat. Long-context capable.',
    speed: 5, quality: 4, status: 'Cloud', latency: '0.3s (Fast)', badge: 'Free',
    badgeColor: 'text-emerald-600 font-semibold'
  },
  { 
    id: 'm-13', name: 'Llama 3 8B (Groq)', provider: 'Groq / Meta', 
    description: 'Best for: instant completions on Groq LPU hardware. Near-zero latency chat.',
    speed: 5, quality: 4, status: 'Cloud', latency: '0.1s (LPU Instant)', badge: 'Groq',
    badgeColor: 'text-amber-600 font-semibold'
  },
  { 
    id: 'm-14', name: 'Llama 3.3 70B (Groq)', provider: 'Groq / Meta', 
    description: 'Best for: high-quality fast reasoning on Groq. Best speed-to-quality ratio available.',
    speed: 5, quality: 5, status: 'Cloud', latency: '0.15s (LPU Instant)', badge: 'Groq',
    badgeColor: 'text-amber-600 font-semibold'
  },
  { 
    id: 'm-15', name: 'Llama 3.1 8B (Groq)', provider: 'Groq / Meta', 
    description: 'Best for: structured parsing, instant responses, pipelines requiring ultra-low latency.',
    speed: 5, quality: 4, status: 'Cloud', latency: '0.08s (LPU Instant)', badge: 'Groq',
    badgeColor: 'text-amber-600 font-semibold'
  },
  { 
    id: 'm-16', name: 'Mixtral 8x7B (Groq)', provider: 'Groq / Meta', 
    description: 'Best for: MoE high-speed execution, code summaries, multilingual tasks on Groq.',
    speed: 5, quality: 4, status: 'Cloud', latency: '0.12s (LPU Instant)', badge: 'Groq',
    badgeColor: 'text-amber-600 font-semibold'
  },
  { 
    id: 'm-17', name: 'Llama 3.1 Nemotron 70B (Nvidia)', provider: 'Nvidia / Meta', 
    description: 'Best for: conversational helpfulness, roleplay, coding, and general tasks on NVIDIA NIM.',
    speed: 5, quality: 5, status: 'Cloud', latency: '0.14s (GPU Accelerated)', badge: 'Nvidia',
    badgeColor: 'text-green-600 font-semibold'
  },
  { 
    id: 'm-18', name: 'Llama 3.3 70B (Nvidia)', provider: 'Nvidia / Meta', 
    description: 'Best for: high-speed enterprise reasoning and deep factual accuracy on NVIDIA NIM.',
    speed: 5, quality: 5, status: 'Cloud', latency: '0.15s (GPU Accelerated)', badge: 'Nvidia',
    badgeColor: 'text-green-600 font-semibold'
  },
  { 
    id: 'm-19', name: 'Mixtral 8x22B (Nvidia)', provider: 'Nvidia / Mistral', 
    description: 'Best for: complex logic pipelines, schema design, and large-context formatting on NVIDIA.',
    speed: 4, quality: 5, status: 'Cloud', latency: '0.18s (GPU Accelerated)', badge: 'Nvidia',
    badgeColor: 'text-green-600 font-semibold'
  }
];

// Initial Seed Memories
const INITIAL_MEMORIES: StoredMemory[] = [
  { 
    id: 'mem-101', 
    content: 'Client environment default styling preference is space glassmorphism with dark theme defaults.', 
    tags: ['config', 'layout', 'styling'], 
    strength: 'Core', 
    createdAt: '2026-05-27T10:00:00Z' 
  },
  { 
    id: 'mem-102', 
    content: 'Personal satellites clearance credentials are fully authorized under level 10 operator certificates.', 
    tags: ['identity', 'security', 'satellites'], 
    strength: 'Retentive', 
    createdAt: '2026-05-27T11:00:00Z' 
  }
];

export default function App() {
  
  // Navigation Routing States
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isEnteringAuth, setIsEnteringAuth] = useState<boolean>(false);
  const [currentScreen, setCurrentScreen] = useState<string>('chat'); // 'chat' | 'switcher' | 'memory' | 'marketplace' | 'admin' | 'settings'
  const [postLoginScreen, setPostLoginScreen] = useState<string>('chat');

  // Custom Admin Session Variables
  const [userEmail, setUserEmail] = useState<string>('');
  const [userDisplayName, setUserDisplayName] = useState<string>('');
  const [systemBroadcast, setSystemBroadcast] = useState<string | null>(
    'Developer Notice: Welcome to FrogeMind Unified Workspace Console.'
  );

  const isAdmin = userEmail === 'yogendrachukka@gmail.com';

  // Listen for real Firebase auth session states
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setIsAuthenticated(true);
        setIsEnteringAuth(false);
        setUserEmail(user.email || '');
        setUserDisplayName(user.displayName || 'FrogeMind User');
      } else {
        setIsAuthenticated(false);
        setUserEmail('');
        setUserDisplayName('');
      }
    });
    return () => unsubscribe();
  }, []);

  // Model States
  const [modelsList, setModelsList] = useState<LLMModel[]>(INITIAL_MODELS);
  const [activeModel, setActiveModel] = useState<LLMModel>(INITIAL_MODELS[0]);

  // Memory states
  const [memoriesList, setMemoriesList] = useState<StoredMemory[]>(INITIAL_MEMORIES);

  // Installed Plugins names list
  const [installedPlugins, setInstalledPlugins] = useState<string[]>(['CyberDoc - Prose Explainer']);

  // Handle addition of custom facts to Second brain
  const handleAddMemory = (content: string, tags: string[], strength: 'Core' | 'Retentive' | 'Fading') => {
    const newMemo: StoredMemory = {
      id: `mem-${Date.now()}`,
      content,
      tags,
      strength,
      createdAt: new Date().toISOString()
    };
    setMemoriesList(prev => [newMemo, ...prev]);
  };

  // Evict personal facts from registry
  const handleRemoveMemory = (id: string) => {
    setMemoriesList(prev => prev.filter(m => m.id !== id));
  };

  // Toggle dynamic active status (Online/Offline) inside catalog directory
  const handleToggleModel = (id: string) => {
    setModelsList(prev => prev.map(m => {
      if (m.id === id) {
        const nextStatus = m.status === 'Offline' ? 'Cloud' : 'Offline';
        return { 
          ...m, 
          status: nextStatus,
          latency: nextStatus === 'Offline' ? 'N/A' : '1.0s' 
        };
      }
      return m;
    }));
  };

  // Handle plug mount triggers
  const handleInstallPlugin = (name: string) => {
    if (installedPlugins.includes(name)) {
      setInstalledPlugins(prev => prev.filter(p => p !== name));
    } else {
      setInstalledPlugins(prev => [...prev, name]);
    }
  };

  // Fallback to active model if current became inactive offline
  useEffect(() => {
    const freshActive = modelsList.find(m => m.id === activeModel.id);
    if (freshActive && freshActive.status === 'Offline') {
      const fallback = modelsList.find(m => m.status !== 'Offline');
      if (fallback) setActiveModel(fallback);
    }
  }, [modelsList]);

  return (
    <div className="w-full h-screen overflow-hidden bg-white text-slate-800 flex font-sans antialiased">
      
      {/* Main Screen Routing */}
      <AnimatePresence mode="wait">
        
        {/* Render Landing Page if not logged in or in login form */}
        {!isAuthenticated && !isEnteringAuth && (
          <motion.div
            key="landing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="w-full h-full"
          >
            <LandingPage 
              onEnterApp={(sc) => {
                if (sc) setPostLoginScreen(sc);
                setIsEnteringAuth(true);
              }}
              onEnterAuth={() => {
                setPostLoginScreen('chat');
                setIsEnteringAuth(true);
              }}
            />
          </motion.div>
        )}

        {/* Render Auth Screen */}
        {!isAuthenticated && isEnteringAuth && (
          <motion.div
            key="auth"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="w-full h-full"
          >
            <AuthUI 
              onAuthSuccess={() => {
                setIsAuthenticated(true);
                setIsEnteringAuth(false);
                setCurrentScreen(postLoginScreen);
              }}
              onGoBack={() => setIsEnteringAuth(false)}
            />
          </motion.div>
        )}

        {/* Core Logged-in Workspace Hub */}
        {isAuthenticated && (
          <motion.div
            key="hub"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="w-full h-full flex"
          >
            {/* Sidebar navigation */}
            <Sidebar 
              currentScreen={currentScreen} 
              setScreen={setCurrentScreen} 
              memoriesCount={memoriesList.length}
              pluginsCount={installedPlugins.length}
              onSignOut={async () => {
                try {
                  await auth.signOut();
                } catch (e) {
                  console.error('Failed to sign out via Firebase Auth:', e);
                }
                setIsAuthenticated(false);
                setIsEnteringAuth(false);
                setCurrentScreen('chat');
              }}
              userEmail={userEmail}
              isAdmin={isAdmin}
            />

            {/* Display correct interactive viewport */}
            <main className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
               <AnimatePresence mode="wait">
                
                 {currentScreen === 'chat' && (
                  <motion.div 
                    key="chat_screen" 
                    initial={{ opacity: 0, scale: 0.99 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.99 }}
                    className="w-full h-full flex flex-col"
                  >
                    <ChatInterface 
                      modelsList={modelsList} 
                      activeModel={activeModel} 
                      onSelectModel={setActiveModel} 
                      memoriesCount={memoriesList.length}
                      systemBroadcast={systemBroadcast}
                    />
                  </motion.div>
                )}

                {currentScreen === 'projects' && (
                  <motion.div 
                    key="projects_screen" 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="w-full h-full flex flex-col"
                  >
                    <Projects />
                  </motion.div>
                )}

                {currentScreen === 'connectors' && (
                  <motion.div 
                    key="connectors_screen" 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="w-full h-full flex flex-col"
                  >
                    <Connectors />
                  </motion.div>
                )}

                {currentScreen === 'admin' && (
                  <motion.div 
                    key="admin_screen" 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="w-full h-full flex flex-col"
                  >
                    <AdminDashboard 
                      modelsList={modelsList}
                      onAddModel={(m) => setModelsList(prev => [...prev, m])}
                      onRemoveModel={(id) => setModelsList(prev => prev.filter(mod => mod.id !== id))}
                      systemBroadcast={systemBroadcast}
                      onUpdateBroadcast={setSystemBroadcast}
                      userEmail={userEmail}
                      isAdmin={isAdmin}
                    />
                  </motion.div>
                )}

                {currentScreen === 'settings' && (
                  <motion.div 
                    key="settings_screen" 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="w-full h-full flex flex-col"
                  >
                    <SettingsPanel />
                  </motion.div>
                )}

              </AnimatePresence>
            </main>

          </motion.div>
        )}

      </AnimatePresence>

    </div>
  );
}
